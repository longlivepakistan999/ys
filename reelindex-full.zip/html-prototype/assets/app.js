/* ReelIndex front-end behaviour (prototype).
   Watch providers: HTML ships the US list (what crawlers see); the script swaps
   to the visitor's English-speaking region. In production the default region
   comes from Cloudflare's CF-IPCountry header; here it is chosen with the select. */
(function () {
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  var LABELS = { stream: "Stream", rent: "Rent", buy: "Buy" };

  document.querySelectorAll("[data-providers]").forEach(function (box) {
    var dataEl = box.querySelector("script[type='application/json']");
    var select = box.querySelector("select[data-region]");
    var out = box.querySelector(".prov-groups");
    if (!dataEl || !select || !out) return;
    var data;
    try { data = JSON.parse(dataEl.textContent); } catch (e) { return; }

    function render(region) {
      var r = data[region];
      if (!r) return;
      var html = "";
      ["stream", "rent", "buy"].forEach(function (kind) {
        var list = r[kind] || [];
        if (!list.length) return;
        html += '<div class="prov-group"><span class="prov-label">' + LABELS[kind] + '</span><div class="prov-list">';
        list.forEach(function (p) {
          html += '<a class="prov" href="#" rel="nofollow sponsored"><i style="--h:' + p.h + '">' + esc(p.n.slice(0, 2)) + "</i>" + esc(p.n) + "</a>";
        });
        html += "</div></div>";
      });
      out.innerHTML = html || '<p class="muted">Not available to stream, rent or buy in this region yet.</p>';
    }

    try { var saved = localStorage.getItem("region"); if (saved && data[saved]) { select.value = saved; render(saved); } } catch (e) {}
    select.addEventListener("change", function () {
      render(select.value);
      try { localStorage.setItem("region", select.value); } catch (e) {}
    });
  });

  /* Prototype only: links that point at pages not built in the prototype */
  document.querySelectorAll("a[href='#']").forEach(function (a) {
    a.addEventListener("click", function (e) { e.preventDefault(); });
  });
})();
