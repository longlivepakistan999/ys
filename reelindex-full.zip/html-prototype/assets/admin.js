/* ReelIndex admin behaviour (prototype). Real actions call the admin API. */
(function () {
  var toastTimer;
  function toast(msg) {
    var t = document.querySelector(".toast");
    if (!t) { t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
    t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, 2600);
  }

  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-toast]");
    if (b) { e.preventDefault(); toast(b.getAttribute("data-toast")); }

    var c = e.target.closest("[data-confirm]");
    if (c) {
      e.preventDefault();
      var box = document.getElementById(c.getAttribute("data-confirm"));
      if (box) box.hidden = !box.hidden;
    }

    var cancel = e.target.closest("[data-cancel]");
    if (cancel) { e.preventDefault(); var bx = cancel.closest(".confirm-box"); if (bx) bx.hidden = true; }

    var mv = e.target.closest("[data-move]");
    if (mv) {
      e.preventDefault();
      var li = mv.closest("li"), list = li.parentElement;
      if (mv.getAttribute("data-move") === "up" && li.previousElementSibling) list.insertBefore(li, li.previousElementSibling);
      if (mv.getAttribute("data-move") === "down" && li.nextElementSibling) list.insertBefore(li.nextElementSibling, li);
      if (mv.getAttribute("data-move") === "remove") li.remove();
      list.querySelectorAll(".idx").forEach(function (n, i) { n.textContent = i + 1; });
    }
  });

  document.querySelectorAll("form[data-demo]").forEach(function (f) {
    f.addEventListener("submit", function (e) { e.preventDefault(); toast(f.getAttribute("data-demo")); });
  });

  /* Live preview for SEO title templates */
  document.querySelectorAll("[data-tpl]").forEach(function (input) {
    var out = document.getElementById(input.getAttribute("data-tpl"));
    var sample = JSON.parse(input.getAttribute("data-sample") || "{}");
    function upd() { out.textContent = input.value.replace(/\{(\w+)\}/g, function (m, k) { return k in sample ? sample[k] : m; }); }
    input.addEventListener("input", upd); upd();
  });
})();
