# ReelIndex

技术栈：Next.js、PostgreSQL（Prisma）、Redis（BullMQ）。

- 第 1 步：数据库表结构、TMDB 客户端、全部同步任务。
- 第 2 步：前台全部页面接数据库，包括 SEO、sitemap、robots.txt 和播放页。
- 第 3 步：后台管理。

## 本地运行

```bash
cp .env.example .env          # 填入 TMDB_TOKEN（TMDB 的 API Read Access Token）
docker compose up -d          # 启动 PostgreSQL 和 Redis
npm install
npx prisma db push            # 建表
npm run worker                # 终端 1：常驻同步进程（生产环境用 PM2 托管）
npm run sync -- admin 用户名 密码   # 终端 2：创建管理员（密码至少 12 位）
npm run sync -- seed          # 创建默认广告位（全部关闭）
npm run sync -- init          # 首次导入（类型、ID 导出文件、美国 2010 年后电影预导入）
npm run dev                   # 终端 3：网站，http://localhost:3000
```

## 同步流程

每日任务默认在 UTC 03:30 运行，时间可在后台修改。

1. **同步类型**：拉取电影和剧集的类型列表。
2. **导入每日 ID 导出文件**（电影、剧集、演员、合集）：
   - 新 ID 入库，只写名称和热度；
   - 已有条目更新热度；
   - 从 TMDB 消失的条目标记为已删除，页面返回 410。
3. **新电影、新剧集**：排队拉取详情。旧电影不在这里更新。
4. **剧集变动**（`/tv/changes`）：只处理仍在追踪的剧，逐季比对季数和集数，只拉取有变化的季：
   - 新季：拉取整季；
   - 集数变化：重新拉取该季；
   - 最新一季：每次都刷新，因为播出后会补充集名和简介。
5. **六个月轮换**：每天重新拉取最旧的 1/150 缓存数据，约 5 个月轮换一遍，满足 TMDB 缓存不超过 6 个月的条款。
6. **数据过期告警**：最旧数据超过 150 天时发送 Telegram 告警。
7. **收尾**（队列清空后）：
   - 刷新变动页面的缓存；
   - 清除 Cloudflare 上对应网址的缓存；
   - 通过 IndexNow 推送变动网址；
   - 发送 Telegram 摘要。

**限速**：所有进程共享 Redis 里的每秒计数器，默认每秒 30 次，可在后台调整。遇到 429 会按 Retry-After 退避；每条任务最多重试 5 次，仍失败的进入失败队列。

**按需拉取**：页面被首次访问时，如果该条目还没有详情，会通过 `src/lib/data/ensure.ts` 拉取一次。有 Redis 锁，同一条目不会被并发拉取多次。

## 手动命令

```bash
npm run sync -- daily               # 立即运行每日同步
npm run sync -- preload             # 预导入美国 2010 年后电影
npm run sync -- rotation            # 立即执行今天的轮换刷新
npm run sync -- refresh tv 1402     # 立即刷新单个条目并打印结果
```

## 目录

```
prisma/schema.prisma        表结构（TMDB id 作主键，detail 字段为 JSON 缓存）
src/lib/tmdb/               API 客户端（限速、重试）、导出文件读取、响应裁剪
src/lib/seo/indexable.ts    索引判定规则
src/lib/publish.ts          页面缓存刷新、Cloudflare 清除、IndexNow 推送
src/lib/notify/telegram.ts  Telegram 告警
src/sync/refresh/           电影、剧集（含季和集）、演员、合集的刷新逻辑
src/sync/jobs/              每日任务、导出文件导入、预导入、轮换、类型
src/sync/worker.ts          常驻 worker 和定时计划
```

## 前台网址

| 页面 | 网址 |
| --- | --- |
| 首页 | `/` |
| 电影 / 剧集列表 | `/movies`、`/tv`，分页 `/movies/page/2` |
| 类型、年份 | `/movies/horror`、`/movies/horror/2025`、`/movies/all/2025` |
| 平台片单 | `/movies/netflix`，其他地区 `/movies/netflix/uk`（ca、au、nz、ie 同理） |
| 即将上映 | `/movies/upcoming/2026/12` |
| Top Rated | `/top-rated/movies`、`/top-rated/tv` |
| 国家 | `/countries`、`/country/south-korea/tv` |
| 电影详情 / 相似 / 播放 | `/movie/550-fight-club-1999`、`…/similar`、`…/watch` |
| 合集 | `/collection/9485-the-fast-and-the-furious` |
| 剧集 / 季 / 集 / 播放 | `/tv/1402-the-walking-dead`、`…/season-1`、`…/season-1/episode-1`、`…/episode-1/watch` |
| 演员 | `/person/31-tom-hanks`、`…/movies` |
| 搜索（不收录） | `/search?q=` |
| sitemap / robots | `/sitemap.xml`、`/sitemaps/movies-1.xml`、`/robots.txt` |

- **网址纠正**：网址里 ID 在前。只带 ID、或 slug 已过时的网址，会 301 到当前正确网址。
- **没有内容的集**：没有独立网址，访问时 301 到季页。
- **列表筛选**：筛选都跳转到干净的网址，不使用查询参数，所以页面都能缓存。

## 播放页

播放页已经预留好：电影是 `/movie/…/watch`，剧集是 `/tv/…/episode-N/watch`。

- **片源来源**：从 `VideoSource` 表读取，在后台“播放片源”里管理。每条记录对应一部电影或一集，类型有三种：
  - `hls`：.m3u8 地址；
  - `mp4`：视频文件地址；
  - `iframe`：授权合作方提供的嵌入播放器。
- **多个片源**：显示为切换按钮。
- **rightsNote 字段**：用来记录授权信息，包括版权方、地区和到期时间。
- **有片源时**：详情页的 “Watch Now” 按钮会跳到播放页。
- **没有片源时**：
  - 播放页显示暂不可播放，并列出正版观看平台；
  - 播放页不进入索引；
  - “Watch Now” 按钮跳到详情页下方的观看平台区块。

请只添加你自己拥有、或已获得播放授权的视频。

## 构建与部署

- **构建需要能连上数据库**：`npm run build` 会预先生成少数几个固定页面（首页、电影列表、剧集列表、国家页），这一步要查询数据库，所以请在服务器上构建。
- **其他页面按需生成**：首次访问时生成并缓存，不会在构建时生成。
- **PM2 托管**：
  - 网站进程：`npm start`
  - 同步进程：`npm run worker`

## 后台

地址是 `/admin`。在 `.env` 里设置 `ADMIN_PATH=任意路径` 后改用新地址，原来的 `/admin` 返回 404。

| 页面 | 功能 |
| --- | --- |
| 仪表盘 | 数据总量、可索引页面数、最近一次同步、14 天 API 调用量、爬虫统计（读取 Nginx 日志）、最近告警 |
| 同步管理 | 立即同步、立即轮换、按 TMDB ID 添加或刷新、计划时间与速率、失败重试队列、同步日志 |
| 内容管理 | 按片名或 ID 搜索，按索引状态和下架状态筛选；编辑页可修改显示标题、SEO 标题、简介，强制索引或强制不索引，下架，刷新，清除缓存 |
| 播放片源 | 为电影或某一集添加 HLS、MP4 或授权嵌入播放器，授权说明必填；可启用、停用、删除 |
| 首页编排 | 推荐电影、推荐剧集的置顶（添加、排序、移除）、自动规则、显示数量、热门链接 |
| SEO 管理 | Title 模板、索引门槛、重新计算索引、sitemap 统计、301 重定向、robots.txt、热门搜索词 |
| 广告管理 | 广告位开关、通用广告代码、尺寸、显示的页面类型、未填充时折叠 |
| 缓存管理 | 按网址清除（可连同季页、集页）、清除全部（需二次确认）、Redis 内存 |
| 站点设置 | 站名与域名、接口密钥、Telegram 告警事件与测试消息、代码插入、修改密码、两步验证、操作日志 |

**安全**
- **密码**：用 scrypt 哈希保存。
- **两步验证**：使用 TOTP，任何身份验证器 App 都能用。
- **登录 Cookie**：经过签名，只能由服务器读取（HttpOnly），有效期 7 天。修改密码后，其他设备会自动退出登录。
- **双重检查**：中间件和每个页面、每个操作都会验证登录状态。
- **防暴力破解**：同一 IP 连续失败 5 次，锁定 15 分钟，并发送 Telegram 通知。
- **禁止收录**：后台页面全部输出 `noindex` 和 `no-store`。
- **忘记密码**：在服务器上重新运行 `npm run sync -- admin 用户名 新密码`。这会同时关闭两步验证，并让所有设备退出登录。
