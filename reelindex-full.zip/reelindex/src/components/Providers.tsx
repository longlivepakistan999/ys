"use client";
import { useEffect, useState } from "react";
import type { RegionProviders } from "@/lib/tmdb/trim";

const REGIONS: [string, string][] = [["US", "United States"], ["GB", "United Kingdom"], ["CA", "Canada"], ["AU", "Australia"], ["NZ", "New Zealand"], ["IE", "Ireland"]];
const LOGO = "https://image.tmdb.org/t/p/w92";

/**
 * Where-to-watch block. The server renders the US list (what crawlers index);
 * on the client it switches to the visitor's region: saved choice first, then
 * the country Cloudflare reports via /api/region.
 */
export function Providers({ data, title }: { data: Record<string, RegionProviders>; title: string }) {
  const [region, setRegion] = useState("US");

  useEffect(() => {
    let saved: string | null = null;
    try { saved = localStorage.getItem("region"); } catch {}
    if (saved && REGIONS.some(([c]) => c === saved)) { setRegion(saved); return; }
    fetch("/api/region").then((r) => r.json()).then((j: { region?: string }) => {
      if (j.region && REGIONS.some(([c]) => c === j.region)) setRegion(j.region);
    }).catch(() => {});
  }, []);

  const choose = (r: string) => {
    setRegion(r);
    try { localStorage.setItem("region", r); } catch {}
  };

  const r = data[region];
  const groups: [string, RegionProviders["stream"]][] = r ? [["Stream", r.stream], ["Free", r.free], ["Rent", r.rent], ["Buy", r.buy]] : [];
  const visible = groups.filter(([, l]) => l.length);

  return (
    <section className="section" id="watch">
      <div className="section-head"><h2 className="section-title">Where to Watch {title}</h2></div>
      <div className="providers-head">
        <p className="muted" style={{ margin: 0 }}>Streaming, rental and purchase options in your region.</p>
        <label className="region" htmlFor="region">Region{" "}
          <select className="field" id="region" value={region} onChange={(e) => choose(e.target.value)}>
            {REGIONS.map(([c, n]) => <option key={c} value={c}>{n}</option>)}
          </select>
        </label>
      </div>
      {visible.length ? (
        <div className="prov-groups">
          {visible.map(([label, list]) => (
            <div className="prov-group" key={label}>
              <span className="prov-label">{label}</span>
              <div className="prov-list">
                {list.map((p) => (
                  <a key={p.id} className="prov" href={r?.link ?? "#"} target="_blank" rel="nofollow noopener sponsored">
                    {p.logo
                      // eslint-disable-next-line @next/next/no-img-element
                      ? <img src={LOGO + p.logo} alt="" width={30} height={30} style={{ borderRadius: 5 }} loading="lazy" />
                      : <i style={{ ["--h" as string]: (p.id * 47) % 360 }}>{p.name.slice(0, 2)}</i>}
                    {p.name}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="muted">Not available to stream, rent or buy in this region yet.</p>
      )}
      <p className="prov-note">Availability data by JustWatch. Catalogs change often; check the service before you subscribe.</p>
    </section>
  );
}
