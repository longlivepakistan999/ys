import type { ReactNode } from "react";

/**
 * Admin "Code injection (head)": React cannot drop raw HTML into <head>, so the
 * common tags are parsed and re-emitted: <meta>, <link>, and <script> (src or inline).
 */
function attrs(s: string): Record<string, string> {
  const out: Record<string, string> = {};
  const re = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    const key = m[1].toLowerCase();
    const map: Record<string, string> = { class: "className", crossorigin: "crossOrigin", charset: "charSet", "http-equiv": "httpEquiv", referrerpolicy: "referrerPolicy", nomodule: "noModule" };
    out[map[key] ?? key] = m[2] ?? m[3] ?? m[4] ?? "";
  }
  return out;
}

export function HeadCode({ html }: { html: string }) {
  if (!html.trim()) return null;
  const nodes: ReactNode[] = [];
  const re = /<(meta|link)\b([^>]*)\/?>|<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(html))) {
    if (m[1]) {
      const a = attrs(m[2]);
      nodes.push(m[1].toLowerCase() === "meta" ? <meta key={i++} {...a} /> : <link key={i++} {...a} />);
    } else {
      const a = attrs(m[3]);
      const body = m[4].trim();
      nodes.push(body
        ? <script key={i++} {...a} dangerouslySetInnerHTML={{ __html: body }} />
        : <script key={i++} {...a} async={"async" in a ? true : undefined} />);
    }
  }
  return <>{nodes}</>;
}
