import Link from "next/link";
import type { ReactNode } from "react";
import type { CardItem } from "@/lib/data/queries";
import { img } from "@/lib/site";

/** Deterministic hue for gradient placeholders when TMDB has no image. */
export function hue(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h % 360;
}

export function Poster({ title, path, size = "w342", mini = false, rating, priority = false }: {
  title: string; path: string | null | undefined; size?: "w92" | "w185" | "w342" | "w500"; mini?: boolean; rating?: number | null; priority?: boolean;
}) {
  const src = img(path, size);
  return (
    <div className={`poster${mini ? " mini" : ""}${src ? " has-img" : ""}`} style={{ ["--h" as string]: hue(title) }}>
      {src && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt={`${title} poster`} width={342} height={513} loading={priority ? "eager" : "lazy"} decoding="async" />
      )}
      {!mini && rating ? <span className="badge rating">&#9733; {rating.toFixed(1)}</span> : null}
      <span className="pt">{title}</span>
    </div>
  );
}

export function Still({ title, path, size = "w500", href, children }: { title: string; path: string | null | undefined; size?: "w185" | "w342" | "w500" | "w780"; href?: string; children?: ReactNode }) {
  const src = img(path, size);
  const inner = (
    <>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      {src && <img src={src} alt={`${title} still`} width={500} height={281} loading="lazy" decoding="async" />}
      {children}
    </>
  );
  const style = { ["--h" as string]: hue(title) };
  return href ? <Link className="still" style={style} href={href} aria-label={title}>{inner}</Link> : <div className="still" style={style}>{inner}</div>;
}

export function Card({ item }: { item: CardItem }) {
  return (
    <Link className="card" href={item.href}>
      <Poster title={item.title} path={item.poster} rating={item.rating} />
      <span className="card-title">{item.title}</span>
      <span className="card-meta">{item.year && <span>{item.year}</span>}{item.meta && <span>{item.meta}</span>}</span>
    </Link>
  );
}

export function Grid({ items, empty = "Nothing to show here yet." }: { items: CardItem[]; empty?: string }) {
  if (!items.length) return <p className="empty">{empty}</p>;
  return <div className="grid">{items.map((i) => <Card key={i.key} item={i} />)}</div>;
}

export function Crumbs({ items, onDark = false }: { items: [string, string][]; onDark?: boolean }) {
  return (
    <nav className="crumbs" aria-label="Breadcrumb" style={onDark ? undefined : undefined}>
      <ol>
        {items.map(([name, href], i) =>
          i === items.length - 1
            ? <li key={i} aria-current="page">{name}</li>
            : <li key={i}><Link href={href}>{name}</Link></li>)}
      </ol>
    </nav>
  );
}

export function Section({ title, link, count, id, children }: { title: string; link?: [string, string]; count?: string; id?: string; children: ReactNode }) {
  return (
    <section className="section" id={id}>
      <div className="section-head">
        <h2 className="section-title">{title}</h2>
        {link ? <Link className="section-link" href={link[1]}>{link[0]} &rarr;</Link> : count ? <span className="count">{count}</span> : null}
      </div>
      {children}
    </section>
  );
}

/** Page 1 lives at the base URL; later pages at /page/N (needs doc §5, pagination). */
export const pageHref = (base: string, n: number) => (n <= 1 ? base : `${base}/page/${n}`);

export function Pager({ base, page, pages, maxPages = 100 }: { base: string; page: number; pages: number; maxPages?: number }) {
  const last = Math.min(pages, maxPages);
  if (last <= 1) return null;
  const nums = [...new Set([1, 2, 3, page - 1, page, page + 1, last])].filter((n) => n >= 1 && n <= last).sort((a, b) => a - b);
  const out: ReactNode[] = [];
  out.push(page > 1 ? <Link key="p" href={pageHref(base, page - 1)} rel="prev">&lsaquo; Prev</Link> : <span key="p" className="off">&lsaquo; Prev</span>);
  let prev = 0;
  for (const n of nums) {
    if (n - prev > 1) out.push(<span key={`g${n}`} className="gap">&hellip;</span>);
    out.push(n === page ? <span key={n} aria-current="page">{n}</span> : <Link key={n} href={pageHref(base, n)}>{n}</Link>);
    prev = n;
  }
  out.push(page < last ? <Link key="n" href={pageHref(base, page + 1)} rel="next">Next &rsaquo;</Link> : <span key="n" className="off">Next &rsaquo;</span>);
  return <nav className="pager" aria-label="Pagination">{out}</nav>;
}

export function Avatar({ name, path }: { name: string; path: string | null | undefined }) {
  const src = img(path, "w185");
  const initials = name.split(/\s+/).slice(0, 2).map((w) => w[0]).join("");
  return (
    <span className={`avatar${src ? " has-img" : ""}`} style={{ ["--h" as string]: hue(name) }}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      {src && <img src={src} alt={name} width={185} height={185} loading="lazy" decoding="async" />}
      <span>{initials}</span>
    </span>
  );
}

export function PeopleRail({ people }: { people: { key: string; name: string; role: string; profile: string | null; href?: string }[] }) {
  if (!people.length) return <p className="empty">No cast information yet.</p>;
  return (
    <div className="rail">
      {people.map((p) => {
        const body = <><Avatar name={p.name} path={p.profile} /><span className="person-name">{p.name}</span><span className="person-role">{p.role}</span></>;
        return p.href ? <Link key={p.key} className="person" href={p.href}>{body}</Link> : <div key={p.key} className="person">{body}</div>;
      })}
    </div>
  );
}

export function Facts({ rows }: { rows: [string, ReactNode][] }) {
  return (
    <dl className="facts">
      {rows.filter(([, v]) => v !== null && v !== undefined && v !== "").map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}
    </dl>
  );
}

export const PlayIcon = () => <svg viewBox="0 0 24 24" aria-hidden="true" width="16" height="16" fill="currentColor"><path d="M7 4.5v15l13-7.5z" /></svg>;
