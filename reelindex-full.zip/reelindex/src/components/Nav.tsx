"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV: [string, string, RegExp][] = [
  ["TV Shows", "/tv", /^\/tv(\/|$)/],
  ["Movies", "/movies", /^\/(movies|movie|collection)(\/|$)/],
  ["Top Rated", "/top-rated/movies", /^\/top-rated(\/|$)/],
  ["Countries", "/countries", /^\/(countries|country)(\/|$)/],
];

export function Nav() {
  const path = usePathname() ?? "/";
  return (
    <nav className="main-nav" aria-label="Main">
      {NAV.map(([name, href, re]) => (
        <Link key={href} href={href} aria-current={re.test(path) ? "page" : undefined}>{name}</Link>
      ))}
    </nav>
  );
}
