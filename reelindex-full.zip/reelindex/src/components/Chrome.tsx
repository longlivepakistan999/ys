import Link from "next/link";
import { PROVIDERS } from "@/lib/providers";
import { Nav } from "./Nav";

function Logo({ name }: { name: string }) {
  // Splits the site name for the two-tone wordmark: "ReelIndex" → Reel + Index
  const m = /^([A-Z][a-z]+)(.*)$/.exec(name);
  return m && m[2] ? <>{m[1]}<b>{m[2]}</b></> : <>{name}</>;
}

export function Header({ siteName }: { siteName: string }) {
  return (
    <header className="site-header">
      <div className="wrap">
        <Link className="logo" href="/" aria-label={`${siteName} home`}><Logo name={siteName} /></Link>
        <Nav />
        <form className="header-search" action="/search" method="get" role="search">
          <label className="visually-hidden" htmlFor="hq">Search movies, TV shows and people</label>
          <input className="field" id="hq" name="q" type="search" placeholder="Search movies, shows, people" autoComplete="off" />
          <button className="btn btn-primary" type="submit" aria-label="Search">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.4" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
          </button>
        </form>
      </div>
    </header>
  );
}

export function Footer({ siteName, text }: { siteName: string; text: string }) {
  const year = new Date().getUTCFullYear();
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="foot-grid">
          <div>
            <Link className="logo" href="/"><Logo name={siteName} /></Link>
            <p className="muted" style={{ marginTop: 10, maxWidth: "40ch" }}>{text}</p>
          </div>
          <div><h2>Browse</h2><ul>
            <li><Link href="/movies">Movies</Link></li><li><Link href="/tv">TV Shows</Link></li>
            <li><Link href="/top-rated/movies">Top Rated</Link></li><li><Link href="/countries">Countries</Link></li>
            <li><Link href={`/movies/upcoming/${year}/${new Date().getUTCMonth() + 1}`}>Upcoming Movies</Link></li></ul></div>
          <div><h2>Streaming</h2><ul>
            {PROVIDERS.slice(0, 5).map((p) => <li key={p.slug}><Link href={`/movies/${p.slug}`}>{p.name}</Link></li>)}</ul></div>
          <div><h2>Site</h2><ul>
            <li><Link href="/about">About</Link></li><li><Link href="/contact">Contact</Link></li>
            <li><Link href="/privacy">Privacy Policy</Link></li><li><Link href="/terms">Terms of Use</Link></li></ul></div>
        </div>
        <div className="attribution">
          {/* Replace with an approved TMDB logo file in /public (TMDB attribution rules). */}
          <span className="tmdb-mark">TMDB</span>
          <p style={{ margin: 0 }}>This product uses the TMDB API but is not endorsed or certified by TMDB. Streaming availability data by JustWatch. &copy; {year} {siteName}</p>
        </div>
      </div>
    </footer>
  );
}
