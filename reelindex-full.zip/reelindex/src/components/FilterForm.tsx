"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

/**
 * Filters map onto clean, indexable URLs instead of query strings:
 * genre → /movies/horror, genre + year → /movies/horror/2025,
 * country → /country/japan/movies, "highest rated" → /top-rated/movies.
 * Pages stay statically cached and there are no parameter duplicates to canonicalize.
 */
export function FilterForm({ kind, genres, countries, current }: {
  kind: "movies" | "tv";
  genres: { slug: string; name: string }[];
  countries: { slug: string; name: string }[];
  current?: { genre?: string; year?: number; country?: string };
}) {
  const router = useRouter();
  const [genre, setGenre] = useState(current?.genre ?? "");
  const [year, setYear] = useState(current?.year ? String(current.year) : "");
  const [country, setCountry] = useState(current?.country ?? "");
  const [sort, setSort] = useState("popular");
  const now = new Date().getUTCFullYear();

  const go = (e: React.FormEvent) => {
    e.preventDefault();
    if (sort === "rating") return router.push(`/top-rated/${kind}`);
    if (country) return router.push(`/country/${country}/${kind}`);
    if (genre && year) return router.push(`/${kind}/${genre}/${year}`);
    if (genre) return router.push(`/${kind}/${genre}`);
    if (year) return router.push(`/${kind}/all/${year}`);
    router.push(`/${kind}`);
  };

  return (
    <form className="filters" onSubmit={go}>
      <label htmlFor="f-genre">Genre
        <select className="field" id="f-genre" value={genre} onChange={(e) => setGenre(e.target.value)}>
          <option value="">All genres</option>
          {genres.map((g) => <option key={g.slug} value={g.slug}>{g.name}</option>)}
        </select>
      </label>
      <label htmlFor="f-year">Year
        <select className="field" id="f-year" value={year} onChange={(e) => setYear(e.target.value)}>
          <option value="">Any year</option>
          {Array.from({ length: 40 }, (_, i) => now + 1 - i).map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </label>
      <label htmlFor="f-country">Country
        <select className="field" id="f-country" value={country} onChange={(e) => setCountry(e.target.value)}>
          <option value="">All countries</option>
          {countries.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
        </select>
      </label>
      <label htmlFor="f-sort">Sort by
        <select className="field" id="f-sort" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="popular">Most popular</option>
          <option value="rating">Highest rated</option>
        </select>
      </label>
      <button className="btn btn-primary" type="submit">Apply</button>
    </form>
  );
}
