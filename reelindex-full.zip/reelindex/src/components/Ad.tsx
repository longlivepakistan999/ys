import { prisma } from "@/lib/db";

let cache: { at: number; slots: Map<string, { enabled: boolean; code: string; pageTypes: string[]; desktopH: number; mobileH: number }> } | null = null;

async function slots() {
  if (cache && Date.now() - cache.at < 60_000) return cache.slots;
  const rows = await prisma.adSlot.findMany();
  cache = { at: Date.now(), slots: new Map(rows.map((r) => [r.key, r])) };
  return cache.slots;
}

/**
 * Ad slot (needs doc §6). Outputs nothing at all unless the slot is switched on,
 * has code and is enabled for this page type, so a site without ads shows no gaps.
 * Height is reserved to avoid layout shift. The code runs on the server-rendered
 * page; client-side navigation shows it on the next full load.
 */
export async function Ad({ slot, page }: { slot: string; page: string }) {
  const s = (await slots()).get(slot);
  if (!s || !s.enabled || !s.code.trim()) return null;
  if (s.pageTypes.length && !s.pageTypes.includes(page)) return null;
  return (
    <div className="ad-slot live" data-ad-slot={slot} style={{ minHeight: s.desktopH }} dangerouslySetInnerHTML={{ __html: s.code }} />
  );
}
