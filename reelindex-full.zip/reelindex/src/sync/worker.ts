/**
 * Long-running sync worker: `npm run worker` (keep it alive with PM2).
 * Registers the daily schedule and processes every TMDB job.
 */
import { Worker, type Job } from "bullmq";
import { newRedisConnection } from "@/lib/redis";
import { getSettings } from "@/lib/settings";
import { QUEUE_NAME, jobDone, queue, type JobData } from "./queue";
import { failRun, finishRun, recordFailure, recordResult, startRun } from "./run";
import { refreshMovie } from "./refresh/movie";
import { refreshTv } from "./refresh/tv";
import { refreshCollection, refreshPerson } from "./refresh/other";
import { runDaily } from "./jobs/daily";
import { runPreload } from "./jobs/preload";
import { reindexAll } from "./jobs/reindex";
import { notify } from "@/lib/notify/telegram";
import { revalidatePaths } from "@/lib/publish";
import type { RefreshResult } from "./refresh/types";

async function processDetail(job: Job<JobData>) {
  const d = job.data as Extract<JobData, { id: number }>;
  try {
    let r: RefreshResult;
    if (d.type === "movie") r = await refreshMovie(d.id);
    else if (d.type === "tv") r = await refreshTv(d.id, { force: d.force });
    else if (d.type === "person") r = await refreshPerson(d.id);
    else r = await refreshCollection(d.id);
    if (d.runId) { await recordResult(d.runId, d.type, r); await jobDone(d.runId); }
    return r.status;
  } catch (err) {
    const last = job.attemptsMade + 1 >= (job.opts.attempts ?? 1);
    if (!last) throw err; // BullMQ retries with exponential backoff
    await recordFailure(d.runId, d.type, d.id, err instanceof Error ? err.message : String(err));
    if (d.runId) await jobDone(d.runId);
    return "failed";
  }
}

async function processor(job: Job<JobData>) {
  const d = job.data;
  switch (d.type) {
    case "daily": {
      const runId = await startRun("daily");
      try { await runDaily(runId); } catch (err) { await failRun(runId, err); }
      return;
    }
    case "preload": {
      try { await runPreload(d.runId); } catch (err) { await failRun(d.runId, err); }
      return;
    }
    case "finalize":
      await finishRun(d.runId);
      return;
    case "reindex": {
      const r = await reindexAll();
      await revalidatePaths(["/sitemap.xml"]);
      await notify("dailySummary", `Index rules re-applied: ${r.changed} pages changed state.`);
      return r;
    }
    default:
      return processDetail(job);
  }
}

async function main() {
  const s = await getSettings(0);
  await queue().upsertJobScheduler(
    "daily-sync",
    { pattern: s.syncCron, tz: "UTC" },
    { name: "daily", data: { type: "daily" }, opts: { removeOnComplete: true, removeOnFail: 20, attempts: 1 } },
  );
  const worker = new Worker<JobData>(QUEUE_NAME, processor, {
    connection: newRedisConnection(),
    concurrency: s.workerConcurrency,
    lockDuration: 120_000,
  });
  worker.on("error", (err) => console.error("[worker]", err));
  console.log(`[worker] running · daily sync "${s.syncCron}" UTC · concurrency ${s.workerConcurrency}`);

  const stop = async () => { console.log("[worker] shutting down"); await worker.close(); process.exit(0); };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
}

main().catch((err) => { console.error(err); process.exit(1); });
