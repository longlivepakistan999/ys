import { Queue } from "bullmq";
import { newRedisConnection, redis } from "@/lib/redis";

export const QUEUE_NAME = "tmdb";

export type DetailType = "movie" | "tv" | "person" | "collection";
export type JobData =
  | { type: DetailType; id: number; runId?: number; force?: boolean }
  | { type: "daily" }
  | { type: "preload"; runId: number }
  | { type: "finalize"; runId: number }
  | { type: "reindex" };

/** Lower number = runs first (BullMQ priority). */
export const PRIORITY = { manual: 1, tvChange: 3, dailyNew: 5, lazy: 8, preload: 20, rotation: 50 } as const;

let q: Queue<JobData> | null = null;
export function queue(): Queue<JobData> {
  if (!q) q = new Queue<JobData>(QUEUE_NAME, { connection: newRedisConnection() });
  return q;
}

/** Pending-job counter per run: when it reaches 0 on a sealed run, the run is finalized. */
const pendingKey = (runId: number) => `run:${runId}:pending`;
const sealedKey = (runId: number) => `run:${runId}:sealed`;

export async function enqueueDetail(type: DetailType, id: number, opts: { runId?: number; priority?: number; force?: boolean } = {}) {
  // Job ids are unique per run, so the same title is never queued twice in one run.
  const jobId = `${type}-${id}-${opts.runId ?? "x"}`;
  const existing = await queue().getJob(jobId);
  if (existing) return false;
  if (opts.runId) await redis().incr(pendingKey(opts.runId));
  await queue().add(type, { type, id, runId: opts.runId, force: opts.force }, {
    jobId,
    priority: opts.priority ?? PRIORITY.manual,
    attempts: 5,
    backoff: { type: "exponential", delay: 5_000 },
    removeOnComplete: true,
    removeOnFail: true,
  });
  return true;
}

export async function enqueueMany(type: DetailType, ids: number[], opts: { runId?: number; priority?: number; force?: boolean }) {
  let n = 0;
  for (const id of ids) if (await enqueueDetail(type, id, opts)) n++;
  return n;
}

/** Called once a run has queued everything it will queue. */
export async function sealRun(runId: number) {
  await redis().set(sealedKey(runId), "1", "EX", 60 * 60 * 48);
  const pending = Number((await redis().get(pendingKey(runId))) || 0);
  if (pending <= 0) await enqueueFinalize(runId);
}

/** Called by the worker after each detail job of a run (success or final failure). */
export async function jobDone(runId: number) {
  const left = await redis().decr(pendingKey(runId));
  if (left <= 0 && (await redis().get(sealedKey(runId)))) await enqueueFinalize(runId);
}

async function enqueueFinalize(runId: number) {
  await queue().add("finalize", { type: "finalize", runId }, { jobId: `finalize-${runId}`, priority: PRIORITY.manual, removeOnComplete: true, removeOnFail: 50 });
}

export async function clearRunKeys(runId: number) {
  await redis().del(pendingKey(runId), sealedKey(runId), `run:${runId}:paths`);
}
