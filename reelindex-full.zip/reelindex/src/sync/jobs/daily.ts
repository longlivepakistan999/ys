import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { tmdb } from "@/lib/tmdb/client";
import type { TmdbChange, TmdbPaged } from "@/lib/tmdb/types";
import { notify } from "@/lib/notify/telegram";
import { enqueueMany, PRIORITY, sealRun } from "../queue";
import { importExport } from "./importExport";
import { syncGenres } from "./genres";
import { enqueueRotation } from "./rotation";

const ymd = (d: Date) => d.toISOString().slice(0, 10);

/** Ids TMDB reports as changed in the window (max 14 days per call). */
async function changedTvIds(from: Date, to: Date): Promise<number[]> {
  const ids = new Set<number>();
  for (let page = 1; ; page++) {
    const res = await tmdb<TmdbPaged<TmdbChange>>("/tv/changes", { start_date: ymd(from), end_date: ymd(to), page, language: undefined });
    if (!res) break;
    for (const r of res.results) if (!r.adult) ids.add(r.id);
    if (page >= res.total_pages || page >= 500) break;
  }
  return [...ids];
}

/**
 * The daily run (needs doc §3):
 *  1. genres; 2. ID exports → new titles + popularity + removals;
 *  3. new movies and shows → fetch details (old movies are not re-fetched here);
 *  4. TMDB changes → refresh shows we track (new seasons / new episodes);
 *  5. 6-month rotation; 6. stale-data alert; 7. seal → finalize when the queue drains.
 */
export async function runDaily(runId: number) {
  const s = await getSettings();
  await syncGenres();

  const movies = await importExport("movie");
  const shows = await importExport("tv_series");
  const people = await importExport("person");
  const collections = await importExport("collection");
  await prisma.syncRun.update({
    where: { id: runId },
    data: { note: `exports: ${movies.seen} movies (+${movies.inserted.length}, -${movies.removed}), ${shows.seen} shows (+${shows.inserted.length}, -${shows.removed}), ${people.seen} people, ${collections.seen} collections` },
  });

  // On the very first import every id is "new": details then come from the preload and on demand instead.
  if (!movies.firstImport) await enqueueMany("movie", movies.inserted.map((x) => x.id), { runId, priority: PRIORITY.dailyNew });
  if (!shows.firstImport) await enqueueMany("tv", shows.inserted.map((x) => x.id), { runId, priority: PRIORITY.dailyNew });

  const to = new Date();
  const from = new Date(to.getTime() - 36 * 3_600_000); // overlap so a late run misses nothing
  const changed = await changedTvIds(from, to);
  for (let i = 0; i < changed.length; i += 5_000) {
    const part = changed.slice(i, i + 5_000);
    const tracked = await prisma.tvShow.findMany({
      where: { id: { in: part }, isTracking: true, removedAt: null, detailSyncedAt: { not: null } }, select: { id: true },
    });
    await enqueueMany("tv", tracked.map((x) => x.id), { runId, priority: PRIORITY.tvChange });
  }

  await enqueueRotation(runId);

  const oldest = await prisma.movie.findFirst({ where: { detailSyncedAt: { not: null }, removedAt: null }, orderBy: { detailSyncedAt: "asc" }, select: { detailSyncedAt: true } });
  if (oldest?.detailSyncedAt) {
    const days = Math.floor((Date.now() - oldest.detailSyncedAt.getTime()) / 86_400_000);
    if (days > s.staleAlertDays) await notify("staleData", `⚠️ Oldest cached movie data is ${days} days old (limit ${s.staleAlertDays}). Raise the rotation share or the API rate.`);
  }

  await sealRun(runId);
}
