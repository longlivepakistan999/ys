import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { enqueueMany, PRIORITY } from "../queue";

/**
 * TMDB's terms cap cached data at 6 months. Each day re-fetch the oldest
 * 1/rotationDivisor of every cached table (default 1/150 ≈ a full cycle in 5 months).
 */
export async function enqueueRotation(runId: number) {
  const { rotationDivisor } = await getSettings();
  const where = { detailSyncedAt: { not: null }, removedAt: null } as const;
  const take = (total: number) => Math.ceil(total / Math.max(1, rotationDivisor));
  const opts = { runId, priority: PRIORITY.rotation, force: true };

  const m = take(await prisma.movie.count({ where }));
  if (m) await enqueueMany("movie", (await prisma.movie.findMany({ where, orderBy: { detailSyncedAt: "asc" }, take: m, select: { id: true } })).map((x) => x.id), opts);

  const t = take(await prisma.tvShow.count({ where }));
  if (t) await enqueueMany("tv", (await prisma.tvShow.findMany({ where, orderBy: { detailSyncedAt: "asc" }, take: t, select: { id: true } })).map((x) => x.id), opts);

  const p = take(await prisma.person.count({ where }));
  if (p) await enqueueMany("person", (await prisma.person.findMany({ where, orderBy: { detailSyncedAt: "asc" }, take: p, select: { id: true } })).map((x) => x.id), opts);

  const c = take(await prisma.collection.count({ where }));
  if (c) await enqueueMany("collection", (await prisma.collection.findMany({ where, orderBy: { detailSyncedAt: "asc" }, take: c, select: { id: true } })).map((x) => x.id), opts);

  return { movies: m, shows: t, people: p, collections: c };
}
