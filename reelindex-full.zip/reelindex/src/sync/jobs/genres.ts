import { prisma } from "@/lib/db";
import { slugify } from "@/lib/slug";
import { tmdb } from "@/lib/tmdb/client";
import type { TmdbGenre } from "@/lib/tmdb/types";

export async function syncGenres() {
  const movie = (await tmdb<{ genres: TmdbGenre[] }>("/genre/movie/list"))?.genres ?? [];
  const tv = (await tmdb<{ genres: TmdbGenre[] }>("/genre/tv/list"))?.genres ?? [];
  const all = new Map<number, { name: string; kinds: Set<string> }>();
  for (const g of movie) all.set(g.id, { name: g.name, kinds: new Set(["movie"]) });
  for (const g of tv) {
    const x = all.get(g.id);
    if (x) x.kinds.add("tv"); else all.set(g.id, { name: g.name, kinds: new Set(["tv"]) });
  }
  for (const [id, g] of all) {
    const kind = g.kinds.size === 2 ? "both" : [...g.kinds][0];
    await prisma.genre.upsert({ where: { id }, create: { id, name: g.name, slug: slugify(g.name), kind }, update: { name: g.name, slug: slugify(g.name), kind } });
  }
  return all.size;
}
