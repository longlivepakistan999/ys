import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { episodeHasPage, personIndexable, seasonIndexable, titleIndexable } from "@/lib/seo/indexable";

/**
 * Re-applies the index rules to every cached row after the admin changes a
 * threshold. Works in id-ordered batches so memory stays flat on 1M+ rows.
 */
export async function reindexAll(): Promise<{ changed: number }> {
  const s = await getSettings(0);
  let changed = 0;
  const batch = 5_000;

  for (let after = 0; ;) {
    const rows = await prisma.movie.findMany({ where: { id: { gt: after } }, orderBy: { id: "asc" }, take: batch,
      select: { id: true, hidden: true, removedAt: true, indexOverride: true, adult: true, overview: true, posterPath: true, voteCount: true, isIndexable: true } });
    if (!rows.length) break;
    after = rows[rows.length - 1].id;
    const flip = rows.filter((r) => titleIndexable(r, s) !== r.isIndexable);
    for (const r of flip) await prisma.movie.update({ where: { id: r.id }, data: { isIndexable: !r.isIndexable } });
    changed += flip.length;
  }

  for (let after = 0; ;) {
    const shows = await prisma.tvShow.findMany({ where: { id: { gt: after } }, orderBy: { id: "asc" }, take: 1_000,
      select: { id: true, hidden: true, removedAt: true, indexOverride: true, adult: true, overview: true, posterPath: true, voteCount: true, isIndexable: true, popularity: true } });
    if (!shows.length) break;
    after = shows[shows.length - 1].id;
    for (const t of shows) {
      const idx = titleIndexable(t, s);
      if (idx !== t.isIndexable) { await prisma.tvShow.update({ where: { id: t.id }, data: { isIndexable: idx } }); changed++; }
      const seasons = await prisma.season.findMany({ where: { showId: t.id }, select: { id: true, overview: true, episodeCount: true, isIndexable: true } });
      for (const se of seasons) {
        const eps = await prisma.episode.findMany({ where: { seasonId: se.id }, select: { id: true, overview: true, stillPath: true, hasPage: true, isIndexable: true } });
        let anyPage = false;
        for (const e of eps) {
          const hasPage = episodeHasPage(e, t.popularity, s);
          anyPage ||= hasPage;
          const ei = hasPage && idx;
          if (hasPage !== e.hasPage || ei !== e.isIndexable) { await prisma.episode.update({ where: { id: e.id }, data: { hasPage, isIndexable: ei } }); changed++; }
        }
        const si = seasonIndexable(idx, se, anyPage);
        if (si !== se.isIndexable) { await prisma.season.update({ where: { id: se.id }, data: { isIndexable: si } }); changed++; }
      }
    }
  }

  for (let after = 0; ;) {
    const rows = await prisma.person.findMany({ where: { id: { gt: after } }, orderBy: { id: "asc" }, take: batch,
      select: { id: true, hidden: true, removedAt: true, indexOverride: true, adult: true, profilePath: true, creditCount: true, isIndexable: true } });
    if (!rows.length) break;
    after = rows[rows.length - 1].id;
    const flip = rows.filter((r) => personIndexable(r, s) !== r.isIndexable);
    for (const r of flip) await prisma.person.update({ where: { id: r.id }, data: { isIndexable: !r.isIndexable } });
    changed += flip.length;
  }
  return { changed };
}
