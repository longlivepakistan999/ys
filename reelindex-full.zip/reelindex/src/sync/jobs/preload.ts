import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { tmdb } from "@/lib/tmdb/client";
import type { TmdbListItem, TmdbPaged } from "@/lib/tmdb/types";
import { enqueueMany, PRIORITY, sealRun } from "../queue";

/**
 * Preload (needs doc §9): fetch full details ahead of time for US-made movies
 * released since 2010. Discover returns at most 500 pages, so the range is
 * walked month by month; a month never comes close to that cap.
 */
export async function runPreload(runId: number) {
  const { preloadScope } = await getSettings();
  if (preloadScope === "NONE") return sealRun(runId);

  const now = new Date();
  let total = 0;
  for (let y = preloadScope === "ALL" ? 1900 : 2010; y <= now.getUTCFullYear(); y++) {
    for (let mth = 0; mth < 12; mth++) {
      const start = new Date(Date.UTC(y, mth, 1));
      if (start > now) break;
      const end = new Date(Date.UTC(y, mth + 1, 0));
      const ids: number[] = [];
      for (let page = 1; page <= 500; page++) {
        const res = await tmdb<TmdbPaged<TmdbListItem>>("/discover/movie", {
          ...(preloadScope === "US_2010" ? { with_origin_country: "US" } : {}),
          "primary_release_date.gte": start.toISOString().slice(0, 10),
          "primary_release_date.lte": end.toISOString().slice(0, 10),
          include_adult: false, include_video: false, sort_by: "popularity.desc", page,
        });
        if (!res) break;
        ids.push(...res.results.map((r) => r.id));
        if (page >= res.total_pages) break;
      }
      // Skip what is already cached
      const have = new Set((await prisma.movie.findMany({ where: { id: { in: ids }, detailSyncedAt: { not: null } }, select: { id: true } })).map((x) => x.id));
      total += await enqueueMany("movie", ids.filter((id) => !have.has(id)), { runId, priority: PRIORITY.preload });
    }
  }
  await prisma.syncRun.update({ where: { id: runId }, data: { note: `preload ${preloadScope}: ${total} movies queued` } });
  await sealRun(runId);
}
