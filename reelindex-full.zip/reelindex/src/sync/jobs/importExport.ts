import { prisma } from "@/lib/db";
import { readExport, type ExportType } from "@/lib/tmdb/exports";

/**
 * Imports one TMDB daily export in chunks:
 *  - inserts ids we have never seen (name + popularity only; details come later)
 *  - refreshes popularity for ids we already have
 *  - marks ids that disappeared from TMDB as removed (pages then return 410)
 * Memory stays flat: rows are processed 10,000 at a time and "seen" ids are
 * tracked in a bitmap.
 */
const TABLES: Record<ExportType, { table: string; insertCols: string; hasPopularity: boolean }> = {
  movie: { table: `"Movie"`, insertCols: `id, title, "originalTitle", popularity, "updatedAt"`, hasPopularity: true },
  tv_series: { table: `"TvShow"`, insertCols: `id, name, "originalName", popularity, "updatedAt"`, hasPopularity: true },
  person: { table: `"Person"`, insertCols: `id, name, popularity, "updatedAt"`, hasPopularity: true },
  collection: { table: `"Collection"`, insertCols: `id, name, "updatedAt"`, hasPopularity: false },
};

class Bitmap {
  private bits = new Uint8Array(1 << 20);
  count = 0;
  set(n: number) {
    const i = n >>> 3;
    if (i >= this.bits.length) { const b = new Uint8Array(Math.max(this.bits.length * 2, i + 1)); b.set(this.bits); this.bits = b; }
    const m = 1 << (n & 7);
    if (!(this.bits[i] & m)) { this.bits[i] |= m; this.count++; }
  }
  has(n: number) { const i = n >>> 3; return i < this.bits.length && (this.bits[i] & (1 << (n & 7))) !== 0; }
}

export interface ImportResult {
  type: ExportType;
  seen: number;
  inserted: { id: number; popularity: number }[];
  removed: number;
  firstImport: boolean;
}

export async function importExport(type: ExportType): Promise<ImportResult> {
  const t = TABLES[type];
  const [{ n: before }] = await prisma.$queryRawUnsafe<{ n: bigint }[]>(`SELECT count(*)::bigint AS n FROM ${t.table} WHERE "removedAt" IS NULL`);
  const firstImport = Number(before) === 0;
  const seen = new Bitmap();
  const inserted: { id: number; popularity: number }[] = [];
  let buf: { id: number; name: string; popularity: number }[] = [];

  const flush = async () => {
    if (!buf.length) return;
    const ids = buf.map((r) => r.id);
    const names = buf.map((r) => r.name || `#${r.id}`);
    const pops = buf.map((r) => r.popularity);
    const values =
      type === "collection" ? `SELECT u.id, u.name, now() FROM unnest($1::int[], $2::text[]) AS u(id, name)`
      : type === "person" ? `SELECT u.id, u.name, u.p, now() FROM unnest($1::int[], $2::text[], $3::float8[]) AS u(id, name, p)`
      : `SELECT u.id, u.name, u.name, u.p, now() FROM unnest($1::int[], $2::text[], $3::float8[]) AS u(id, name, p)`;
    const params = type === "collection" ? [ids, names] : [ids, names, pops];
    const rows = await prisma.$queryRawUnsafe<{ id: number }[]>(
      `INSERT INTO ${t.table} (${t.insertCols}) ${values} ON CONFLICT (id) DO NOTHING RETURNING id`, ...params,
    );
    const pop = new Map(buf.map((r) => [r.id, r.popularity]));
    for (const r of rows) inserted.push({ id: r.id, popularity: pop.get(r.id) ?? 0 });
    if (t.hasPopularity) {
      await prisma.$executeRawUnsafe(
        `UPDATE ${t.table} AS t SET popularity = u.p FROM unnest($1::int[], $2::float8[]) AS u(id, p)
         WHERE t.id = u.id AND t.popularity IS DISTINCT FROM u.p`, ids, pops,
      );
    }
    buf = [];
  };

  for await (const row of readExport(type)) {
    if (row.adult || row.video) continue;
    seen.set(row.id);
    buf.push(row);
    if (buf.length >= 10_000) await flush();
  }
  await flush();

  // Removal: only trust a complete-looking file (guards against truncated downloads).
  let removed = 0;
  if (!firstImport && seen.count >= Number(before) * 0.9) {
    let after = 0;
    for (;;) {
      const page = await prisma.$queryRawUnsafe<{ id: number }[]>(
        `SELECT id FROM ${t.table} WHERE "removedAt" IS NULL AND id > $1 ORDER BY id LIMIT 50000`, after,
      );
      if (!page.length) break;
      after = page[page.length - 1].id;
      const gone = page.filter((r) => !seen.has(r.id)).map((r) => r.id);
      if (gone.length) {
        removed += await prisma.$executeRawUnsafe(
          `UPDATE ${t.table} SET "removedAt" = now(), "isIndexable" = false WHERE id = ANY($1::int[])`, gone,
        );
      }
    }
  }

  inserted.sort((a, b) => b.popularity - a.popularity);
  return { type, seen: seen.count, inserted, removed, firstImport };
}
