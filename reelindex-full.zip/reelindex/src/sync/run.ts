import { prisma } from "@/lib/db";
import { redis } from "@/lib/redis";
import { apiCallStats } from "@/lib/tmdb/client";
import { notify } from "@/lib/notify/telegram";
import { pushIndexNow, purgeCloudflare, revalidatePaths } from "@/lib/publish";
import { clearRunKeys } from "./queue";
import type { RefreshResult } from "./refresh/types";

const pathsKey = (runId: number) => `run:${runId}:paths`;

export async function startRun(kind: "daily" | "rotation" | "preload" | "manual", note?: string) {
  const run = await prisma.syncRun.create({ data: { kind, note } });
  await redis().set(`run:${run.id}:calls0`, String((await apiCallStats()).calls), "EX", 60 * 60 * 48);
  return run.id;
}

export async function recordResult(runId: number, type: string, r: RefreshResult) {
  const data: Record<string, { increment: number }> = {};
  if (r.status === "created" && type === "movie") data.newMovies = { increment: 1 };
  else if (r.status === "created" && type === "tv") data.newShows = { increment: 1 };
  else if (r.status === "updated") data.updated = { increment: 1 };
  if (r.newSeasons) data.newSeasons = { increment: r.newSeasons };
  if (r.newEpisodes) data.newEpisodes = { increment: r.newEpisodes };
  if (Object.keys(data).length) await prisma.syncRun.update({ where: { id: runId }, data });
  if (r.paths.length) {
    await redis().sadd(pathsKey(runId), ...r.paths);
    await redis().expire(pathsKey(runId), 60 * 60 * 48);
  }
}

export async function recordFailure(runId: number | undefined, type: string, tmdbId: number, reason: string) {
  await prisma.syncFailure.upsert({
    where: { type_tmdbId: { type, tmdbId } },
    create: { type, tmdbId, reason: reason.slice(0, 500), attempts: 5, runId },
    update: { reason: reason.slice(0, 500), attempts: { increment: 5 }, runId },
  });
  if (runId) await prisma.syncRun.update({ where: { id: runId }, data: { failed: { increment: 1 } } });
}

/** Publish everything the run changed, close it, and send the Telegram summary. */
export async function finishRun(runId: number) {
  const run = await prisma.syncRun.findUnique({ where: { id: runId } });
  if (!run || run.finishedAt) return;
  const changed = await redis().smembers(pathsKey(runId));
  const revalidated = await revalidatePaths(changed);
  await purgeCloudflare(changed);
  const pushed = await pushIndexNow(changed);
  const calls0 = Number((await redis().get(`run:${runId}:calls0`)) || 0);
  const apiCalls = Math.max(0, (await apiCallStats()).calls - calls0);
  const status = run.failed > 0 ? "partial" : "ok";
  const done = await prisma.syncRun.update({
    where: { id: runId },
    data: { finishedAt: new Date(), status, urlsPushed: pushed, apiCalls },
  });
  await clearRunKeys(runId);

  const mins = Math.round((done.finishedAt!.getTime() - done.startedAt.getTime()) / 60000);
  const text =
    `${status === "ok" ? "✅" : "⚠️"} Sync #${runId} (${done.kind}) finished in ${mins} min\n` +
    `New: ${done.newMovies} movies · ${done.newShows} shows · ${done.newSeasons} seasons · ${done.newEpisodes} episodes\n` +
    `Updated: ${done.updated} · Failed: ${done.failed}\n` +
    `Pages refreshed: ${revalidated} · IndexNow: ${pushed} · API calls: ${apiCalls}`;
  if (status === "ok") await notify("dailySummary", text);
  else await notify("syncFailed", text);
}

export async function failRun(runId: number, err: unknown) {
  const msg = err instanceof Error ? err.message : String(err);
  await prisma.syncRun.update({ where: { id: runId }, data: { status: "failed", finishedAt: new Date(), error: msg.slice(0, 1000) } });
  await clearRunKeys(runId);
  await notify("syncFailed", `❌ Sync #${runId} failed: ${msg.slice(0, 300)}`);
}
