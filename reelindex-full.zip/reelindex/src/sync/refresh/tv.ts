import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { slugify, paths } from "@/lib/slug";
import { tmdb } from "@/lib/tmdb/client";
import { providerKeys, toDate, trimEpisode, trimTv, yearOf } from "@/lib/tmdb/trim";
import type { TmdbSeason, TmdbTv } from "@/lib/tmdb/types";
import { episodeHasPage, seasonIndexable, titleIndexable } from "@/lib/seo/indexable";
import type { RefreshResult } from "./types";

/**
 * Refresh a show, then only the seasons that need it:
 *  - a season TMDB lists that we don't have yet          → new season, fetch all episodes
 *  - a season whose episode count changed                 → new episodes, fetch the season
 *  - the latest season (titles and overviews get filled in after airing)
 *  - every season when `force` (6-month rotation, manual refresh)
 */
export async function refreshTv(id: number, opts: { force?: boolean } = {}): Promise<RefreshResult> {
  const t = await tmdb<TmdbTv>(`/tv/${id}`, { append_to_response: "credits,watch/providers,recommendations,content_ratings" });
  const prev = await prisma.tvShow.findUnique({
    where: { id },
    select: { slug: true, detail: true, hidden: true, indexOverride: true, seasons: { select: { seasonNumber: true, episodeCount: true, syncedAt: true } } },
  });

  if (!t) {
    if (prev) await prisma.tvShow.update({ where: { id }, data: { removedAt: new Date(), isIndexable: false } });
    return { status: "removed", paths: prev ? [paths.tv(id, prev.slug)] : [] };
  }

  const s = await getSettings();
  const slug = slugify(t.name) || slugify(t.original_name);
  const detail = trimTv(t);
  const base = {
    name: t.name || t.original_name,
    originalName: t.original_name,
    overview: t.overview || null,
    slug,
    firstAirDate: toDate(t.first_air_date),
    lastAirDate: toDate(t.last_air_date),
    firstAirYear: yearOf(t.first_air_date),
    status: t.status,
    numberOfSeasons: t.number_of_seasons,
    numberOfEpisodes: t.number_of_episodes,
    lastEpisodeAirDate: toDate(t.last_episode_to_air?.air_date),
    nextEpisodeAirDate: toDate(t.next_episode_to_air?.air_date),
    genres: t.genres.map((g) => g.id),
    countries: t.origin_country ?? [],
    networks: t.networks.map((n) => n.name),
    language: t.original_language,
    rating: Math.round(t.vote_average * 10) / 10,
    voteCount: t.vote_count,
    popularity: t.popularity,
    posterPath: t.poster_path,
    backdropPath: t.backdrop_path,
    adult: !!t.adult,
    isTracking: !s.stopTrackingStatuses.includes(t.status),
    providers: providerKeys(detail.providers),
    detail: detail as object,
    detailSyncedAt: new Date(),
    removedAt: null,
  };
  const showIndexable = titleIndexable({
    hidden: prev?.hidden ?? false, indexOverride: prev?.indexOverride, adult: base.adult,
    overview: base.overview, posterPath: base.posterPath, voteCount: base.voteCount,
  }, s);
  await prisma.tvShow.upsert({ where: { id }, create: { id, ...base, isIndexable: showIndexable }, update: { ...base, isIndexable: showIndexable } });

  const showPath = paths.tv(id, slug);
  const changed: string[] = [showPath];
  if (prev && prev.slug !== slug) changed.push(paths.tv(id, prev.slug));

  const known = new Map((prev?.seasons ?? []).map((x) => [x.seasonNumber, x]));
  const latest = Math.max(0, ...t.seasons.filter((x) => x.season_number > 0).map((x) => x.season_number));
  let newSeasons = 0;
  let newEpisodes = 0;

  for (const sm of t.seasons) {
    const old = known.get(sm.season_number);
    const needs = opts.force || !old || !old.syncedAt || old.episodeCount !== sm.episode_count || sm.season_number === latest;
    if (!needs) continue;

    const sd = await tmdb<TmdbSeason>(`/tv/${id}/season/${sm.season_number}`);
    if (!sd) continue;
    if (!old) newSeasons++;

    const before = new Set(
      (await prisma.episode.findMany({ where: { showId: id, seasonNumber: sm.season_number }, select: { id: true } })).map((e) => e.id),
    );
    const episodes = sd.episodes.map((e) => {
      const hasPage = episodeHasPage({ overview: e.overview, stillPath: e.still_path }, base.popularity, s);
      return {
        id: e.id, showId: id, seasonId: sd.id, seasonNumber: sm.season_number, episodeNumber: e.episode_number,
        name: e.name || null, overview: e.overview || null, airDate: toDate(e.air_date), runtime: e.runtime || null,
        stillPath: e.still_path, rating: Math.round((e.vote_average ?? 0) * 10) / 10, voteCount: e.vote_count ?? 0,
        detail: trimEpisode(e) as object, hasPage, isIndexable: hasPage && showIndexable,
      };
    });
    const seasonData = {
      showId: id, seasonNumber: sm.season_number, name: sd.name || null, overview: sd.overview || null,
      episodeCount: sd.episodes.length, airDate: toDate(sd.air_date), posterPath: sd.poster_path,
      isIndexable: seasonIndexable(showIndexable, { overview: sd.overview, episodeCount: sd.episodes.length }, episodes.some((e) => e.hasPage)),
      syncedAt: new Date(),
    };

    // Episodes carry no admin edits, so the season's episodes are replaced as a set.
    // This also handles TMDB renumbering episodes within a season.
    await prisma.$transaction([
      prisma.season.deleteMany({ where: { showId: id, seasonNumber: sm.season_number, NOT: { id: sd.id } } }),
      prisma.season.upsert({ where: { id: sd.id }, create: { id: sd.id, ...seasonData }, update: seasonData }),
      prisma.episode.deleteMany({ where: { showId: id, seasonNumber: sm.season_number } }),
      prisma.episode.createMany({ data: episodes, skipDuplicates: true }),
    ]);

    changed.push(paths.season(id, slug, sm.season_number));
    for (const e of episodes) {
      const isNew = !before.has(e.id);
      if (isNew) newEpisodes++;
      if (e.hasPage && (isNew || opts.force || sm.season_number === latest)) changed.push(paths.episode(id, slug, sm.season_number, e.episodeNumber));
    }
  }

  // Seasons TMDB no longer lists
  const listed = t.seasons.map((x) => x.season_number);
  await prisma.season.deleteMany({ where: { showId: id, seasonNumber: { notIn: listed } } });

  return { status: prev?.detail ? "updated" : "created", paths: changed, indexable: showIndexable, newSeasons, newEpisodes };
}
