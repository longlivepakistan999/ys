import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { slugify, paths } from "@/lib/slug";
import { tmdb } from "@/lib/tmdb/client";
import { providerKeys, toDate, trimMovie, yearOf } from "@/lib/tmdb/trim";
import type { TmdbMovie } from "@/lib/tmdb/types";
import { titleIndexable } from "@/lib/seo/indexable";
import type { RefreshResult } from "./types";

/** Fetch one movie with everything its page needs in a single API call, then upsert. */
export async function refreshMovie(id: number): Promise<RefreshResult> {
  const m = await tmdb<TmdbMovie>(`/movie/${id}`, { append_to_response: "credits,watch/providers,recommendations,similar,release_dates" });
  const prev = await prisma.movie.findUnique({
    where: { id }, select: { slug: true, year: true, detail: true, hidden: true, indexOverride: true },
  });

  if (!m) {
    if (prev) await prisma.movie.update({ where: { id }, data: { removedAt: new Date(), isIndexable: false } });
    return { status: "removed", paths: prev ? [paths.movie(id, prev.slug, prev.year)] : [] };
  }

  const s = await getSettings();
  const year = yearOf(m.release_date);
  const slug = slugify(m.title) || slugify(m.original_title);
  const detail = trimMovie(m);
  const countries = m.origin_country?.length ? m.origin_country : m.production_countries.map((c) => c.iso_3166_1);
  const base = {
    title: m.title || m.original_title,
    originalTitle: m.original_title,
    overview: m.overview || null,
    slug, year,
    releaseDate: toDate(m.release_date),
    runtime: m.runtime || null,
    genres: m.genres.map((g) => g.id),
    countries,
    language: m.original_language,
    rating: Math.round(m.vote_average * 10) / 10,
    voteCount: m.vote_count,
    popularity: m.popularity,
    posterPath: m.poster_path,
    backdropPath: m.backdrop_path,
    collectionId: m.belongs_to_collection?.id ?? null,
    adult: m.adult,
    status: m.status,
    providers: providerKeys(detail.providers),
    detail: detail as object,
    detailSyncedAt: new Date(),
    removedAt: null,
  };
  const isIndexable = titleIndexable({
    hidden: prev?.hidden ?? false, indexOverride: prev?.indexOverride, adult: m.adult,
    overview: base.overview, posterPath: base.posterPath, voteCount: base.voteCount,
  }, s);

  await prisma.movie.upsert({ where: { id }, create: { id, ...base, isIndexable }, update: { ...base, isIndexable } });

  if (m.belongs_to_collection) {
    const c = m.belongs_to_collection;
    await prisma.collection.upsert({
      where: { id: c.id },
      create: { id: c.id, name: c.name, slug: slugify(c.name), posterPath: c.poster_path, backdropPath: c.backdrop_path },
      update: {},
    });
  }

  const url = paths.movie(id, slug, year);
  const out = [url, `${url}/similar`];
  if (prev && (prev.slug !== slug || prev.year !== year)) out.push(paths.movie(id, prev.slug, prev.year));
  return { status: prev?.detail ? "updated" : "created", paths: out, indexable: isIndexable };
}
