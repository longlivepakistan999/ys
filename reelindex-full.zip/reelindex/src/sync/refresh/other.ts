import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { slugify, paths } from "@/lib/slug";
import { tmdb } from "@/lib/tmdb/client";
import { trimCollection, trimPerson } from "@/lib/tmdb/trim";
import type { TmdbCollection, TmdbPerson } from "@/lib/tmdb/types";
import { personIndexable } from "@/lib/seo/indexable";
import type { RefreshResult } from "./types";

export async function refreshPerson(id: number): Promise<RefreshResult> {
  const p = await tmdb<TmdbPerson>(`/person/${id}`, { append_to_response: "combined_credits" });
  const prev = await prisma.person.findUnique({ where: { id }, select: { slug: true, detail: true, hidden: true, indexOverride: true } });
  if (!p) {
    if (prev) await prisma.person.update({ where: { id }, data: { removedAt: new Date(), isIndexable: false } });
    return { status: "removed", paths: prev ? [paths.person(id, prev.slug)] : [] };
  }
  const s = await getSettings();
  const detail = trimPerson(p);
  const slug = slugify(p.name);
  const creditCount = detail.cast.length + detail.crew.length;
  const base = {
    name: p.name, slug, profilePath: p.profile_path, popularity: p.popularity, knownFor: p.known_for_department,
    creditCount, adult: p.adult, detail: detail as object, detailSyncedAt: new Date(), removedAt: null,
  };
  const isIndexable = personIndexable({ hidden: prev?.hidden ?? false, indexOverride: prev?.indexOverride, adult: p.adult, profilePath: p.profile_path, creditCount }, s);
  await prisma.person.upsert({ where: { id }, create: { id, ...base, isIndexable }, update: { ...base, isIndexable } });
  const url = paths.person(id, slug);
  const out = [url, `${url}/movies`];
  if (prev && prev.slug !== slug) out.push(paths.person(id, prev.slug));
  return { status: prev?.detail ? "updated" : "created", paths: out, indexable: isIndexable };
}

export async function refreshCollection(id: number): Promise<RefreshResult> {
  const c = await tmdb<TmdbCollection>(`/collection/${id}`);
  const prev = await prisma.collection.findUnique({ where: { id }, select: { slug: true, detail: true, hidden: true } });
  if (!c) {
    if (prev) await prisma.collection.update({ where: { id }, data: { removedAt: new Date(), isIndexable: false } });
    return { status: "removed", paths: prev ? [paths.collection(id, prev.slug)] : [] };
  }
  const detail = trimCollection(c);
  const slug = slugify(c.name.replace(/\s+collection$/i, ""));
  const base = {
    name: c.name, slug, overview: c.overview || null, posterPath: c.poster_path, backdropPath: c.backdrop_path,
    partCount: detail.parts.length, detail: detail as object, detailSyncedAt: new Date(), removedAt: null,
    isIndexable: !(prev?.hidden) && detail.parts.length >= 2,
  };
  await prisma.collection.upsert({ where: { id }, create: { id, ...base }, update: base });
  return { status: prev?.detail ? "updated" : "created", paths: [paths.collection(id, slug)], indexable: base.isIndexable };
}
