export interface RefreshResult {
  status: "created" | "updated" | "removed" | "skipped";
  /** Site paths whose cached HTML is now stale */
  paths: string[];
  indexable?: boolean;
  newSeasons?: number;
  newEpisodes?: number;
}
