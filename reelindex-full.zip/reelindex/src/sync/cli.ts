/**
 * Manual commands (the worker must be running for queued jobs):
 *   npm run sync -- init                 first setup: genres + ID exports + preload
 *   npm run sync -- daily                queue the daily run now
 *   npm run sync -- preload              queue the US-2010+ movie preload
 *   npm run sync -- rotation             queue today's 6-month rotation batch
 *   npm run sync -- refresh movie 550    refresh one title right now (inline, prints result)
 *   npm run sync -- genres               refresh genre list
 *   npm run sync -- seed                 create the default ad slots (all switched off)
 *   npm run sync -- admin <user> <pass>  create the admin account, or reset its password (turns off 2FA)
 */
import { prisma } from "@/lib/db";
import { getAccount, saveAccount } from "@/lib/admin/account";
import { hashPassword } from "@/lib/admin/crypto";
import { queue, sealRun } from "./queue";
import { startRun } from "./run";
import { importExport } from "./jobs/importExport";
import { syncGenres } from "./jobs/genres";
import { enqueueRotation } from "./jobs/rotation";
import { refreshMovie } from "./refresh/movie";
import { refreshTv } from "./refresh/tv";
import { refreshCollection, refreshPerson } from "./refresh/other";

async function main() {
  const [cmd, a, b] = process.argv.slice(2);
  switch (cmd) {
    case "init": {
      console.log("genres:", await syncGenres());
      for (const t of ["movie", "tv_series", "person", "collection"] as const) {
        const r = await importExport(t);
        console.log(`${t}: ${r.seen} ids, ${r.inserted.length} inserted`);
      }
      const runId = await startRun("preload", "initial preload");
      await queue().add("preload", { type: "preload", runId }, { jobId: `preload-${runId}`, removeOnComplete: true });
      console.log(`preload queued as run #${runId}; start the worker to process it`);
      break;
    }
    case "daily":
      await queue().add("daily", { type: "daily" }, { removeOnComplete: true });
      console.log("daily run queued");
      break;
    case "preload": {
      const runId = await startRun("preload");
      await queue().add("preload", { type: "preload", runId }, { jobId: `preload-${runId}`, removeOnComplete: true });
      console.log(`preload queued as run #${runId}`);
      break;
    }
    case "rotation": {
      const runId = await startRun("rotation");
      console.log(await enqueueRotation(runId));
      await sealRun(runId);
      break;
    }
    case "refresh": {
      const id = Number(b);
      if (!a || !Number.isInteger(id)) throw new Error("usage: refresh <movie|tv|person|collection> <tmdbId>");
      const r = a === "movie" ? await refreshMovie(id) : a === "tv" ? await refreshTv(id, { force: true })
        : a === "person" ? await refreshPerson(id) : await refreshCollection(id);
      console.log(JSON.stringify(r, null, 2));
      break;
    }
    case "genres":
      console.log("genres:", await syncGenres());
      break;
    case "seed": {
      const slots = [
        { key: "content-mid", label: "Content middle", desktopW: 728, desktopH: 90, pageTypes: ["movie", "tv", "person"] },
        { key: "content-bottom", label: "Content bottom", desktopW: 728, desktopH: 90, pageTypes: ["season", "episode", "list", "similar", "collection", "watch"] },
        { key: "sidebar", label: "Sidebar", desktopW: 300, desktopH: 250, mobileW: 300, mobileH: 250, pageTypes: ["movie", "tv", "season", "episode"] },
      ];
      for (const s of slots) await prisma.adSlot.upsert({ where: { key: s.key }, create: s, update: {} });
      console.log(`${slots.length} ad slots ready (switched off until code is added in the admin)`);
      break;
    }
    case "admin": {
      if (!a || !b || b.length < 12) throw new Error("usage: admin <username> <password>  (password at least 12 characters)");
      const prev = await getAccount();
      await saveAccount({ username: a, passwordHash: await hashPassword(b), totpSecret: null, totpEnabled: false, sessionVersion: (prev?.sessionVersion ?? 0) + 1, pendingTotpSecret: null });
      console.log(`admin account "${a}" ${prev ? "reset (two-factor turned off, all sessions signed out)" : "created"}`);
      break;
    }
    default:
      console.log("commands: init | seed | admin <user> <pass> | daily | preload | rotation | refresh <type> <id> | genres");
  }
}

main()
  .catch((err) => { console.error(err); process.exitCode = 1; })
  .finally(async () => { await prisma.$disconnect(); await queue().close(); process.exit(); });
