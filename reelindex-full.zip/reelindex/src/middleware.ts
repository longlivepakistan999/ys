import { NextResponse, type NextRequest } from "next/server";
import { COOKIE, verifySession } from "@/lib/admin/session";

/**
 * Admin protection and the customizable admin path.
 * The admin routes live under /admin; with ADMIN_PATH=my-secret-panel the
 * public URL becomes /my-secret-panel/... and /admin itself returns 404.
 * Every admin URL except the login page needs a valid session cookie.
 * (Pages and actions check the session again on the server.)
 */
export async function middleware(req: NextRequest) {
  const base = (process.env.ADMIN_PATH || "admin").replace(/^\/+|\/+$/g, "");
  const { pathname } = req.nextUrl;
  const isPublicAdmin = pathname === `/${base}` || pathname.startsWith(`/${base}/`);
  const isInternal = pathname === "/admin" || pathname.startsWith("/admin/");

  if (base !== "admin" && isInternal && !isPublicAdmin) {
    return NextResponse.rewrite(new URL("/__not-found", req.url));
  }
  if (!isPublicAdmin) return NextResponse.next();

  const rest = pathname.slice(base.length + 1) || "/";
  const internal = new URL(`/admin${rest === "/" ? "" : rest}${req.nextUrl.search}`, req.url);
  const res = rest === "/login" ? null : await verifySession(req.cookies.get(COOKIE)?.value).catch(() => null);
  if (rest !== "/login" && !res) {
    return NextResponse.redirect(new URL(`/${base}/login`, req.url));
  }
  const out = base === "admin" ? NextResponse.next() : NextResponse.rewrite(internal);
  out.headers.set("x-robots-tag", "noindex, nofollow");
  out.headers.set("cache-control", "no-store");
  return out;
}

export const config = {
  // Skip static files and Next internals
  matcher: ["/((?!_next/|favicon|api/|sitemap|sitemaps/|robots.txt|indexnow-key.txt).*)"],
};
