import Link from "next/link";
import { cache } from "react";
import { permanentRedirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { ensureDetail } from "@/lib/data/ensure";
import { movieLinks, tvLinks } from "@/lib/data/queries";
import { idFromSegment, paths } from "@/lib/slug";
import { missing } from "@/lib/route";
import { fillTemplate, getSettings } from "@/lib/settings";
import { buildMeta } from "@/lib/seo/meta";
import { breadcrumbLd, JsonLd } from "@/lib/seo/jsonld";
import { fmtDate, getSite, img } from "@/lib/site";
import type { trimPerson } from "@/lib/tmdb/trim";
import { Ad } from "@/components/Ad";
import { Crumbs, Facts, Grid, Section, hue } from "@/components/ui";

type PersonDetail = ReturnType<typeof trimPerson>;
type Credit = PersonDetail["cast"][number];

const age = (birth: string | null, death: string | null) => {
  if (!birth) return null;
  const b = new Date(birth + "T00:00:00Z"), e = death ? new Date(death + "T00:00:00Z") : new Date();
  let a = e.getUTCFullYear() - b.getUTCFullYear();
  if (e.getUTCMonth() < b.getUTCMonth() || (e.getUTCMonth() === b.getUTCMonth() && e.getUTCDate() < b.getUTCDate())) a--;
  return a;
};

const loadPerson = cache(async (segment: string, suffix: string) => {
  const id = idFromSegment(segment);
  if (!id) return missing(`/person/${segment}${suffix}`);
  try { await ensureDetail("person", id); } catch { /* cached data */ }
  const p = await prisma.person.findUnique({ where: { id } });
  if (!p || p.removedAt || p.hidden || p.adult || !p.detail) return missing(`/person/${segment}${suffix}`);
  const canonical = paths.person(p.id, p.slug);
  if (`/person/${segment}` !== canonical) permanentRedirect(canonical + suffix);
  const d = p.detail as unknown as PersonDetail;
  // One row per title (an actor can have several roles in one show)
  const credits = new Map<string, Credit>();
  for (const c of [...d.cast, ...d.crew]) { const k = `${c.type}${c.id}`; if (!credits.has(k)) credits.set(k, c); }
  const all = [...credits.values()];
  const movies = all.filter((c) => c.type === "movie");
  const [mLinks, tLinks] = await Promise.all([movieLinks(movies.map((c) => c.id)), tvLinks(all.filter((c) => c.type === "tv").map((c) => c.id))]);
  const href = (c: Credit) => (c.type === "movie" ? mLinks.get(c.id) ?? `/movie/${c.id}` : tLinks.get(c.id) ?? `/tv/${c.id}`);
  return { p, d, canonical, all, movies, href };
});

export async function personMetadata(segment: string) {
  const { p, d, canonical, all } = await loadPerson(segment, "");
  const s = await getSettings();
  const top = [...all].sort((a, b) => b.votes - a.votes).slice(0, 2).map((c) => c.title);
  const latest = [...all].filter((c) => c.year).sort((a, b) => (b.year ?? 0) - (a.year ?? 0))[0];
  return buildMeta({
    title: fillTemplate(s.seoTemplates.person, { name: p.name }), path: canonical, index: p.isIndexable, ogType: "profile", image: img(p.profilePath, "h632"),
    description: `${p.name}${d.birthday ? ` (born ${fmtDate(d.birthday)})` : ""}: biography and full filmography${top.length ? `, from ${top.join(" and ")}` : ""}${latest ? ` to ${latest.title} (${latest.year})` : ""}, with ratings and where to watch.`,
  });
}

export async function PersonPage({ segment }: { segment: string }) {
  const { p, d, canonical, all, movies, href } = await loadPerson(segment, "");
  const site = await getSite();
  const known = [...all].filter((c) => c.poster).sort((a, b) => b.votes - a.votes).slice(0, 6);
  const rows = [...all].sort((a, b) => (b.year ?? 9999) - (a.year ?? 9999));
  const crumbs: [string, string][] = [["Home", "/"], [p.name, canonical]];
  const nMovies = movies.length, nTv = all.length - nMovies;
  const best = [...all].filter((c) => c.votes >= 500).sort((a, b) => b.rating - a.rating).slice(0, 2).map((c) => c.title);
  const latest = rows.find((c) => c.year && c.year <= new Date().getUTCFullYear());
  return (
    <div className="wrap">
      <JsonLd data={[{
        "@context": "https://schema.org", "@type": "Person", name: p.name, url: site.url + canonical,
        ...(p.profilePath ? { image: img(p.profilePath, "h632") } : {}), ...(d.birthday ? { birthDate: d.birthday } : {}),
        ...(d.deathday ? { deathDate: d.deathday } : {}), ...(d.placeOfBirth ? { birthPlace: d.placeOfBirth } : {}), ...(d.department ? { jobTitle: d.department === "Acting" ? "Actor" : d.department } : {}),
      }, breadcrumbLd(site.url, crumbs)]} />
      <Crumbs items={crumbs} />
      <div className="detail" style={{ gridTemplateColumns: "260px minmax(0,1fr)" }}>
        <aside className="side" style={{ paddingTop: 12 }} aria-label="Personal info">
          <div className={`portrait${p.profilePath ? " has-img" : ""}`} style={{ ["--h" as string]: hue(p.name) }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            {p.profilePath && <img src={img(p.profilePath, "h632")!} alt={p.name} width={421} height={632} />}
            <span>{p.name.split(/\s+/).slice(0, 2).map((w) => w[0]).join("")}</span>
          </div>
          <div className="side-block"><h2>Personal info</h2>
            <Facts rows={[
              ["Known for", d.department], ["Born", d.birthday ? `${fmtDate(d.birthday)}${!d.deathday ? ` (age ${age(d.birthday, null)})` : ""}` : null],
              ["Died", d.deathday ? `${fmtDate(d.deathday)} (age ${age(d.birthday, d.deathday)})` : null], ["Birthplace", d.placeOfBirth],
              ["Credits", `${nMovies} movies · ${nTv} TV`],
            ]} />
          </div>
        </aside>
        <div>
          <div className="page-head" style={{ paddingTop: 12 }}><div><span className="eyebrow">{d.department}</span><h1 className="page-title">{p.name}</h1></div></div>
          <section className="prose">
            {d.biography && d.biography.split(/\n+/).slice(0, 4).map((para, i) => <p key={i}>{para}</p>)}
            <p className="auto-summary">{p.name} has {nMovies} movie and {nTv} TV credits.{best.length ? ` The highest rated include ${best.join(" and ")}.` : ""}{latest ? ` The most recent is ${latest.title} (${latest.year}).` : ""}</p>
          </section>
          {known.length > 0 && (
            <Section title="Known For" link={nMovies ? [`All ${p.name} movies`, `${canonical}/movies`] : undefined}>
              <Grid items={known.map((c) => ({ key: `${c.type}${c.id}`, href: href(c), title: c.title, poster: c.poster, year: c.year ? String(c.year) : "", rating: c.rating || null }))} />
            </Section>
          )}
          <Ad slot="content-mid" page="person" />
          <Section title="Filmography" count={`${rows.length} credits`}>
            <div className="film-table-wrap">
              <table className="film-table">
                <thead><tr><th>Year</th><th>Title</th><th>Role</th><th>Type</th></tr></thead>
                <tbody>{rows.map((c) => <tr key={`${c.type}${c.id}`}><td>{c.year ?? "—"}</td><td><Link href={href(c)}>{c.title}</Link></td><td className="muted">{c.role}</td><td className="muted">{c.type === "movie" ? "Movie" : "TV"}</td></tr>)}</tbody>
              </table>
            </div>
          </Section>
        </div>
      </div>
    </div>
  );
}

export async function personMoviesMetadata(segment: string) {
  const { p, canonical, movies } = await loadPerson(segment, "/movies");
  const s = await getSettings();
  return buildMeta({
    title: `${p.name} Movies – All ${movies.length} Films by Year`, path: `${canonical}/movies`, index: p.isIndexable && movies.length >= s.minListSize / 2,
    description: `Every ${p.name} movie in order, newest first, with roles, ratings and where to watch.`,
  });
}

export async function PersonMoviesPage({ segment }: { segment: string }) {
  const { p, canonical, movies, href } = await loadPerson(segment, "/movies");
  const site = await getSite();
  const path = `${canonical}/movies`;
  const crumbs: [string, string][] = [["Home", "/"], [p.name, canonical], ["Movies", path]];
  const decades = new Map<number, Credit[]>();
  for (const c of movies) { const k = c.year ? Math.floor(c.year / 10) * 10 : 0; decades.set(k, [...(decades.get(k) ?? []), c]); }
  const order = [...decades.keys()].sort((a, b) => b - a);
  return (
    <div className="wrap">
      <JsonLd data={breadcrumbLd(site.url, crumbs)} />
      <Crumbs items={crumbs} />
      <div className="page-head"><div><span className="eyebrow">Filmography</span><h1 className="page-title">{p.name} Movies</h1>
        <p className="page-sub">Every film {p.name} has worked on, newest first.</p></div><span className="count">{movies.length} movies</span></div>
      {order.map((dec) => {
        const list = decades.get(dec)!.sort((a, b) => (b.year ?? 0) - (a.year ?? 0));
        return (
          <section key={dec}>
            <h2 className="year-head">{dec ? `${dec}s` : "Undated"} <span>{list.length} films</span></h2>
            <Grid items={list.map((c) => ({ key: `${c.id}`, href: href(c), title: c.title, poster: c.poster, year: c.year ? String(c.year) : "", rating: c.rating || null, meta: c.role || undefined }))} />
          </section>
        );
      })}
    </div>
  );
}
