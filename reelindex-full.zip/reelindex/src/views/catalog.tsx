/**
 * Shared logic for /movies/... and /tv/... list routes:
 *   /movies                         catalog
 *   /movies/page/N
 *   /movies/{genre}                 genre (all years)     /movies/all/{year}   year (all genres)
 *   /movies/{genre}/{year}          genre + year (+ /page/N)
 *   /movies/{provider}              platform (US)         /movies/{provider}/{uk|ca|au|nz|ie}
 *   /movies/upcoming/{y}/{m}        release calendar (movies only)
 *   /tv/airing-today                episodes airing today (tv only)
 */
import type { Metadata } from "next";
import { permanentRedirect } from "next/navigation";
import { listMovies, listTv } from "@/lib/data/queries";
import { genreBySlug, genresFor } from "@/lib/genres";
import { countrySlug, countryName } from "@/lib/countries";
import { providerBySlug, REGION_NAMES, REGION_SLUGS } from "@/lib/providers";
import { getSettings, fillTemplate } from "@/lib/settings";
import { buildMeta } from "@/lib/seo/meta";
import { fmtInt, listJoin } from "@/lib/site";
import { guardPage, missing, splitPage } from "@/lib/route";
import { FilterForm } from "@/components/FilterForm";
import { ListPage, YearPills } from "./ListPage";
import Link from "next/link";

type Kind = "movies" | "tv";
const COMMON_COUNTRIES = ["US", "GB", "KR", "JP", "FR", "DE", "IN", "ES", "IT", "CA", "CN", "MX", "BR", "TR", "AU"];

export interface CatalogView {
  title: string; description: string; path: string; index: boolean;
  render: () => Promise<React.ReactNode>;
}

export async function resolveCatalog(kind: Kind, segments: string[]): Promise<CatalogView> {
  const s = await getSettings();
  const label = kind === "movies" ? "Movies" : "TV Shows";
  const noun = kind === "movies" ? "movies" : "TV shows";
  const { rest, page } = await splitPage(segments, (r) => `/${[kind, ...r].join("/")}`);
  const list = (f: Parameters<typeof listMovies>[0], sort: Parameters<typeof listMovies>[1] = "popular") => (kind === "movies" ? listMovies(f, sort, page) : listTv(f, sort, page));
  const filterProps = async (current?: { genre?: string; year?: number }) => ({
    kind, current,
    genres: (await genresFor(kind === "movies" ? "movie" : "tv")).map((g) => ({ slug: g.slug, name: g.name })),
    countries: COMMON_COUNTRIES.map((c) => ({ slug: countrySlug(c), name: countryName(c) })),
  });
  const titleFor = (t: string) => (page > 1 ? fillTemplate(s.seoTemplates.page, { list_title: t, page }) : t);

  // ---- Catalog root
  if (rest.length === 0) {
    const r = await list({});
    const base = `/${kind}`;
    await guardPage(page, r.pages, s.maxListPages, base);
    const title = `${label} – Browse by Genre, Year & Rating`;
    return {
      title: titleFor(title), path: page > 1 ? `${base}/page/${page}` : base, index: true,
      description: `Browse ${fmtInt(r.total)} ${noun} by genre, year, country and rating, with cast, ratings and where to watch.`,
      render: async () => (
        <ListPage title={label} page={page} pages={r.pages} total={r.total} perPage={r.perPage} items={r.items} base={base} maxPages={s.maxListPages}
          crumbs={[["Home", "/"], [label, base]]} count={`${fmtInt(r.total)} titles`} adPage="list"
          intro={kind === "movies" ? "Every film in the catalog, most popular first. Filter by genre, year, country or rating." : "Series from every network and streaming service, with full season and episode guides."}
          before={<FilterForm {...await filterProps()} />} />
      ),
    };
  }

  const [a, b, c] = rest;

  // ---- Upcoming calendar → separate view
  if (kind === "movies" && a === "upcoming") {
    if (!b) { const d = new Date(); permanentRedirect(`/movies/upcoming/${d.getUTCFullYear()}/${d.getUTCMonth() + 1}`); }
    return upcomingView(Number(b), Number(c));
  }

  // ---- Platform pages
  const provider = providerBySlug(a);
  if (provider && rest.length <= 2) {
    const regionCode = b ? REGION_SLUGS[b as keyof typeof REGION_SLUGS] : "US";
    if (!regionCode) return missing(`/${kind}/${rest.join("/")}`);
    const r = await list({ provider: `${regionCode}:${provider.id}` });
    const base = `/${kind}/${provider.slug}${b ? `/${b}` : ""}`;
    await guardPage(page, r.pages, s.maxListPages, base);
    const where = REGION_NAMES[regionCode];
    const title = `${label} on ${provider.name}${regionCode === "US" ? "" : ` (${regionCode === "GB" ? "UK" : regionCode})`}`;
    return {
      title: titleFor(`${title} – What to Watch Now`), path: page > 1 ? `${base}/page/${page}` : base, index: r.total >= s.minListSize,
      description: `${fmtInt(r.total)} ${noun} streaming on ${provider.name} in ${where}, most popular first, with ratings and episode guides.`,
      render: async () => (
        <ListPage eyebrow="Streaming service" title={title} page={page} pages={r.pages} total={r.total} perPage={r.perPage} items={r.items} base={base}
          maxPages={s.maxListPages} adPage="list" crumbs={[["Home", "/"], [label, `/${kind}`], [provider.name, base]]}
          intro={`${fmtInt(r.total)} ${noun} are streaming on ${provider.name} in ${where} right now. The list updates daily as titles arrive and leave. Availability data by JustWatch.`}
          before={
            <div className="pills" style={{ marginBottom: 22 }} aria-label="Region">
              <Link className="pill" href={`/${kind}/${provider.slug}`} aria-current={regionCode === "US" ? "page" : undefined}>US</Link>
              {Object.entries(REGION_SLUGS).map(([slug, code]) => (
                <Link key={slug} className="pill" href={`/${kind}/${provider.slug}/${slug}`} aria-current={regionCode === code ? "page" : undefined}>{code === "GB" ? "UK" : code}</Link>
              ))}
            </div>
          } />
      ),
    };
  }

  // ---- Genre / year pages
  if (rest.length > 2) return missing(`/${kind}/${rest.join("/")}`);
  const genre = a === "all" ? null : await genreBySlug(a, kind === "movies" ? "movie" : "tv");
  if (a !== "all" && !genre) return missing(`/${kind}/${rest.join("/")}`);
  const year = b ? Number(b) : undefined;
  if (b && (!/^\d{4}$/.test(b) || year! < 1900 || year! > new Date().getUTCFullYear() + 3)) return missing(`/${kind}/${rest.join("/")}`);
  if (!genre && !year) permanentRedirect(`/${kind}`);

  const r = await list({ genreId: genre?.id, year });
  const base = `/${kind}/${rest.join("/")}`;
  await guardPage(page, r.pages, s.maxListPages, base);
  const gName = genre ? (kind === "movies" ? genre.name : genre.name.replace(/&/g, "and")) : "";
  const listTitle = genre && year ? `Best ${gName} ${label} of ${year}` : genre ? `${gName} ${label}` : `${label} of ${year}`;
  const top = r.rows.slice(0, 3).map((x) => ("title" in x ? x.title : x.name));
  const best = (kind === "movies"
    ? await listMovies({ genreId: genre?.id, year, minVotes: 100 }, "rating", 1, 1)
    : await listTv({ genreId: genre?.id, year, minVotes: 50 }, "rating", 1, 1)).items[0];
  const intro = `${year ? `${year} brought` : "The catalog has"} ${fmtInt(r.total)} ${gName ? gName.toLowerCase() + " " : ""}${noun}.`
    + (top.length ? ` The most popular are ${listJoin(top)}.` : "")
    + (best && best.rating ? ` The highest rated with enough votes is ${best.title} at ${best.rating.toFixed(1)}.` : "")
    + " Sorted by popularity.";
  return {
    title: titleFor(listTitle), path: page > 1 ? `${base}/page/${page}` : base, index: r.total >= s.minListSize,
    description: `${listTitle}: ${top.length ? listJoin(top) + " and " : ""}${fmtInt(Math.max(0, r.total - top.length))} more, ranked by popularity with ratings and where to watch.`,
    render: async () => (
      <ListPage eyebrow={genre && year ? "Genre · Year" : genre ? "Genre" : "Year"} title={listTitle} page={page} pages={r.pages} total={r.total} perPage={r.perPage}
        items={r.items} base={base} maxPages={s.maxListPages} adPage="list" count={`${fmtInt(r.total)} titles`}
        crumbs={[["Home", "/"], [label, `/${kind}`], ...(genre ? [[gName, `/${kind}/${genre.slug}`] as [string, string]] : []), ...(year ? [[String(year), base] as [string, string]] : [])]}
        intro={intro}
        before={genre ? <YearPills base={`/${kind}/${genre.slug}`} current={year} /> : <FilterForm {...await filterProps({ year })} />} />
    ),
  };
}

async function upcomingView(year: number, month: number): Promise<CatalogView> {
  const { upcomingMovies } = await import("@/lib/data/queries");
  if (!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12 || year < 2000 || year > 2100) return missing(`/movies/upcoming/${year}/${month}`);
  const rows = await upcomingMovies(year, month);
  const monthName = new Date(Date.UTC(year, month - 1, 1)).toLocaleDateString("en-US", { month: "long", timeZone: "UTC" });
  const path = `/movies/upcoming/${year}/${month}`;
  const prev = month === 1 ? [year - 1, 12] : [year, month - 1];
  const next = month === 12 ? [year + 1, 1] : [year, month + 1];
  const name = (y: number, m: number) => new Date(Date.UTC(y, m - 1, 1)).toLocaleDateString("en-US", { month: "long", year: "numeric", timeZone: "UTC" });
  const days = new Map<string, typeof rows>();
  for (const r of rows) {
    const k = r.releaseDate!.toISOString().slice(0, 10);
    days.set(k, [...(days.get(k) ?? []), r]);
  }
  const { toMovieCard } = await import("@/lib/data/queries");
  const { Grid, Crumbs } = await import("@/components/ui");
  return {
    title: `Upcoming Movies in ${monthName} ${year} – Release Dates`, path, index: rows.length > 0,
    description: `${rows.length} movies releasing in ${monthName} ${year}, with release dates, cast and where to watch once they are out.`,
    render: async () => (
      <div className="wrap">
        <Crumbs items={[["Home", "/"], ["Movies", "/movies"], [`${monthName} ${year}`, path]]} />
        <div className="page-head"><div><span className="eyebrow">Release calendar</span><h1 className="page-title">Upcoming Movies in {monthName} {year}</h1>
          <p className="page-sub">Release dates by day. Dates move often; each title page shows the latest date and switches to where to watch once it is out.</p></div></div>
        <nav className="month-nav" aria-label="Months">
          <Link href={`/movies/upcoming/${prev[0]}/${prev[1]}`}>&larr; {name(prev[0], prev[1])}</Link>
          <span className="mono muted">{monthName.slice(0, 3).toUpperCase()} {year}</span>
          <Link href={`/movies/upcoming/${next[0]}/${next[1]}`}>{name(next[0], next[1])} &rarr;</Link>
        </nav>
        {days.size === 0 && <p className="empty">No releases listed for this month yet.</p>}
        {[...days.entries()].map(([d, list]) => {
          const date = new Date(d + "T00:00:00Z");
          return (
            <section key={d}>
              <div className="date-head">
                <time className="date-big" dateTime={d}>{date.toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" })}</time>
                <span className="eyebrow">{date.toLocaleDateString("en-US", { weekday: "long", timeZone: "UTC" })}</span>
              </div>
              <Grid items={list.map((m) => toMovieCard(m))} />
            </section>
          );
        })}
      </div>
    ),
  };
}

export async function catalogMetadata(v: CatalogView): Promise<Metadata> {
  return buildMeta({ title: v.title, description: v.description, path: v.path, index: v.index });
}
