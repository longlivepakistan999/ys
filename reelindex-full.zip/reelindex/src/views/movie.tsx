import Link from "next/link";
import { cache } from "react";
import { permanentRedirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { ensureDetail } from "@/lib/data/ensure";
import { movieHref, movieLinks, personLinks } from "@/lib/data/queries";
import { genreNames } from "@/lib/genres";
import { countryName, countrySlug } from "@/lib/countries";
import { idFromSegment } from "@/lib/slug";
import { missing } from "@/lib/route";
import { fillTemplate, getSettings } from "@/lib/settings";
import { buildMeta } from "@/lib/seo/meta";
import { breadcrumbLd, JsonLd } from "@/lib/seo/jsonld";
import { languageName, movieSummary } from "@/lib/seo/summaries";
import { fmtDate, fmtInt, fmtRuntime, getSite, img, listJoin } from "@/lib/site";
import type { trimMovie } from "@/lib/tmdb/trim";
import { Ad } from "@/components/Ad";
import { hasVideo } from "@/lib/data/sources";
import { Providers } from "@/components/Providers";
import { Crumbs, Facts, Grid, PeopleRail, PlayIcon, Poster, Section, hue } from "@/components/ui";

export type MovieDetail = ReturnType<typeof trimMovie>;

/** Load + canonicalize: id-only or stale-slug URLs 301 to the current one. */
export const loadMovie = cache(async (segment: string, suffix = "") => {
  const id = idFromSegment(segment);
  if (!id) return missing(`/movie/${segment}${suffix}`);
  try { await ensureDetail("movie", id); } catch { /* TMDB down: render what we have */ }
  const m = await prisma.movie.findUnique({ where: { id } });
  if (!m || m.removedAt || m.hidden || m.adult || !m.detail) return missing(`/movie/${segment}${suffix}`);
  const canonical = movieHref(m);
  if (`/movie/${segment}` !== canonical) permanentRedirect(canonical + suffix);
  const d = m.detail as unknown as MovieDetail;
  const directors = d.credits.crew.filter((c) => c.job === "Director");
  return { m, d, canonical, directors, genres: d.genres };
});

export async function movieMetadata(segment: string) {
  const { m, d, canonical, directors } = await loadMovie(segment);
  const s = await getSettings();
  const upcoming = !!m.releaseDate && m.releaseDate.getTime() > Date.now();
  const title = m.seoTitleOverride || fillTemplate(upcoming ? s.seoTemplates.movieUpcoming : s.seoTemplates.movie, { title: m.titleOverride || m.title, year: m.year });
  const stars = d.credits.cast.slice(0, 2).map((c) => c.name);
  const description = `${m.title}${m.year ? ` (${m.year})` : ""}${directors.length ? `, directed by ${directors[0].name}` : ""}${stars.length ? `, starring ${listJoin(stars)}` : ""}. `
    + `${m.runtime ? `Runtime ${fmtRuntime(m.runtime)}${d.certification ? `, rated ${d.certification}` : ""}. ` : ""}See the cast, ratings and where to stream.`;
  return buildMeta({ title, description, path: canonical, index: m.isIndexable, ogType: "video.movie", image: img(m.backdropPath, "w1280") ?? img(m.posterPath, "w780") });
}

export async function MoviePage({ segment }: { segment: string }) {
  const { m, d, canonical, directors } = await loadMovie(segment);
  const site = await getSite();
  const title = m.titleOverride || m.title;
  const overview = m.overviewOverride || m.overview;
  const writers = d.credits.crew.filter((c) => ["Screenplay", "Writer"].includes(c.job));
  const novel = d.credits.crew.find((c) => c.job === "Novel");
  const castLinks = await personLinks([...d.credits.cast.map((c) => c.id), ...directors.map((x) => x.id)]);
  const similar = [...d.similar, ...d.recommendations].filter((x, i, a) => a.findIndex((y) => y.id === x.id) === i).slice(0, 12);
  const simLinks = await movieLinks(similar.map((x) => x.id));
  const collection = m.collectionId ? await prisma.collection.findUnique({ where: { id: m.collectionId }, select: { id: true, name: true, slug: true } }) : null;
  const upcoming = !!m.releaseDate && m.releaseDate.getTime() > Date.now();
  const summary = movieSummary({
    title, year: m.year, genres: d.genres, directors: directors.map((x) => x.name), cast: d.credits.cast.map((c) => c.name),
    runtime: m.runtime, certification: d.certification, rating: m.rating, voteCount: m.voteCount, releaseDate: m.releaseDate, providers: d.providers,
  });
  const genreRows = await genreNames(m.genres);
  const playable = await hasVideo("movie", m.id);

  return (
    <>
      <JsonLd data={[{
        "@context": "https://schema.org", "@type": "Movie", name: title, url: site.url + canonical,
        ...(m.posterPath ? { image: img(m.posterPath, "w780") } : {}),
        ...(m.releaseDate ? { datePublished: m.releaseDate.toISOString().slice(0, 10) } : {}),
        ...(overview ? { description: overview } : {}),
        genre: d.genres, ...(m.runtime ? { duration: `PT${Math.floor(m.runtime / 60)}H${m.runtime % 60}M` } : {}),
        ...(d.certification ? { contentRating: d.certification } : {}),
        director: directors.map((x) => ({ "@type": "Person", name: x.name })),
        actor: d.credits.cast.slice(0, 6).map((c) => ({ "@type": "Person", name: c.name })),
        ...(m.voteCount >= 10 ? { aggregateRating: { "@type": "AggregateRating", ratingValue: m.rating, bestRating: 10, ratingCount: m.voteCount } } : {}),
      }, breadcrumbLd(site.url, [["Home", "/"], ["Movies", "/movies"], [`${title}${m.year ? ` (${m.year})` : ""}`, canonical]])]} />

      <section className="hero">
        <div className="hero-bg" style={{ ["--h" as string]: hue(title) }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {m.backdropPath && <img src={img(m.backdropPath, "w1280")!} alt="" />}
        </div>
        <div className="wrap">
          <Crumbs items={[["Home", "/"], ["Movies", "/movies"], [`${title}${m.year ? ` (${m.year})` : ""}`, canonical]]} />
          <div className="hero-grid">
            <Poster title={title} path={m.posterPath} size="w500" priority />
            <div className="hero-text">
              <div className="hero-meta">
                <span>Movie</span>{m.year && <span>{m.year}</span>}{d.certification && <span>{d.certification}</span>}
                {m.runtime ? <span>{fmtRuntime(m.runtime)}</span> : null}{m.language && <span>{languageName(m.language)}</span>}
              </div>
              <h1 className="hero-title">{title} {m.year && <small>({m.year})</small>}</h1>
              {genreRows.length > 0 && <div className="chips">{genreRows.map((g) => <Link key={g.id} className="chip" href={`/movies/${g.slug}`}>{g.name}</Link>)}</div>}
              {m.voteCount >= 10 && !upcoming && (
                <div className="score"><span className="score-num">{m.rating.toFixed(1)}</span><span className="score-sub">/ 10 user score<br />{fmtInt(m.voteCount)} votes</span></div>
              )}
              {upcoming && m.releaseDate && <div className="score"><span className="score-sub">Release date<br /></span><span className="score-num" style={{ fontSize: 34 }}>{fmtDate(m.releaseDate)}</span></div>}
              {overview && <p className="hero-overview">{overview}</p>}
              <div className="hero-actions"><Link className="btn btn-primary" href={playable ? `${canonical}/watch` : "#watch"}><PlayIcon /> Watch Now</Link></div>
            </div>
          </div>
        </div>
      </section>

      <div className="wrap detail">
        <div>
          <Section title={`About ${title}`}><p className="auto-summary">{summary}</p></Section>
          <Section title={`${title} Cast`}>
            <PeopleRail people={d.credits.cast.slice(0, 15).map((c) => ({ key: `${c.id}-${c.character}`, name: c.name, role: c.character, profile: c.profile, href: castLinks.get(c.id) ?? `/person/${c.id}` }))} />
          </Section>
          <Ad slot="content-mid" page="movie" />
          <Providers data={d.providers} title={title} />
          {similar.length > 0 && (
            <Section title={`Movies Like ${title}`} link={["See all", `${canonical}/similar`]}>
              <Grid items={similar.slice(0, 6).map((x) => ({ key: `s${x.id}`, href: simLinks.get(x.id) ?? `/movie/${x.id}`, title: x.title, poster: x.poster, year: x.year ? String(x.year) : "", rating: x.rating || null }))} />
            </Section>
          )}
        </div>
        <aside className="side" aria-label="Movie facts">
          <div className="side-block"><h2>Details</h2>
            <Facts rows={[
              ["Director", directors.length ? <>{directors.map((x, i) => <span key={x.id}>{i > 0 && ", "}<Link href={castLinks.get(x.id) ?? `/person/${x.id}`}>{x.name}</Link></span>)}</> : null],
              ["Screenplay", writers.length ? writers.map((w) => w.name).slice(0, 3).join(", ") : null],
              ["Based on", novel ? `Novel by ${novel.name}` : null],
              ["Release date", m.releaseDate ? `${fmtDate(m.releaseDate)}` : null],
              ["Runtime", m.runtime ? fmtRuntime(m.runtime) : null],
              ["Age rating", d.certification],
              ["Language", m.language ? languageName(m.language) : null],
              ["Country", m.countries.length ? <>{m.countries.slice(0, 3).map((c, i) => <span key={c}>{i > 0 && ", "}<Link href={`/country/${countrySlug(c)}/movies`}>{countryName(c)}</Link></span>)}</> : null],
              ["Budget", d.budget ? `$${fmtInt(d.budget)}` : null],
              ["Box office", d.revenue ? `$${fmtInt(d.revenue)}` : null],
              ["Collection", collection ? <Link href={`/collection/${collection.id}-${collection.slug}`}>{collection.name}</Link> : null],
              ["Status", m.status],
            ]} />
          </div>
          <Ad slot="sidebar" page="movie" />
        </aside>
      </div>
    </>
  );
}

/** /movie/{id}-{slug}/similar — recommendations with the reason each one was picked. */
export async function similarData(segment: string) {
  const { m, d, canonical, directors } = await loadMovie(segment, "/similar");
  const picks = [...d.similar, ...d.recommendations].filter((x, i, a) => a.findIndex((y) => y.id === x.id) === i).slice(0, 16);
  const rows = await prisma.movie.findMany({ where: { id: { in: picks.map((p) => p.id) }, removedAt: null, hidden: false } });
  const byId = new Map(rows.map((r) => [r.id, r]));
  const dirIds = new Set(directors.map((x) => x.id));
  const castIds = new Map(d.credits.cast.slice(0, 8).map((c) => [c.id, c.name]));
  const items = picks.map((p) => {
    const r = byId.get(p.id);
    const pd = r?.detail as unknown as MovieDetail | undefined;
    const reasons: string[] = [];
    const sameDir = pd?.credits.crew.find((c) => c.job === "Director" && dirIds.has(c.id));
    if (sameDir) reasons.push(`Same director: ${sameDir.name}`);
    const sharedCast = pd?.credits.cast.filter((c) => castIds.has(c.id)).slice(0, 2) ?? [];
    for (const c of sharedCast) reasons.push(`Stars ${c.name}`);
    const sharedGenres = pd?.genres.filter((g) => d.genres.includes(g)) ?? [];
    if (reasons.length < 2 && sharedGenres.length) reasons.push(sharedGenres.slice(0, 2).join(" · "));
    return { id: p.id, title: p.title, year: p.year, rating: p.rating, poster: p.poster, href: r ? movieHref(r) : `/movie/${p.id}`, overview: r?.overview ?? null, reasons };
  });
  const s = await getSettings();
  const withText = items.filter((i) => i.overview).length;
  return { m, canonical, items, index: m.isIndexable && withText >= Math.ceil(s.minListSize / 2) };
}

export async function similarMetadata(segment: string) {
  const { m, canonical, items, index } = await similarData(segment);
  const names = items.slice(0, 3).map((i) => i.title);
  return buildMeta({
    title: `Movies Like ${m.title} – ${items.length} Films to Watch Next`, path: `${canonical}/similar`, index,
    description: `Liked ${m.title}? Here are ${items.length} similar movies${names.length ? `, including ${listJoin(names)}` : ""}, with the reason each one made the list.`,
  });
}

export async function SimilarPage({ segment }: { segment: string }) {
  const { m, canonical, items } = await similarData(segment);
  const site = await getSite();
  const path = `${canonical}/similar`;
  const crumbs: [string, string][] = [["Home", "/"], ["Movies", "/movies"], [`${m.title}${m.year ? ` (${m.year})` : ""}`, canonical], ["Similar", path]];
  return (
    <div className="wrap">
      <JsonLd data={[breadcrumbLd(site.url, crumbs), { "@context": "https://schema.org", "@type": "ItemList", name: `Movies Like ${m.title}`, itemListElement: items.map((x, i) => ({ "@type": "ListItem", position: i + 1, name: x.title, url: site.url + x.href })) }]} />
      <Crumbs items={crumbs} />
      <div className="page-head"><div><span className="eyebrow">Recommendations</span><h1 className="page-title">Movies Like {m.title}</h1>
        <p className="page-sub">Picked for their links to {m.title}: the same director or stars, shared genres, or what viewers of {m.title} watched next.</p></div></div>
      {items.length === 0 ? <p className="empty">No recommendations yet.</p> : (
        <div className="similar-list">
          {items.map((x) => (
            <article className="similar" key={x.id}>
              <Link href={x.href}><Poster title={x.title} path={x.poster} mini /></Link>
              <div>
                <Link className="row-title" href={x.href}>{x.title}</Link>
                <div className="row-meta">{x.year}{x.rating ? ` · ★ ${x.rating.toFixed(1)}` : ""}</div>
                {x.overview && <p className="row-desc">{x.overview.length > 220 ? x.overview.slice(0, 217).replace(/\s+\S*$/, "") + "…" : x.overview}</p>}
                {x.reasons.length > 0 && <div style={{ marginTop: 8 }}>{x.reasons.map((r) => <span key={r} className="reason">{r}</span>)}</div>}
              </div>
            </article>
          ))}
        </div>
      )}
      <Ad slot="content-bottom" page="similar" />
    </div>
  );
}

