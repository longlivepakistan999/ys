import Link from "next/link";
import type { ReactNode } from "react";
import type { CardItem } from "@/lib/data/queries";
import { breadcrumbLd, JsonLd } from "@/lib/seo/jsonld";
import { getSite } from "@/lib/site";
import { Ad } from "@/components/Ad";
import { Crumbs, Grid, Pager } from "@/components/ui";

/**
 * Every list page (catalog, genre/year, country, platform). Page 1 carries the
 * intro paragraph; later pages show only their range, per the pagination rules.
 */
export async function ListPage(p: {
  eyebrow?: string; title: string; intro?: ReactNode; count?: string;
  crumbs: [string, string][]; items: CardItem[]; base: string; page: number; pages: number; total: number; perPage: number;
  before?: ReactNode; maxPages: number; adPage: string;
}) {
  const site = await getSite();
  const from = (p.page - 1) * p.perPage + 1;
  const to = Math.min(p.total, p.page * p.perPage);
  return (
    <div className="wrap">
      <JsonLd data={breadcrumbLd(site.url, p.crumbs)} />
      <Crumbs items={p.crumbs} />
      <div className="page-head">
        <div>
          {p.eyebrow && <span className="eyebrow">{p.eyebrow}</span>}
          <h1 className="page-title">{p.title}</h1>
          {p.page === 1 ? (p.intro ? <p className="page-sub">{p.intro}</p> : null)
            : <p className="page-sub">Page {p.page} · titles {from.toLocaleString("en-US")}–{to.toLocaleString("en-US")} of {p.total.toLocaleString("en-US")}</p>}
        </div>
        {p.count && <span className="count">{p.count}</span>}
      </div>
      {p.before}
      <Grid items={p.items} />
      <Pager base={p.base} page={p.page} pages={p.pages} maxPages={p.maxPages} />
      {p.pages > p.maxPages && p.page === 1 && (
        <p className="pager-note">Showing the first {p.maxPages} pages. Browse by <Link className="section-link" href="/countries">country</Link> or year to see more.</p>
      )}
      <Ad slot="content-bottom" page={p.adPage} />
    </div>
  );
}

/** Year pills for genre/year pages. */
export function YearPills({ base, current }: { base: string; current?: number }) {
  const now = new Date().getUTCFullYear();
  const years = Array.from({ length: 12 }, (_, i) => now - i);
  return (
    <div className="pills" style={{ marginBottom: 22 }} aria-label="Year">
      <Link className="pill" href={base} aria-current={current ? undefined : "page"}>All years</Link>
      {years.map((y) => <Link key={y} className="pill" href={`${base}/${y}`} aria-current={y === current ? "page" : undefined}>{y}</Link>)}
    </div>
  );
}
