import Link from "next/link";
import { cache } from "react";
import { permanentRedirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { ensureDetail } from "@/lib/data/ensure";
import { personLinks, tvHref, tvLinks } from "@/lib/data/queries";
import { genreNames } from "@/lib/genres";
import { countryName, countrySlug } from "@/lib/countries";
import { idFromSegment, paths } from "@/lib/slug";
import { missing } from "@/lib/route";
import { fillTemplate, getSettings } from "@/lib/settings";
import { buildMeta } from "@/lib/seo/meta";
import { breadcrumbLd, JsonLd } from "@/lib/seo/jsonld";
import { episodeSummary, languageName, seasonSummary, tvSummary } from "@/lib/seo/summaries";
import { fmtDate, fmtInt, getSite, img } from "@/lib/site";
import type { trimEpisode, trimTv } from "@/lib/tmdb/trim";
import { Ad } from "@/components/Ad";
import { hasVideo } from "@/lib/data/sources";
import { Providers } from "@/components/Providers";
import { Card, Crumbs, Facts, Grid, PeopleRail, PlayIcon, Poster, Section, Still, hue } from "@/components/ui";

export type TvDetail = ReturnType<typeof trimTv>;
type EpDetail = ReturnType<typeof trimEpisode>;

const seasonLabel = (n: number) => (n === 0 ? "Specials" : `Season ${n}`);
const code = (s: number, e: number) => `S${String(s).padStart(2, "0")}E${String(e).padStart(2, "0")}`;

function yearsOf(t: { firstAirYear: number | null; lastAirDate: Date | null; status: string | null }) {
  const end = t.status === "Ended" || t.status === "Canceled" ? t.lastAirDate?.getUTCFullYear() : null;
  if (!t.firstAirYear) return "";
  return end && end !== t.firstAirYear ? `${t.firstAirYear}–${end}` : end ? `${t.firstAirYear}` : `${t.firstAirYear}–`;
}

export const loadShow = cache(async (segment: string, rest: string) => {
  const id = idFromSegment(segment);
  if (!id) return missing(`/tv/${segment}${rest}`);
  try { await ensureDetail("tv", id); } catch { /* serve cached data */ }
  const t = await prisma.tvShow.findUnique({ where: { id } });
  if (!t || t.removedAt || t.hidden || t.adult || !t.detail) return missing(`/tv/${segment}${rest}`);
  const canonical = tvHref(t);
  if (`/tv/${segment}` !== canonical) permanentRedirect(canonical + rest);
  const d = t.detail as unknown as TvDetail;
  const name = t.titleOverride || t.name;
  return { t, d, canonical, name, years: yearsOf(t) };
});

// ------------------------------------------------------------------ Show
export async function showMetadata(segment: string) {
  const { t, canonical, name, years } = await loadShow(segment, "");
  const s = await getSettings();
  const title = t.seoTitleOverride || fillTemplate(s.seoTemplates.tv, { title: name, years });
  const description = `${name}: all ${t.numberOfSeasons} season${t.numberOfSeasons === 1 ? "" : "s"} and ${fmtInt(t.numberOfEpisodes)} episodes${years ? ` (${years})` : ""}. Episode guide, cast, ratings and where to stream every season.`;
  return buildMeta({ title, description, path: canonical, index: t.isIndexable, ogType: "video.tv_show", image: img(t.backdropPath, "w1280") ?? img(t.posterPath, "w780") });
}

export async function ShowPage({ segment }: { segment: string }) {
  const { t, d, canonical, name, years } = await loadShow(segment, "");
  const site = await getSite();
  const seasons = await prisma.season.findMany({ where: { showId: t.id }, orderBy: { seasonNumber: "asc" } });
  const ordered = [...seasons.filter((x) => x.seasonNumber > 0), ...seasons.filter((x) => x.seasonNumber === 0)];
  const castLinks = await personLinks([...d.credits.cast.map((c) => c.id), ...d.createdBy.map((c) => c.id)]);
  const recLinks = await tvLinks(d.recommendations.map((r) => r.id));
  const genreRows = await genreNames(t.genres);
  const ended = t.status === "Ended" || t.status === "Canceled";
  const lastEp = d.lastEpisode ? await prisma.episode.findFirst({ where: { showId: t.id, seasonNumber: d.lastEpisode.s, episodeNumber: d.lastEpisode.e } }) : null;
  const overview = t.overviewOverride || t.overview;
  const summary = tvSummary({
    name, creators: d.createdBy.map((c) => c.name), networks: d.networks, firstAirDate: t.firstAirDate, lastAirDate: t.lastAirDate,
    status: t.status, seasons: t.numberOfSeasons, episodes: t.numberOfEpisodes, cast: d.credits.cast.map((c) => c.name),
    lastEpisode: d.lastEpisode, nextEpisode: d.nextEpisode, providers: d.providers,
  });
  const runtimes = d.runtimes.length ? (Math.min(...d.runtimes) === Math.max(...d.runtimes) ? `${d.runtimes[0]} min` : `${Math.min(...d.runtimes)}–${Math.max(...d.runtimes)} min`) : null;

  return (
    <>
      <JsonLd data={[{
        "@context": "https://schema.org", "@type": "TVSeries", name, url: site.url + canonical,
        ...(t.posterPath ? { image: img(t.posterPath, "w780") } : {}), ...(overview ? { description: overview } : {}),
        ...(t.firstAirDate ? { startDate: t.firstAirDate.toISOString().slice(0, 10) } : {}),
        ...(ended && t.lastAirDate ? { endDate: t.lastAirDate.toISOString().slice(0, 10) } : {}),
        numberOfSeasons: t.numberOfSeasons, numberOfEpisodes: t.numberOfEpisodes, genre: d.genres,
        creator: d.createdBy.map((c) => ({ "@type": "Person", name: c.name })),
        actor: d.credits.cast.slice(0, 6).map((c) => ({ "@type": "Person", name: c.name })),
        ...(t.voteCount >= 10 ? { aggregateRating: { "@type": "AggregateRating", ratingValue: t.rating, bestRating: 10, ratingCount: t.voteCount } } : {}),
        containsSeason: ordered.map((x) => ({ "@type": "TVSeason", seasonNumber: x.seasonNumber, numberOfEpisodes: x.episodeCount, url: site.url + paths.season(t.id, t.slug, x.seasonNumber) })),
      }, breadcrumbLd(site.url, [["Home", "/"], ["TV Shows", "/tv"], [name, canonical]])]} />

      <section className="hero">
        <div className="hero-bg" style={{ ["--h" as string]: hue(name) }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {t.backdropPath && <img src={img(t.backdropPath, "w1280")!} alt="" />}
        </div>
        <div className="wrap">
          <Crumbs items={[["Home", "/"], ["TV Shows", "/tv"], [name, canonical]]} />
          <div className="hero-grid">
            <Poster title={name} path={t.posterPath} size="w500" priority />
            <div className="hero-text">
              <div className="hero-meta"><span>TV Series</span>{years && <span>{years}</span>}<span>{t.numberOfSeasons} seasons</span><span>{fmtInt(t.numberOfEpisodes)} episodes</span>{t.status && <span>{t.status}</span>}</div>
              <h1 className="hero-title">{name}</h1>
              {genreRows.length > 0 && <div className="chips">{genreRows.map((g) => <Link key={g.id} className="chip" href={`/tv/${g.slug}`}>{g.name}</Link>)}</div>}
              {t.voteCount >= 10 && <div className="score"><span className="score-num">{t.rating.toFixed(1)}</span><span className="score-sub">/ 10 user score<br />{fmtInt(t.voteCount)} votes</span></div>}
              {overview && <p className="hero-overview">{overview}</p>}
              <div className="hero-actions">
                <a className="btn btn-primary" href="#watch"><PlayIcon /> Watch Now</a>
                {ordered[0] && <Link className="btn btn-ghost" href={paths.season(t.id, t.slug, ordered[0].seasonNumber)}>Episode guide</Link>}
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="wrap detail">
        <div>
          <Section title={`About ${name}`}><p className="auto-summary">{summary}</p></Section>
          {d.lastEpisode && (
            <Section title={ended ? "Last Episode" : "Latest Episode"}>
              <div className="latest">
                <Still title={d.lastEpisode.name} path={lastEp?.stillPath} href={lastEp?.hasPage ? paths.episode(t.id, t.slug, d.lastEpisode.s, d.lastEpisode.e) : undefined} />
                <div>
                  <span className="ep-code">{code(d.lastEpisode.s, d.lastEpisode.e)}{ended ? " · Series finale" : ""}</span>
                  <div className="ep-title">
                    {lastEp?.hasPage ? <Link href={paths.episode(t.id, t.slug, d.lastEpisode.s, d.lastEpisode.e)}>Season {d.lastEpisode.s} Episode {d.lastEpisode.e}: {d.lastEpisode.name}</Link>
                      : <>Season {d.lastEpisode.s} Episode {d.lastEpisode.e}: {d.lastEpisode.name}</>}
                  </div>
                  <div className="ep-meta">{d.lastEpisode.airDate && <span>Aired {fmtDate(d.lastEpisode.airDate)}</span>}{lastEp?.runtime ? <span>{lastEp.runtime} min</span> : null}</div>
                  {d.nextEpisode?.airDate && <p className="muted" style={{ margin: 0 }}>Next: Season {d.nextEpisode.s} Episode {d.nextEpisode.e} on {fmtDate(d.nextEpisode.airDate)}</p>}
                </div>
              </div>
            </Section>
          )}
          <Section title="All Seasons" count={`${t.numberOfSeasons} seasons · ${fmtInt(t.numberOfEpisodes)} episodes`}>
            <div className="season-grid">
              {ordered.map((x) => (
                <Card key={x.id} item={{
                  key: String(x.id), href: paths.season(t.id, t.slug, x.seasonNumber), title: x.seasonNumber === 0 ? `${name} Specials` : `${name} Season ${x.seasonNumber}`,
                  poster: x.posterPath ?? t.posterPath, year: `${x.episodeCount} episodes`, rating: null, meta: x.airDate ? String(x.airDate.getUTCFullYear()) : undefined,
                }} />
              ))}
            </div>
          </Section>
          <Section title={`${name} Cast`}>
            <PeopleRail people={d.credits.cast.slice(0, 15).map((c) => ({ key: `${c.id}`, name: c.name, role: c.character, profile: c.profile, href: castLinks.get(c.id) ?? `/person/${c.id}` }))} />
          </Section>
          <Ad slot="content-mid" page="tv" />
          <Providers data={d.providers} title={name} />
          {d.recommendations.length > 0 && (
            <Section title={`Shows Like ${name}`}>
              <Grid items={d.recommendations.slice(0, 6).map((r) => ({ key: `r${r.id}`, href: recLinks.get(r.id) ?? `/tv/${r.id}`, title: r.title, poster: r.poster, year: r.year ? String(r.year) : "", rating: r.rating || null }))} />
            </Section>
          )}
        </div>
        <aside className="side" aria-label="Show facts">
          <div className="side-block"><h2>Details</h2>
            <Facts rows={[
              ["Created by", d.createdBy.length ? <>{d.createdBy.map((c, i) => <span key={c.id}>{i > 0 && ", "}<Link href={castLinks.get(c.id) ?? `/person/${c.id}`}>{c.name}</Link></span>)}</> : null],
              ["Network", d.networks.join(", ") || null],
              ["First aired", t.firstAirDate ? fmtDate(t.firstAirDate) : null],
              [ended ? "Last aired" : "Latest episode", t.lastEpisodeAirDate ? fmtDate(t.lastEpisodeAirDate) : null],
              ["Next episode", t.nextEpisodeAirDate ? fmtDate(t.nextEpisodeAirDate) : null],
              ["Status", t.status], ["Seasons", String(t.numberOfSeasons)], ["Episodes", fmtInt(t.numberOfEpisodes)], ["Runtime", runtimes],
              ["Rating", d.certification],
              ["Country", t.countries.length ? <>{t.countries.slice(0, 3).map((c, i) => <span key={c}>{i > 0 && ", "}<Link href={`/country/${countrySlug(c)}/tv`}>{countryName(c)}</Link></span>)}</> : null],
              ["Language", t.language ? languageName(t.language) : null],
            ]} />
          </div>
          <Ad slot="sidebar" page="tv" />
        </aside>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ Season
function parseSeason(seg: string) {
  if (seg === "specials") return 0;
  const m = /^season-(\d+)$/.exec(seg);
  return m ? Number(m[1]) : null;
}

export const loadSeason = cache(async (segment: string, seasonSeg: string, rest = "") => {
  const show = await loadShow(segment, `/${seasonSeg}${rest}`);
  const n = parseSeason(seasonSeg);
  if (n === null || (n === 0 && seasonSeg !== "specials")) return missing(`${show.canonical}/${seasonSeg}${rest}`);
  const season = await prisma.season.findUnique({ where: { showId_seasonNumber: { showId: show.t.id, seasonNumber: n } } });
  if (!season) return missing(`${show.canonical}/${seasonSeg}${rest}`);
  const episodes = await prisma.episode.findMany({ where: { seasonId: season.id }, orderBy: { episodeNumber: "asc" } });
  const all = await prisma.season.findMany({ where: { showId: show.t.id }, orderBy: { seasonNumber: "asc" }, select: { seasonNumber: true } });
  return { ...show, season, episodes, seasonNumbers: all.map((x) => x.seasonNumber), path: paths.season(show.t.id, show.t.slug, n) };
});

export async function seasonMetadata(segment: string, seasonSeg: string) {
  const { t, name, season, episodes, path } = await loadSeason(segment, seasonSeg);
  const s = await getSettings();
  const first = episodes.find((e) => e.airDate), last = [...episodes].reverse().find((e) => e.airDate);
  const title = season.seasonNumber === 0
    ? `${name} Specials – All ${episodes.length} Episodes`
    : fillTemplate(s.seoTemplates.season, { show: name, season: season.seasonNumber, episodes: episodes.length });
  const description = `${name} ${seasonLabel(season.seasonNumber)} episode guide: all ${episodes.length} episodes`
    + (first?.name && last?.name && first !== last ? ` from ${first.name} (${fmtDate(first.airDate)}) to ${last.name} (${fmtDate(last.airDate)})` : "")
    + ", with air dates and where to stream.";
  return buildMeta({ title, description, path, index: season.isIndexable && t.isIndexable, ogType: "video.tv_show", image: img(season.posterPath ?? t.posterPath, "w780") });
}

export async function SeasonPage({ segment, seasonSeg }: { segment: string; seasonSeg: string }) {
  const { t, d, canonical, name, season, episodes, seasonNumbers, path } = await loadSeason(segment, seasonSeg);
  const site = await getSite();
  const n = season.seasonNumber;
  const label = seasonLabel(n);
  const regular = seasonNumbers.filter((x) => x > 0);
  const idx = regular.indexOf(n);
  const prevS = idx > 0 ? regular[idx - 1] : null;
  const nextS = idx >= 0 && idx < regular.length - 1 ? regular[idx + 1] : null;
  const first = episodes.find((e) => e.airDate), last = [...episodes].reverse().find((e) => e.airDate);
  const crumbs: [string, string][] = [["Home", "/"], ["TV Shows", "/tv"], [name, canonical], [label, path]];
  return (
    <>
      <JsonLd data={[{
        "@context": "https://schema.org", "@type": "TVSeason", name: `${name} ${label}`, seasonNumber: n, numberOfEpisodes: episodes.length, url: site.url + path,
        ...(first?.airDate ? { startDate: first.airDate.toISOString().slice(0, 10) } : {}), ...(last?.airDate ? { endDate: last.airDate.toISOString().slice(0, 10) } : {}),
        partOfSeries: { "@type": "TVSeries", name, url: site.url + canonical },
        episode: episodes.filter((e) => e.hasPage).map((e) => ({ "@type": "TVEpisode", episodeNumber: e.episodeNumber, name: e.name ?? `Episode ${e.episodeNumber}`, ...(e.airDate ? { datePublished: e.airDate.toISOString().slice(0, 10) } : {}), url: site.url + paths.episode(t.id, t.slug, n, e.episodeNumber) })),
      }, breadcrumbLd(site.url, crumbs)]} />
      <section className="hero">
        <div className="hero-bg" style={{ ["--h" as string]: hue(name) }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {t.backdropPath && <img src={img(t.backdropPath, "w1280")!} alt="" />}
        </div>
        <div className="wrap">
          <Crumbs items={crumbs} />
          <div className="hero-grid">
            <Poster title={label} path={season.posterPath ?? t.posterPath} size="w500" priority />
            <div className="hero-text">
              <div className="hero-meta"><span>{label}</span><span>{episodes.length} episodes</span>{first?.airDate && <span>{fmtDate(first.airDate)}{last?.airDate && last !== first ? ` – ${fmtDate(last.airDate)}` : ""}</span>}{d.networks[0] && <span>{d.networks[0]}</span>}</div>
              <h1 className="hero-title"><small>{name}</small>{label}</h1>
              {season.overview && <p className="hero-overview">{season.overview}</p>}
              <div className="hero-actions"><a className="btn btn-primary" href="#watch"><PlayIcon /> Watch Now</a></div>
            </div>
          </div>
        </div>
      </section>
      <div className="wrap">
        <div className="pills" style={{ marginTop: 20 }} aria-label="Seasons">
          {[...regular, ...(seasonNumbers.includes(0) ? [0] : [])].map((x) => (
            <Link key={x} className="pill" href={paths.season(t.id, t.slug, x)} aria-current={x === n ? "page" : undefined}>{seasonLabel(x)}</Link>
          ))}
        </div>
        <div className="detail">
          <div>
            <Section title={`${label} Episodes`} count={`${episodes.length} episodes`}>
              <p className="auto-summary">{seasonSummary({ show: name, season: n, episodes, network: d.networks[0] })}</p>
              <ol className="ep-list">
                {episodes.map((e) => {
                  const href = e.hasPage ? paths.episode(t.id, t.slug, n, e.episodeNumber) : undefined;
                  const titleText = `${label} Episode ${e.episodeNumber}${e.name ? `: ${e.name}` : ""}`;
                  return (
                    <li key={e.id} className={`ep${href ? "" : " no-page"}`}>
                      <Still title={e.name ?? titleText} path={e.stillPath} href={href} />
                      <div>
                        <span className="ep-code">{code(n, e.episodeNumber)}</span>
                        <h3 className="ep-title">{href ? <Link href={href}>{titleText}</Link> : titleText}</h3>
                        <div className="ep-meta">{e.airDate && <span>{fmtDate(e.airDate)}</span>}{e.runtime ? <span>{e.runtime} min</span> : null}</div>
                        {e.overview && <p>{e.overview}</p>}
                      </div>
                    </li>
                  );
                })}
              </ol>
              <nav className="season-nav" aria-label="Seasons">
                {prevS !== null ? <Link href={paths.season(t.id, t.slug, prevS)}>&larr; {name} Season {prevS}</Link> : <span className="muted">First season</span>}
                {nextS !== null ? <Link href={paths.season(t.id, t.slug, nextS)}>{name} Season {nextS} &rarr;</Link> : <span className="muted">Latest season</span>}
              </nav>
            </Section>
            <Ad slot="content-bottom" page="season" />
            <Providers data={d.providers} title={`${name} ${label}`} />
          </div>
          <aside className="side" aria-label="Season facts">
            <div className="side-block"><h2>{label}</h2>
              <Facts rows={[["Episodes", String(episodes.length)], ["Premiere", first?.airDate ? fmtDate(first.airDate) : null], ["Finale", last?.airDate && last !== first ? fmtDate(last.airDate) : null], ["Network", d.networks[0] ?? null], ["Show", <Link key="s" href={canonical}>{name}</Link>]]} />
            </div>
            <Ad slot="sidebar" page="season" />
          </aside>
        </div>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ Episode
export const loadEpisode = cache(async (segment: string, seasonSeg: string, epSeg: string) => {
  const s = await loadSeason(segment, seasonSeg, `/${epSeg}`);
  const m = /^episode-(\d+)$/.exec(epSeg);
  if (!m) return missing(`${s.path}/${epSeg}`);
  const n = Number(m[1]);
  const e = s.episodes.find((x) => x.episodeNumber === n);
  if (!e) return missing(`${s.path}/${epSeg}`);
  // Thin episodes have no page of their own (needs doc §5): send them to the season guide.
  if (!e.hasPage) permanentRedirect(s.path);
  const where = { showId: s.t.id, hasPage: true, seasonNumber: { gt: 0 } };
  const [prev, next] = s.season.seasonNumber === 0 ? [null, null] : await Promise.all([
    prisma.episode.findFirst({ where: { ...where, OR: [{ seasonNumber: { lt: s.season.seasonNumber, gt: 0 } }, { seasonNumber: s.season.seasonNumber, episodeNumber: { lt: n } }] }, orderBy: [{ seasonNumber: "desc" }, { episodeNumber: "desc" }] }),
    prisma.episode.findFirst({ where: { ...where, OR: [{ seasonNumber: { gt: s.season.seasonNumber } }, { seasonNumber: s.season.seasonNumber, episodeNumber: { gt: n } }] }, orderBy: [{ seasonNumber: "asc" }, { episodeNumber: "asc" }] }),
  ]);
  return { ...s, e, prev, next, ed: (e.detail ?? { guests: [], crew: [], type: null }) as unknown as EpDetail, epPath: paths.episode(s.t.id, s.t.slug, s.season.seasonNumber, n) };
});

export async function episodeMetadata(segment: string, seasonSeg: string, epSeg: string) {
  const { t, name, season, e, epPath } = await loadEpisode(segment, seasonSeg, epSeg);
  const s = await getSettings();
  const sn = season.seasonNumber;
  const title = sn === 0
    ? `${name} Special: ${e.name ?? `Episode ${e.episodeNumber}`}`
    : fillTemplate(s.seoTemplates.episode, { show: name, season: sn, episode: e.episodeNumber, name: e.name ?? "", code: code(sn, e.episodeNumber) });
  const description = `Episode guide for ${name} ${code(sn, e.episodeNumber)}${e.name ? ` "${e.name}"` : ""}.`
    + `${e.airDate ? ` ${e.airDate.getTime() > Date.now() ? "Airs" : "Aired"} ${fmtDate(e.airDate)}.` : ""} Summary, guest stars, director and where to stream.`;
  return buildMeta({ title, description, path: epPath, index: e.isIndexable && t.isIndexable, ogType: "video.episode", image: img(e.stillPath, "w780") });
}

export async function EpisodePage({ segment, seasonSeg, epSeg }: { segment: string; seasonSeg: string; epSeg: string }) {
  const { t, d, canonical, name, season, episodes, e, prev, next, ed, path, epPath } = await loadEpisode(segment, seasonSeg, epSeg);
  const site = await getSite();
  const sn = season.seasonNumber;
  const label = seasonLabel(sn);
  const directors = ed.crew.filter((c) => c.job === "Director");
  const writers = ed.crew.filter((c) => c.job !== "Director");
  const links = await personLinks([...ed.guests.map((g) => g.id), ...ed.crew.map((c) => c.id)]);
  const crumbs: [string, string][] = [["Home", "/"], ["TV Shows", "/tv"], [name, canonical], [label, path], [`Episode ${e.episodeNumber}`, epPath]];
  const future = !!e.airDate && e.airDate.getTime() > Date.now();
  const titleLine = e.name ?? `Episode ${e.episodeNumber}`;
  const playable = await hasVideo("episode", e.id);
  return (
    <>
      <JsonLd data={[{
        "@context": "https://schema.org", "@type": "TVEpisode", name: titleLine, episodeNumber: e.episodeNumber, url: site.url + epPath,
        ...(e.airDate ? { datePublished: e.airDate.toISOString().slice(0, 10) } : {}), ...(e.runtime ? { timeRequired: `PT${e.runtime}M` } : {}),
        ...(e.overview ? { description: e.overview } : {}), ...(e.stillPath ? { image: img(e.stillPath, "w780") } : {}),
        director: directors.map((x) => ({ "@type": "Person", name: x.name })), author: writers.map((x) => ({ "@type": "Person", name: x.name })),
        actor: ed.guests.slice(0, 6).map((g) => ({ "@type": "Person", name: g.name })),
        partOfSeason: { "@type": "TVSeason", seasonNumber: sn, url: site.url + path },
        partOfSeries: { "@type": "TVSeries", name, url: site.url + canonical },
        ...(e.voteCount >= 5 ? { aggregateRating: { "@type": "AggregateRating", ratingValue: e.rating, bestRating: 10, ratingCount: e.voteCount } } : {}),
      }, breadcrumbLd(site.url, crumbs)]} />
      <section className="hero">
        <div className="hero-bg" style={{ ["--h" as string]: hue(titleLine) }} />
        <div className="wrap">
          <Crumbs items={crumbs} />
          <div className="hero-grid wide-art">
            <Still title={titleLine} path={e.stillPath} size="w780" />
            <div className="hero-text">
              <span className="code-tag">{code(sn, e.episodeNumber)}</span>
              <h1 className="hero-title"><small>{name} {label} Episode {e.episodeNumber}</small>{titleLine}</h1>
              <div className="hero-meta">
                {e.airDate && <span>{future ? "Airs" : "Aired"} {fmtDate(e.airDate)}</span>}{e.runtime ? <span>{e.runtime} min</span> : null}
                {e.episodeNumber === 1 && sn > 0 && <span>Season premiere</span>}{e.episodeNumber === episodes.length && episodes.length > 1 && <span>Season finale</span>}
              </div>
              {e.voteCount >= 5 && <div className="score"><span className="score-num">{e.rating.toFixed(1)}</span><span className="score-sub">/ 10 user score<br />{fmtInt(e.voteCount)} votes</span></div>}
              <div className="hero-actions"><Link className="btn btn-primary" href={playable ? `${epPath}/watch` : "#watch"}><PlayIcon /> Watch Now</Link></div>
            </div>
          </div>
        </div>
      </section>
      <div className="wrap detail">
        <div>
          <Section title="Episode Summary">
            <div className="prose">
              {e.overview && <p>{e.overview}</p>}
              <p className="auto-summary">{episodeSummary({ name: e.name, show: name, season: sn, episode: e.episodeNumber, seasonEpisodes: episodes.length, airDate: e.airDate, runtime: e.runtime, directors: directors.map((x) => x.name), writers: writers.map((x) => x.name), guests: ed.guests.map((g) => g.name) })}</p>
            </div>
          </Section>
          <nav className="ep-nav" aria-label="Episodes">
            {prev ? <Link href={paths.episode(t.id, t.slug, prev.seasonNumber, prev.episodeNumber)}><small>&larr; Previous episode</small><strong>{code(prev.seasonNumber, prev.episodeNumber)}{prev.name ? `: ${prev.name}` : ""}</strong></Link>
              : <span className="off"><small>&larr; Previous episode</small><strong>This is the first episode</strong></span>}
            {next ? <Link className="next" href={paths.episode(t.id, t.slug, next.seasonNumber, next.episodeNumber)}><small>Next episode &rarr;</small><strong>{code(next.seasonNumber, next.episodeNumber)}{next.name ? `: ${next.name}` : ""}</strong></Link>
              : <span className="next off"><small>Next episode &rarr;</small><strong>No later episode yet</strong></span>}
          </nav>
          {ed.guests.length > 0 && (
            <Section title="Guest Stars">
              <PeopleRail people={ed.guests.map((g) => ({ key: `${g.id}`, name: g.name, role: g.character, profile: g.profile, href: links.get(g.id) ?? `/person/${g.id}` }))} />
            </Section>
          )}
          {ed.crew.length > 0 && (
            <Section title="Crew">
              <div style={{ maxWidth: 520 }}><Facts rows={ed.crew.map((c) => [c.job, <Link key={c.id} href={links.get(c.id) ?? `/person/${c.id}`}>{c.name}</Link>])} /></div>
            </Section>
          )}
          <Ad slot="content-bottom" page="episode" />
          <Providers data={d.providers} title={`${name} ${label} Episode ${e.episodeNumber}`} />
        </div>
        <aside className="side" aria-label={`${label} episodes`}>
          <div className="side-block"><h2>{label} · {episodes.length} episodes</h2>
            <ol className="side-eps">
              {episodes.map((x) => {
                const inner = <><span>E{String(x.episodeNumber).padStart(2, "0")}</span>{x.name ?? `Episode ${x.episodeNumber}`}</>;
                return <li key={x.id}>{x.hasPage ? <Link href={paths.episode(t.id, t.slug, sn, x.episodeNumber)} aria-current={x.id === e.id ? "page" : undefined}>{inner}</Link> : <span className="muted" style={{ display: "grid", gridTemplateColumns: "30px 1fr", gap: 8, padding: 8, fontSize: 14 }}>{inner}</span>}</li>;
              })}
            </ol>
            <p style={{ margin: "0 0 8px" }}><Link className="section-link" href={path}>{label} guide &rarr;</Link></p>
          </div>
          <div className="side-block"><h2>Episode facts</h2>
            <Facts rows={[["Show", <Link key="s" href={canonical}>{name}</Link>], ["Season", <Link key="se" href={path}>{label}</Link>], ["Episode", `${e.episodeNumber} of ${episodes.length}`], ["Air date", e.airDate ? fmtDate(e.airDate) : null], ["Runtime", e.runtime ? `${e.runtime} min` : null]]} />
          </div>
          <Ad slot="sidebar" page="episode" />
        </aside>
      </div>
    </>
  );
}

