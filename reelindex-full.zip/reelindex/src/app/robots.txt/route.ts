import { getSettings, secrets } from "@/lib/settings";

// Rendered per request (cheap) and cached by Cloudflare via cache-control; never built ahead of time.
export const dynamic = "force-dynamic";


/** robots.txt from Admin > SEO, with the sitemap line added automatically. */
export async function GET() {
  const s = await getSettings();
  const { siteUrl } = await secrets();
  const body = `${s.robotsTxt.trim()}\n\nSitemap: ${siteUrl}/sitemap.xml\n`;
  return new Response(body, { headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "public, max-age=3600" } });
}
