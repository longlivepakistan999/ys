import { revalidatePath } from "next/cache";
import { NextResponse } from "next/server";
import { env } from "@/lib/env";

/** Called by the sync worker with the paths a run changed. */
export async function POST(req: Request) {
  if (!env.revalidateSecret || req.headers.get("x-revalidate-secret") !== env.revalidateSecret) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const body = (await req.json().catch(() => null)) as { paths?: unknown } | null;
  const list = Array.isArray(body?.paths) ? body.paths.filter((p): p is string => typeof p === "string" && p.startsWith("/")) : [];
  for (const p of list) revalidatePath(p);
  return NextResponse.json({ revalidated: list.length });
}
