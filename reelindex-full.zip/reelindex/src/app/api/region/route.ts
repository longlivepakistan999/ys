import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const SUPPORTED = new Set(["US", "GB", "CA", "AU", "NZ", "IE"]);

/** Visitor's watch-provider region from Cloudflare's CF-IPCountry header; US otherwise. */
export async function GET(req: Request) {
  const c = (req.headers.get("cf-ipcountry") || "").toUpperCase();
  return NextResponse.json({ region: SUPPORTED.has(c) ? c : "US" }, { headers: { "cache-control": "private, max-age=86400" } });
}
