import { TYPES, urlsFor, urlsetXml, type SitemapType } from "@/lib/seo/sitemaps";
import { secrets } from "@/lib/settings";

export const revalidate = 86400;
export async function generateStaticParams() { return []; }

export async function GET(_req: Request, { params }: { params: Promise<{ file: string }> }) {
  const { file } = await params;
  const m = /^([a-z]+)-(\d+)\.xml$/.exec(file);
  if (!m || !TYPES.includes(m[1] as SitemapType)) return new Response("Not found", { status: 404 });
  const urls = await urlsFor(m[1] as SitemapType, Number(m[2]));
  if (!urls.length && m[2] !== "1") return new Response("Not found", { status: 404 });
  const { siteUrl } = await secrets();
  return new Response(urlsetXml(siteUrl, urls), { headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=3600" } });
}
