import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { HeadCode } from "@/components/HeadCode";
import { getSite } from "@/lib/site";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const site = await getSite();
  return {
    metadataBase: new URL(site.url),
    title: site.name,
    description: site.footerText,
    icons: { icon: "/favicon.svg" },
  };
}

export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover" };

/** Shared shell for the public site and the admin. Header and footer live in (site)/layout. */
export default async function RootLayout({ children }: { children: ReactNode }) {
  const site = await getSite();
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="preconnect" href="https://image.tmdb.org" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Display:wght@700;800&family=IBM+Plex+Mono:wght@400;500;600&family=Instrument+Sans:wght@400;500;600;700&display=swap" />
        {/* Admin > Site settings > Code injection (head) */}
        <HeadCode html={site.headCode} />
      </head>
      <body>
        {children}
        {site.bodyEndCode ? <div dangerouslySetInnerHTML={{ __html: site.bodyEndCode }} /> : null}
      </body>
    </html>
  );
}
