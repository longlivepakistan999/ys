import { prisma } from "@/lib/db";
import { getSettings, secrets } from "@/lib/settings";
import { countFor, PER_FILE, TYPES } from "@/lib/seo/sitemaps";
import { addRedirect, deleteRedirect, runReindex, saveRobots, saveTemplates, saveThresholds } from "../../actions";
import { Notice, St, Top, fmt, when, type SP } from "../../ui";

const TPL_LABELS: Record<string, [string, string]> = {
  movie: ["电影详情", "{title} {year}"], movieUpcoming: ["未上映电影", "{title} {year}"], tv: ["剧集", "{title} {years}"],
  season: ["季", "{show} {season} {episodes}"], episode: ["集", "{show} {season} {episode} {name} {code}"],
  person: ["演员", "{name}"], page: ["分页（第 2 页起）", "{list_title} {page}"],
};

export default async function SeoPage({ searchParams }: { searchParams: SP }) {
  const s = await getSettings(0);
  const { siteUrl } = await secrets();
  const weekAgo = new Date(Date.now() - 7 * 86_400_000);
  const [counts, redirects, terms, lastPush] = await Promise.all([
    Promise.all(TYPES.map(async (t) => [t, t === "lists" ? null : await countFor(t)] as const)),
    prisma.redirect.findMany({ orderBy: { createdAt: "desc" }, take: 100 }),
    prisma.searchTerm.groupBy({ by: ["term"], where: { day: { gte: weekAgo } }, _sum: { count: true }, orderBy: { _sum: { count: "desc" } }, take: 20 }),
    prisma.syncRun.findFirst({ where: { finishedAt: { not: null } }, orderBy: { finishedAt: "desc" }, select: { urlsPushed: true, finishedAt: true } }),
  ]);
  const totalUrls = counts.reduce((n, [, c]) => n + (c ?? 0), 0);

  return (
    <>
      <Top eyebrow="SEO 管理" title="SEO 管理" sub="全部自动运行；这里调整模板和门槛" />
      <Notice sp={searchParams} />
      <nav className="subnav" aria-label="SEO 分区"><a href="#tpl">标题模板</a><a href="#rules">索引规则</a><a href="#sitemap">Sitemap</a><a href="#redirects">301 重定向</a><a href="#robots">robots.txt</a><a href="#terms">热门搜索词</a></nav>

      <form className="panel" id="tpl" action={saveTemplates}>
        <div className="panel-head"><div><h2>Title 模板</h2><p>每个标题后面自动加上 “| {s.siteName}”。花括号里是可用变量</p></div></div>
        <div className="panel-body form-grid">
          {Object.entries(s.seoTemplates).map(([k, v]) => (
            <div className="f full" key={k}>
              <label htmlFor={`t-${k}`}>{TPL_LABELS[k]?.[0] ?? k}</label>
              <input className="field mono" id={`t-${k}`} name={k} defaultValue={v} />
              <span className="hint">变量：{TPL_LABELS[k]?.[1]}</span>
            </div>
          ))}
        </div>
        <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存模板</button></div>
      </form>

      <div className="cols">
        <form className="panel" id="rules" action={saveThresholds}>
          <div className="panel-head"><div><h2>索引门槛</h2><p>不达标的页面输出 noindex,follow 且不进 sitemap</p></div></div>
          <div className="panel-body form-grid">
            <div className="f"><label htmlFor="r1">电影 / 剧集：缺简介或海报时的最低评分人数</label><input className="field" id="r1" name="minVotes" type="number" defaultValue={s.minVotesWithoutFullData} /></div>
            <div className="f"><label htmlFor="r2">集页：无简介、无剧照时所属剧集的最低热度</label><input className="field" id="r2" name="minShowPop" type="number" defaultValue={s.minShowPopularityForThinEpisodes} /></div>
            <div className="f"><label htmlFor="r3">演员页：最少作品数</label><input className="field" id="r3" name="minCredits" type="number" defaultValue={s.minPersonCredits} /></div>
            <div className="f"><label htmlFor="r4">聚合页：最少片数</label><input className="field" id="r4" name="minList" type="number" defaultValue={s.minListSize} /></div>
            <div className="f"><label htmlFor="r5">Top Rated 电影最低评分人数</label><input className="field" id="r5" name="topMovie" type="number" defaultValue={s.topRatedMinVotesMovie} /></div>
            <div className="f"><label htmlFor="r6">Top Rated 剧集最低评分人数</label><input className="field" id="r6" name="topTv" type="number" defaultValue={s.topRatedMinVotesTv} /></div>
            <div className="f"><label htmlFor="r7">列表最多开放页数</label><input className="field" id="r7" name="maxPages" type="number" defaultValue={s.maxListPages} /></div>
            <div className="f"><label htmlFor="r8">每页条数</label><input className="field" id="r8" name="perPage" type="number" defaultValue={s.perPage} /></div>
          </div>
          <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存门槛</button></div>
        </form>
        <section className="panel" id="sitemap">
          <div className="panel-head"><div><h2>Sitemap</h2><p><a className="section-link" href="/sitemap.xml" target="_blank" rel="noopener">{siteUrl}/sitemap.xml</a> · 共 {fmt(totalUrls)} 个网址 · 每个文件 ≤ {fmt(PER_FILE)}</p></div>
            <form action={runReindex}><button className="btn btn-sm" type="submit">重新计算索引</button></form></div>
          <div className="table-wrap"><table className="t">
            <thead><tr><th>类型</th><th className="n">可索引网址</th><th className="n">文件数</th></tr></thead>
            <tbody>{counts.map(([t, c]) => <tr key={t}><td className="code">{t}</td><td className="n">{c === null ? "聚合页" : fmt(c)}</td><td className="n">{c === null ? 1 : Math.max(1, Math.ceil(c / PER_FILE))}</td></tr>)}</tbody>
          </table></div>
          <div className="panel-body" style={{ borderTop: "1px solid var(--line)" }}>
            <dl className="kv"><dt>IndexNow</dt><dd>{lastPush ? `上次推送 ${fmt(lastPush.urlsPushed)} 个网址（${when(lastPush.finishedAt)} UTC）` : "还没有推送记录"}</dd>
              <dt>Search Console</dt><dd>验证代码填在 站点设置 › 代码插入</dd></dl>
          </div>
        </section>
      </div>

      <div className="cols">
        <section className="panel" id="redirects">
          <div className="panel-head"><div><h2>301 重定向</h2><p>slug 变化时网址会自动纠正，这里只放额外的手动规则</p></div></div>
          <div className="table-wrap"><table className="t">
            <thead><tr><th>旧网址</th><th>新网址</th><th>来源</th><th></th></tr></thead>
            <tbody>
              {redirects.length === 0 && <tr><td colSpan={4} className="muted">没有手动重定向。</td></tr>}
              {redirects.map((r) => (
                <tr key={r.oldPath}><td className="code">{r.oldPath}</td><td className="code">{r.newPath}</td><td>{r.source}</td>
                  <td><form action={deleteRedirect}><input type="hidden" name="from" value={r.oldPath} /><button className="btn btn-sm" type="submit">删除</button></form></td></tr>
              ))}
            </tbody>
          </table></div>
          <form className="panel-foot" style={{ justifyContent: "stretch" }} action={addRedirect}>
            <input className="field" style={{ flex: "1 1 160px", minWidth: 0 }} name="from" placeholder="/旧网址" aria-label="旧网址" required />
            <input className="field" style={{ flex: "1 1 160px", minWidth: 0 }} name="to" placeholder="/新网址" aria-label="新网址" required />
            <button className="btn btn-sm" type="submit">添加</button>
          </form>
        </section>
        <form className="panel" id="robots" action={saveRobots}>
          <div className="panel-head"><div><h2>robots.txt</h2><p>Sitemap 行自动追加，不用写</p></div></div>
          <div className="panel-body"><textarea className="field" name="robots" rows={14} aria-label="robots.txt" defaultValue={s.robotsTxt} /></div>
          <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存</button></div>
        </form>
      </div>

      <section className="panel" id="terms">
        <div className="panel-head"><div><h2>站内热门搜索词（近 7 天）</h2><p>经常被搜索却没有对应聚合页的词，可以考虑新增页面</p></div></div>
        <div className="table-wrap"><table className="t">
          <thead><tr><th>搜索词</th><th className="n">次数</th></tr></thead>
          <tbody>
            {terms.length === 0 && <tr><td colSpan={2} className="muted">还没有搜索记录。</td></tr>}
            {terms.map((t) => <tr key={t.term}><td>{t.term}</td><td className="n">{fmt(t._sum.count ?? 0)}</td></tr>)}
          </tbody>
        </table></div>
      </section>
      {terms.length > 0 && <p className="muted"><St kind="">提示</St> 热门搜索词只做参考，搜索结果页本身不收录。</p>}
    </>
  );
}
