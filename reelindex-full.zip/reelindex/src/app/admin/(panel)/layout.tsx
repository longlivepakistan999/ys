import Link from "next/link";
import type { ReactNode } from "react";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin/auth";
import { adminBase } from "@/lib/admin/session";
import { getSite } from "@/lib/site";
import { logout } from "../actions";
import { AdminNav } from "../AdminNav";

export default async function Panel({ children }: { children: ReactNode }) {
  const acc = await requireAdmin();
  const [site, failures] = await Promise.all([getSite(), prisma.syncFailure.count()]);
  const base = adminBase();
  return (
    <div className="admin">
      <aside className="sidebar">
        <Link className="logo" href={base}>{site.name}<small>ADMIN</small></Link>
        <AdminNav base={base} failures={failures} />
        <div className="side-foot">
          {acc.username} · <form action={logout} style={{ display: "inline" }}><button type="submit" className="section-link" style={{ background: "none", border: 0, padding: 0, cursor: "pointer", font: "inherit" }}>退出</button></form>
          <br /><a href="/" target="_blank" rel="noopener">查看网站 &nearr;</a>
        </div>
      </aside>
      <main className="admin-main">{children}</main>
    </div>
  );
}
