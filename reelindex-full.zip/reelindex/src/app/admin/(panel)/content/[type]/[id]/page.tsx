import Link from "next/link";
import { Fragment } from "react";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { adminBase } from "@/lib/admin/session";
import { fillTemplate, getSettings } from "@/lib/settings";
import { paths } from "@/lib/slug";
import { purgeContent, refreshItem, saveContent } from "../../../../actions";
import { Notice, St, Top, ago, fmt, when, type SP } from "../../../../ui";

type Props = { params: Promise<{ type: string; id: string }>; searchParams: SP };

export default async function EditContent({ params, searchParams }: Props) {
  const { type, id: raw } = await params;
  const id = Number(raw);
  const base = adminBase();
  const s = await getSettings();
  let row: {
    name: string; tmdbTitle: string; href: string; indexable: boolean; override: string; hidden: boolean; removed: boolean;
    titleOverride?: string | null; seoTitleOverride?: string | null; overviewOverride?: string | null; overview?: string | null;
    autoTitle?: string; synced: Date | null; facts: [string, string][]; checks: [string, boolean][];
  } | null = null;

  if (type === "movie") {
    const m = await prisma.movie.findUnique({ where: { id } });
    if (m) row = {
      name: m.titleOverride || m.title, tmdbTitle: m.title, href: paths.movie(m.id, m.slug, m.year), indexable: m.isIndexable, override: m.indexOverride, hidden: m.hidden, removed: !!m.removedAt,
      titleOverride: m.titleOverride, seoTitleOverride: m.seoTitleOverride, overviewOverride: m.overviewOverride, overview: m.overview,
      autoTitle: fillTemplate(s.seoTemplates.movie, { title: m.titleOverride || m.title, year: m.year }) + ` | ${s.siteName}`, synced: m.detailSyncedAt,
      facts: [["类型", "电影"], ["TMDB ID", String(m.id)], ["年份", String(m.year ?? "—")], ["评分", `${m.rating} (${fmt(m.voteCount)} 票)`], ["热度", m.popularity.toFixed(1)], ["网址", paths.movie(m.id, m.slug, m.year)]],
      checks: [["有简介", !!m.overview], ["有海报", !!m.posterPath], [`评分人数 ${fmt(m.voteCount)}（门槛 ${s.minVotesWithoutFullData}）`, m.voteCount >= s.minVotesWithoutFullData]],
    };
  } else if (type === "tv") {
    const t = await prisma.tvShow.findUnique({ where: { id } });
    if (t) {
      const [eps, idxEps] = await Promise.all([prisma.episode.count({ where: { showId: id } }), prisma.episode.count({ where: { showId: id, isIndexable: true } })]);
      row = {
        name: t.titleOverride || t.name, tmdbTitle: t.name, href: paths.tv(t.id, t.slug), indexable: t.isIndexable, override: t.indexOverride, hidden: t.hidden, removed: !!t.removedAt,
        titleOverride: t.titleOverride, seoTitleOverride: t.seoTitleOverride, overviewOverride: t.overviewOverride, overview: t.overview,
        autoTitle: fillTemplate(s.seoTemplates.tv, { title: t.titleOverride || t.name, years: t.firstAirYear ? `${t.firstAirYear}–` : "" }) + ` | ${s.siteName}`, synced: t.detailSyncedAt,
        facts: [["类型", "剧集"], ["TMDB ID", String(t.id)], ["状态", `${t.status ?? "—"} · ${t.isTracking ? "追踪中" : "已停止追踪"}`], ["季 / 集", `${t.numberOfSeasons} / ${t.numberOfEpisodes}`], ["已入库的集", `${fmt(eps)}（可索引 ${fmt(idxEps)}）`], ["网址", paths.tv(t.id, t.slug)]],
        checks: [["有简介", !!t.overview], ["有海报", !!t.posterPath], [`评分人数 ${fmt(t.voteCount)}（门槛 ${s.minVotesWithoutFullData}）`, t.voteCount >= s.minVotesWithoutFullData]],
      };
    }
  } else if (type === "person") {
    const p = await prisma.person.findUnique({ where: { id } });
    if (p) row = {
      name: p.name, tmdbTitle: p.name, href: paths.person(p.id, p.slug), indexable: p.isIndexable, override: p.indexOverride, hidden: p.hidden, removed: !!p.removedAt, synced: p.detailSyncedAt,
      facts: [["类型", "演员"], ["TMDB ID", String(p.id)], ["作品数", String(p.creditCount)], ["网址", paths.person(p.id, p.slug)]],
      checks: [["有头像", !!p.profilePath], [`作品数 ${p.creditCount}（门槛 ${s.minPersonCredits}）`, p.creditCount >= s.minPersonCredits]],
    };
  }
  if (!row) notFound();
  const editable = type === "movie" || type === "tv";

  return (
    <>
      <Top eyebrow="内容管理" title={`编辑：${row.name}`} sub={<Link href={`${base}/content?type=${type}`}>&larr; 返回内容列表</Link>}
        actions={<a className="btn btn-sm" href={row.href} target="_blank" rel="noopener">查看页面</a>} />
      <Notice sp={searchParams} />
      <div className="cols" style={{ gridTemplateColumns: "minmax(0,2fr) minmax(0,1fr)" }}>
        <form className="panel" action={saveContent}>
          <input type="hidden" name="type" value={type} /><input type="hidden" name="id" value={id} />
          <div className="panel-head"><div><h2>页面设置</h2><p>留空则使用 TMDB 数据和 SEO 模板；填写后每日同步不会覆盖</p></div></div>
          <div className="panel-body form-grid">
            {editable && <>
              <div className="f full"><label htmlFor="e-title">显示标题</label><input className="field" id="e-title" name="titleOverride" defaultValue={row.titleOverride ?? ""} placeholder={row.tmdbTitle} /><span className="hint">TMDB：{row.tmdbTitle}</span></div>
              <div className="f full"><label htmlFor="e-seo">SEO 标题（覆盖模板）</label><input className="field" id="e-seo" name="seoTitleOverride" defaultValue={row.seoTitleOverride ?? ""} placeholder="留空使用模板" /><div className="preview-line">当前模板生成：{row.autoTitle}</div></div>
              <div className="f full"><label htmlFor="e-desc">简介</label><textarea className="field" id="e-desc" name="overviewOverride" rows={4} style={{ fontFamily: "var(--body)", fontSize: 14 }} defaultValue={row.overviewOverride ?? ""} placeholder={row.overview ?? "留空使用 TMDB 简介"} /></div>
            </>}
            <div className="f"><span className="lbl">索引</span>
              <div className="radios">
                <label><input type="radio" name="indexOverride" value="AUTO" defaultChecked={row.override === "AUTO"} /> 自动</label>
                <label><input type="radio" name="indexOverride" value="FORCE_INDEX" defaultChecked={row.override === "FORCE_INDEX"} /> 强制索引</label>
                <label><input type="radio" name="indexOverride" value="FORCE_NOINDEX" defaultChecked={row.override === "FORCE_NOINDEX"} /> 强制不索引</label>
              </div></div>
            <div className="f full"><label style={{ display: "flex", alignItems: "center", gap: 10 }}><input className="switch" type="checkbox" name="hidden" defaultChecked={row.hidden} /> 下架此内容</label>
              <span className="hint">下架后页面返回 404 并移出 sitemap{type === "tv" ? "，季页和集页一并下架" : ""}</span></div>
          </div>
          <div className="panel-foot"><Link className="btn btn-sm" href={`${base}/content?type=${type}`}>取消</Link><button className="btn btn-sm btn-primary" type="submit">保存</button></div>
        </form>
        <div style={{ display: "grid", gap: 20 }}>
          <section className="panel">
            <div className="panel-head"><h2>{row.tmdbTitle}</h2>{row.removed ? <St kind="bad">TMDB 已删除</St> : row.hidden ? <St kind="bad">已下架</St> : <St kind={row.indexable ? "ok" : ""}>{row.indexable ? "可索引" : "不索引"}</St>}</div>
            <div className="panel-body"><dl className="kv">{row.facts.map(([k, v]) => <Fragment key={k}><dt>{k}</dt><dd className={k === "网址" ? "mono" : undefined} style={k === "网址" ? { fontSize: 12 } : undefined}>{v}</dd></Fragment>)}
              <dt>最近同步</dt><dd>{when(row.synced)} UTC（{ago(row.synced)}）</dd></dl></div>
            <div className="panel-foot">
              <form action={refreshItem}><input type="hidden" name="type" value={type} /><input type="hidden" name="id" value={id} /><input type="hidden" name="from" value={`/content/${type}/${id}`} /><button className="btn btn-sm" type="submit">从 TMDB 刷新</button></form>
              <form action={purgeContent}><input type="hidden" name="type" value={type} /><input type="hidden" name="id" value={id} /><button className="btn btn-sm" type="submit">清除缓存</button></form>
            </div>
          </section>
          <section className="panel"><div className="panel-head"><h2>自动索引判定</h2></div>
            <div className="panel-body"><div className="checks">{row.checks.map(([k, ok]) => <span key={k} style={{ color: ok ? "var(--good)" : "var(--muted)" }}>{ok ? "✓" : "✗"} {k}</span>)}</div></div></section>
        </div>
      </div>
    </>
  );
}
