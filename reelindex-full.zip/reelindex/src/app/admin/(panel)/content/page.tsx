import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { adminBase } from "@/lib/admin/session";
import { paths } from "@/lib/slug";
import { Poster } from "@/components/ui";
import { Notice, St, Top, fmt, when, type SP } from "../../ui";

const PER = 30;

export default async function ContentPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const type = sp.type === "tv" ? "tv" : sp.type === "person" ? "person" : "movie";
  const idx = typeof sp.idx === "string" ? sp.idx : "";
  const vis = typeof sp.vis === "string" ? sp.vis : "";
  const page = Math.max(1, Number(sp.page) || 1);
  const base = adminBase();
  const idNum = /^\d+$/.test(q) ? Number(q) : null;

  const common = {
    ...(idx === "yes" ? { isIndexable: true } : idx === "no" ? { isIndexable: false } : {}),
    ...(idx === "force" ? { indexOverride: { not: "AUTO" as const } } : {}),
    ...(vis === "hidden" ? { hidden: true } : vis === "removed" ? { removedAt: { not: null } } : vis === "live" ? { hidden: false, removedAt: null } : {}),
  };
  let rows: { id: number; title: string; year: string; poster: string | null; indexable: boolean; override: string; hidden: boolean; removed: boolean; synced: Date | null; href: string }[] = [];
  let total = 0;
  if (type === "movie") {
    const where: Prisma.MovieWhereInput = { ...common, ...(idNum ? { id: idNum } : q ? { title: { contains: q, mode: "insensitive" } } : {}) };
    const [list, n] = await Promise.all([prisma.movie.findMany({ where, orderBy: { popularity: "desc" }, skip: (page - 1) * PER, take: PER }), prisma.movie.count({ where })]);
    total = n;
    rows = list.map((m) => ({ id: m.id, title: m.title, year: m.year ? String(m.year) : "", poster: m.posterPath, indexable: m.isIndexable, override: m.indexOverride, hidden: m.hidden, removed: !!m.removedAt, synced: m.detailSyncedAt, href: paths.movie(m.id, m.slug, m.year) }));
  } else if (type === "tv") {
    const where: Prisma.TvShowWhereInput = { ...common, ...(idNum ? { id: idNum } : q ? { name: { contains: q, mode: "insensitive" } } : {}) };
    const [list, n] = await Promise.all([prisma.tvShow.findMany({ where, orderBy: { popularity: "desc" }, skip: (page - 1) * PER, take: PER }), prisma.tvShow.count({ where })]);
    total = n;
    rows = list.map((t) => ({ id: t.id, title: t.name, year: t.firstAirYear ? String(t.firstAirYear) : "", poster: t.posterPath, indexable: t.isIndexable, override: t.indexOverride, hidden: t.hidden, removed: !!t.removedAt, synced: t.detailSyncedAt, href: paths.tv(t.id, t.slug) }));
  } else {
    const where: Prisma.PersonWhereInput = { ...common, ...(idNum ? { id: idNum } : q ? { name: { contains: q, mode: "insensitive" } } : {}) };
    const [list, n] = await Promise.all([prisma.person.findMany({ where, orderBy: { popularity: "desc" }, skip: (page - 1) * PER, take: PER }), prisma.person.count({ where })]);
    total = n;
    rows = list.map((p) => ({ id: p.id, title: p.name, year: p.knownFor ?? "", poster: p.profilePath, indexable: p.isIndexable, override: p.indexOverride, hidden: p.hidden, removed: !!p.removedAt, synced: p.detailSyncedAt, href: paths.person(p.id, p.slug) }));
  }
  const pages = Math.max(1, Math.ceil(total / PER));
  const qs = (p: number) => `${base}/content?${new URLSearchParams({ q, type, idx, vis, page: String(p) })}`;
  const label = { movie: "电影", tv: "剧集", person: "演员" }[type];

  return (
    <>
      <Top eyebrow="内容管理" title="内容管理" sub="搜索、修改、强制索引或下架单条内容" actions={<Link className="btn btn-sm btn-primary" href={`${base}/sync`}>按 TMDB ID 添加</Link>} />
      <Notice sp={searchParams} />
      <form className="panel panel-body" style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "flex-end" }} method="get">
        <div className="f" style={{ flex: "2 1 240px" }}><label htmlFor="c-q">片名或 TMDB ID</label><input className="field" id="c-q" name="q" type="search" defaultValue={q} placeholder="例如 Fight Club 或 550" /></div>
        <div className="f" style={{ flex: "1 1 120px" }}><label htmlFor="c-type">类型</label>
          <select className="field" id="c-type" name="type" defaultValue={type}><option value="movie">电影</option><option value="tv">剧集</option><option value="person">演员</option></select></div>
        <div className="f" style={{ flex: "1 1 150px" }}><label htmlFor="c-idx">索引状态</label>
          <select className="field" id="c-idx" name="idx" defaultValue={idx}><option value="">全部</option><option value="yes">可索引</option><option value="no">不索引</option><option value="force">手动强制</option></select></div>
        <div className="f" style={{ flex: "1 1 130px" }}><label htmlFor="c-vis">显示状态</label>
          <select className="field" id="c-vis" name="vis" defaultValue={vis}><option value="">全部</option><option value="live">正常</option><option value="hidden">已下架</option><option value="removed">TMDB 已删除</option></select></div>
        <button className="btn btn-primary" type="submit">筛选</button>
      </form>
      <section className="panel">
        <div className="panel-head"><h2>{label}</h2><span className="mono muted">共 {fmt(total)} 条 · 第 {page} / {fmt(pages)} 页</span></div>
        <div className="table-wrap"><table className="t">
          <thead><tr><th>标题</th><th>TMDB ID</th><th>索引</th><th>状态</th><th>最近同步（UTC）</th><th>操作</th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={6} className="muted">没有匹配的内容。</td></tr>}
            {rows.map((r) => (
              <tr key={r.id}>
                <td><div className="title-cell"><Poster title={r.title} path={r.poster} size="w92" mini /><div><Link href={`${base}/content/${type}/${r.id}`}>{r.title}</Link><div className="muted" style={{ fontSize: 12 }}>{r.year}</div></div></div></td>
                <td className="code">{r.id}</td>
                <td><St kind={r.indexable ? "ok" : ""}>{r.indexable ? "可索引" : "不索引"}{r.override !== "AUTO" ? " · 强制" : ""}</St></td>
                <td>{r.removed ? <St kind="bad">TMDB 已删除</St> : r.hidden ? <St kind="bad">已下架</St> : <St kind="ok">正常</St>}</td>
                <td className="code">{when(r.synced)}</td>
                <td><Link href={`${base}/content/${type}/${r.id}`}>编辑</Link> · <a href={r.href} target="_blank" rel="noopener">查看</a></td>
              </tr>
            ))}
          </tbody>
        </table></div>
        <div className="panel-foot">
          {page > 1 && <Link className="btn btn-sm" href={qs(page - 1)}>上一页</Link>}
          {page < pages && <Link className="btn btn-sm" href={qs(page + 1)}>下一页</Link>}
        </div>
      </section>
    </>
  );
}
