import { prisma } from "@/lib/db";
import { getAccount } from "@/lib/admin/auth";
import { otpauthUri } from "@/lib/admin/crypto";
import { DEFAULT_SETTINGS, getSettings, secrets } from "@/lib/settings";
import { changePassword, saveCode, saveKeys, saveSite, saveTelegram, testTelegram, totpBegin, totpConfirm, totpDisable } from "../../actions";
import { Notice, St, Top, when, type SP } from "../../ui";

const EVENTS: [keyof typeof DEFAULT_SETTINGS.telegramEvents, string][] = [
  ["dailySummary", "每日同步完成摘要（新增数、失败数）"], ["syncFailed", "同步失败或部分失败"], ["rateLimited", "TMDB 限流（429）"],
  ["sitemapFailed", "sitemap 生成失败"], ["staleData", "数据超过期限未刷新"], ["crawlerSpike", "爬虫请求异常激增"],
  ["loginSuccess", "后台登录成功"], ["loginLocked", "后台登录失败被锁定"],
];
const mask = (v: string) => (v ? `已设置（…${v.slice(-4)}）` : "未设置");

export default async function SettingsPage({ searchParams }: { searchParams: SP }) {
  const [s, sec, acc, logs] = await Promise.all([getSettings(0), secrets(), getAccount(), prisma.adminLog.findMany({ orderBy: { createdAt: "desc" }, take: 20 })]);
  return (
    <>
      <Top eyebrow="站点设置" title="站点设置" />
      <Notice sp={searchParams} />
      <nav className="subnav" aria-label="设置分区"><a href="#site">站点信息</a><a href="#api">接口密钥</a><a href="#telegram">Telegram 告警</a><a href="#code">代码插入</a><a href="#account">管理员</a></nav>
      <div className="cols">
        <form className="panel" id="site" action={saveSite}>
          <div className="panel-head"><div><h2>站点信息</h2><p>站名和域名用于标题、canonical、sitemap 和结构化数据</p></div></div>
          <div className="panel-body form-grid">
            <div className="f"><label htmlFor="s-name">站名</label><input className="field" id="s-name" name="siteName" defaultValue={s.siteName} /></div>
            <div className="f"><label htmlFor="s-domain">域名</label><input className="field" id="s-domain" name="siteUrl" defaultValue={s.siteUrl} placeholder={sec.siteUrl} /><span className="hint">留空使用环境变量 SITE_URL</span></div>
            <div className="f full"><label htmlFor="s-foot">页脚简介</label><input className="field" id="s-foot" name="footerText" defaultValue={s.footerText} /></div>
            <div className="f full"><label htmlFor="s-log">Nginx 访问日志路径</label><input className="field mono" id="s-log" name="nginxLogPath" defaultValue={s.nginxLogPath} /><span className="hint">仪表盘的爬虫统计从这里读取</span></div>
            <div className="f full"><span className="hint">Logo 和 Favicon：替换 public/favicon.svg；TMDB 与 JustWatch 署名固定显示在页脚。</span></div>
          </div>
          <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存</button></div>
        </form>
        <form className="panel" id="api" action={saveKeys}>
          <div className="panel-head"><div><h2>接口密钥</h2><p>只在服务端使用。留空表示保留当前值</p></div></div>
          <div className="panel-body form-grid">
            <div className="f full"><label htmlFor="k-tmdb">TMDB API Read Access Token</label><input className="field mono" id="k-tmdb" name="tmdbToken" type="password" autoComplete="off" placeholder={mask(sec.tmdbToken)} /></div>
            <div className="f"><label htmlFor="k-cf">Cloudflare API Token</label><input className="field mono" id="k-cf" name="cloudflareToken" type="password" autoComplete="off" placeholder={mask(sec.cloudflareToken)} /><span className="hint">权限：Cache Purge</span></div>
            <div className="f"><label htmlFor="k-zone">Cloudflare Zone ID</label><input className="field mono" id="k-zone" name="cloudflareZone" placeholder={sec.cloudflareZone || "未设置"} /></div>
            <div className="f"><label htmlFor="k-in">IndexNow Key</label><input className="field mono" id="k-in" name="indexNowKey" placeholder={sec.indexNowKey || "8–128 位字母数字"} /><span className="hint">网站会在 /indexnow-key.txt 输出这个 Key</span></div>
          </div>
          <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存并验证</button></div>
        </form>
      </div>
      <div className="cols">
        <section className="panel" id="telegram">
          <form action={saveTelegram}>
            <div className="panel-head"><div><h2>Telegram 告警</h2><p>通过 Bot 推送到你的私聊或群组</p></div>{sec.telegramBotToken && sec.telegramChatId ? <St kind="ok">已配置</St> : <St kind="">未配置</St>}</div>
            <div className="panel-body form-grid">
              <div className="f"><label htmlFor="tg-token">Bot Token</label><input className="field mono" id="tg-token" name="botToken" type="password" autoComplete="off" placeholder={mask(sec.telegramBotToken)} /></div>
              <div className="f"><label htmlFor="tg-chat">Chat ID</label><input className="field mono" id="tg-chat" name="chatId" defaultValue={s.telegramChatId || sec.telegramChatId} /></div>
              <div className="f full"><span className="lbl">推送这些事件</span>
                <div className="checks">{EVENTS.map(([k, l]) => <label key={k}><input type="checkbox" name={`ev_${k}`} defaultChecked={s.telegramEvents[k]} /> {l}</label>)}</div></div>
            </div>
            <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存</button></div>
          </form>
          <form action={testTelegram} className="panel-foot" style={{ borderTop: 0, paddingTop: 0 }}><button className="btn btn-sm" type="submit">发送测试消息</button></form>
        </section>
        <form className="panel" id="code" action={saveCode}>
          <div className="panel-head"><div><h2>代码插入</h2><p>网站统计、站长验证等；每个页面都会输出</p></div></div>
          <div className="panel-body form-grid">
            <div className="f full"><label htmlFor="c-head">&lt;head&gt; 内</label><textarea className="field" id="c-head" name="headCode" rows={6} defaultValue={s.headCode} placeholder={'<meta name="google-site-verification" content="…">\n<script async src="…"></script>'} /><span className="hint">支持 &lt;meta&gt;、&lt;link&gt;、&lt;script&gt;</span></div>
            <div className="f full"><label htmlFor="c-body">&lt;/body&gt; 前</label><textarea className="field" id="c-body" name="bodyEndCode" rows={4} defaultValue={s.bodyEndCode} /></div>
          </div>
          <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存</button></div>
        </form>
      </div>
      <section className="panel" id="account">
        <div className="panel-head"><div><h2>管理员</h2><p>单一管理员账号</p></div>{acc?.totpEnabled ? <St kind="ok">两步验证已开启</St> : <St kind="warn">两步验证未开启</St>}</div>
        <div className="panel-body cols">
          <form className="form-grid" action={changePassword}>
            <div className="f"><label htmlFor="a-user">用户名</label><input className="field" id="a-user" name="username" defaultValue={acc?.username} autoComplete="username" /></div>
            <div className="f"><label htmlFor="a-old">当前密码</label><input className="field" id="a-old" name="current" type="password" autoComplete="current-password" required /></div>
            <div className="f"><label htmlFor="a-new">新密码</label><input className="field" id="a-new" name="next" type="password" autoComplete="new-password" minLength={12} required /><span className="hint">至少 12 位；修改后其他设备会退出登录</span></div>
            <div className="f full" style={{ justifyItems: "start" }}><button className="btn btn-primary" type="submit">修改密码</button></div>
          </form>
          <div style={{ display: "grid", gap: 14, alignContent: "start" }}>
            <span className="lbl" style={{ fontWeight: 600, fontSize: 13 }}>两步验证（身份验证器 App）</span>
            {!acc?.totpEnabled && !acc?.pendingTotpSecret && <form action={totpBegin}><button className="btn" type="submit">开启两步验证</button></form>}
            {!acc?.totpEnabled && acc?.pendingTotpSecret && (
              <form className="form-grid" action={totpConfirm}>
                <div className="f full"><span className="lbl">在 App 里手动添加这个密钥</span><div className="preview-line">{acc.pendingTotpSecret}</div>
                  <span className="hint">或复制链接：<span className="mono" style={{ wordBreak: "break-all" }}>{otpauthUri(acc.pendingTotpSecret, acc.username, s.siteName)}</span></span></div>
                <div className="f"><label htmlFor="otp">App 显示的 6 位验证码</label><input className="field" id="otp" name="code" inputMode="numeric" maxLength={6} required /></div>
                <div className="f" style={{ alignSelf: "end" }}><button className="btn btn-primary" type="submit">确认开启</button></div>
              </form>
            )}
            {acc?.totpEnabled && (
              <form className="inline-form" action={totpDisable}>
                <input className="field" name="current" type="password" placeholder="输入当前密码以关闭" aria-label="当前密码" autoComplete="current-password" required />
                <button className="btn" type="submit">关闭两步验证</button>
              </form>
            )}
          </div>
        </div>
        <div className="panel-body" style={{ borderTop: "1px solid var(--line)" }}>
          <span className="lbl" style={{ fontWeight: 600, fontSize: 13 }}>操作日志</span>
          <div className="table-wrap"><table className="t">
            <thead><tr><th>时间（UTC）</th><th>操作</th><th>IP</th></tr></thead>
            <tbody>{logs.map((l) => <tr key={l.id}><td className="code">{when(l.createdAt)}</td><td>{l.action}</td><td className="code">{l.ip}</td></tr>)}</tbody>
          </table></div>
        </div>
      </section>
    </>
  );
}
