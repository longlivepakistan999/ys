import { prisma } from "@/lib/db";
import { paths } from "@/lib/slug";
import { addSource, deleteSource, toggleSource } from "../../actions";
import { Notice, St, Top, fmt, when, type SP } from "../../ui";

const KIND: Record<string, string> = { hls: "HLS", mp4: "MP4", iframe: "嵌入播放器" };

export default async function SourcesPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page) || 1);
  const [rows, total] = await Promise.all([
    prisma.videoSource.findMany({ orderBy: { createdAt: "desc" }, skip: (page - 1) * 50, take: 50 }),
    prisma.videoSource.count(),
  ]);
  const movieIds = rows.filter((r) => r.mediaType === "movie").map((r) => r.tmdbId);
  const epIds = rows.filter((r) => r.mediaType === "episode").map((r) => r.tmdbId);
  const [movies, eps] = await Promise.all([
    prisma.movie.findMany({ where: { id: { in: movieIds } }, select: { id: true, title: true, slug: true, year: true } }),
    prisma.episode.findMany({ where: { id: { in: epIds } }, select: { id: true, seasonNumber: true, episodeNumber: true, show: { select: { id: true, name: true, slug: true } } } }),
  ]);
  const mMap = new Map(movies.map((m) => [m.id, m]));
  const eMap = new Map(eps.map((e) => [e.id, e]));
  const label = (r: (typeof rows)[number]) => {
    if (r.mediaType === "movie") { const m = mMap.get(r.tmdbId); return m ? [`${m.title}${m.year ? ` (${m.year})` : ""}`, `${paths.movie(m.id, m.slug, m.year)}/watch`] : [`电影 ${r.tmdbId}`, ""]; }
    const e = eMap.get(r.tmdbId);
    return e ? [`${e.show.name} S${String(e.seasonNumber).padStart(2, "0")}E${String(e.episodeNumber).padStart(2, "0")}`, `${paths.episode(e.show.id, e.show.slug, e.seasonNumber, e.episodeNumber)}/watch`] : [`集 ${r.tmdbId}`, ""];
  };

  return (
    <>
      <Top eyebrow="播放片源" title="播放片源" sub="电影和剧集播放页使用的视频；只添加你自己拥有或已获授权的内容" />
      <Notice sp={searchParams} />
      <form className="panel" action={addSource}>
        <div className="panel-head"><div><h2>添加片源</h2><p>同一部电影或同一集可以添加多个片源，播放页显示为切换按钮</p></div></div>
        <div className="panel-body form-grid">
          <div className="f"><label htmlFor="v-type">内容类型</label><select className="field" id="v-type" name="mediaType" defaultValue="movie"><option value="movie">电影</option><option value="episode">剧集的某一集</option></select></div>
          <div className="f"><label htmlFor="v-movie">电影 TMDB ID</label><input className="field" id="v-movie" name="movieId" inputMode="numeric" placeholder="内容类型为电影时填写" /></div>
          <div className="f"><label htmlFor="v-show">剧集 TMDB ID · 季 · 集</label>
            <div className="inline-form"><input className="field" id="v-show" name="showId" inputMode="numeric" placeholder="剧集 ID" aria-label="剧集 TMDB ID" />
              <input className="field" name="season" inputMode="numeric" placeholder="季" aria-label="季" style={{ flex: "0 0 70px" }} />
              <input className="field" name="episode" inputMode="numeric" placeholder="集" aria-label="集" style={{ flex: "0 0 70px" }} /></div></div>
          <div className="f"><label htmlFor="v-kind">片源类型</label><select className="field" id="v-kind" name="kind" defaultValue="hls"><option value="hls">HLS（.m3u8）</option><option value="mp4">MP4 文件</option><option value="iframe">授权合作方的嵌入播放器</option></select></div>
          <div className="f full"><label htmlFor="v-url">片源地址</label><input className="field mono" id="v-url" name="url" type="url" placeholder="https://" required /></div>
          <div className="f"><label htmlFor="v-label">按钮名称</label><input className="field" id="v-label" name="label" placeholder="Server 1" /></div>
          <div className="f"><label htmlFor="v-pri">排序（小的在前）</label><input className="field" id="v-pri" name="priority" type="number" defaultValue={0} /></div>
          <div className="f full"><label htmlFor="v-rights">授权说明</label><input className="field" id="v-rights" name="rightsNote" placeholder="版权方 / 授权方、授权地区、到期时间" required /><span className="hint">必填，用于记录这条片源的播放授权</span></div>
        </div>
        <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">添加</button></div>
      </form>
      <section className="panel">
        <div className="panel-head"><h2>全部片源</h2><span className="mono muted">共 {fmt(total)} 条</span></div>
        <div className="table-wrap"><table className="t">
          <thead><tr><th>内容</th><th>类型</th><th>名称</th><th>授权说明</th><th>添加时间（UTC）</th><th>状态</th><th></th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={7} className="muted">还没有片源。没有片源的播放页会显示“暂不可播放”并列出正版平台。</td></tr>}
            {rows.map((r) => {
              const [name, href] = label(r);
              return (
                <tr key={r.id}>
                  <td>{href ? <a href={href} target="_blank" rel="noopener">{name}</a> : name}</td>
                  <td>{KIND[r.kind] ?? r.kind}</td><td>{r.label}</td><td className="muted">{r.rightsNote}</td><td className="code">{when(r.createdAt)}</td>
                  <td><form action={toggleSource}><input type="hidden" name="id" value={r.id} /><button className="btn btn-sm" type="submit">{r.enabled ? "启用中 · 停用" : "已停用 · 启用"}</button></form></td>
                  <td><form action={deleteSource}><input type="hidden" name="id" value={r.id} /><button className="btn btn-sm" type="submit">删除</button></form></td>
                </tr>
              );
            })}
          </tbody>
        </table></div>
      </section>
      {total > 50 && <p className="muted">第 {page} 页{page > 1 && <> · <a href={`?page=${page - 1}`}>上一页</a></>}{page * 50 < total && <> · <a href={`?page=${page + 1}`}>下一页</a></>}</p>}
      <p className="muted"><St kind="">提示</St> 播放页地址：电影 /movie/…/watch，剧集 /tv/…/season-N/episode-M/watch。</p>
    </>
  );
}
