import { redis } from "@/lib/redis";
import { secrets } from "@/lib/settings";
import { TTL } from "@/lib/site";
import { purgeAll, purgeUrls } from "../../actions";
import { Notice, St, Top, type SP } from "../../ui";

const days = (s: number) => (s >= 86400 ? `${s / 86400} 天` : `${s / 3600} 小时`);

export default async function CachePage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { cloudflareToken, cloudflareZone } = await secrets();
  const mem = await redis().info("memory").catch(() => "");
  const used = /used_memory_human:(\S+)/.exec(mem)?.[1];
  const max = /maxmemory_human:(\S+)/.exec(mem)?.[1];
  const policy = /maxmemory_policy:(\S+)/.exec(mem)?.[1];
  const confirm = sp.confirm === "1";
  return (
    <>
      <Top eyebrow="缓存管理" title="缓存管理" sub="Cloudflare 边缘缓存 + Next.js 页面缓存" />
      <Notice sp={searchParams} />
      <div className="tiles">
        <div className="tile"><span className="k">Cloudflare</span><span className="v">{cloudflareToken && cloudflareZone ? "已连接" : "未配置"}</span><span className="d">在站点设置里填写 API Token 和 Zone ID</span></div>
        <div className="tile"><span className="k">Redis 内存</span><span className="v">{used ?? "—"}{max && max !== "0B" ? ` / ${max}` : ""}</span><span className="d">淘汰策略 {policy ?? "—"}</span></div>
        <div className="tile"><span className="k">详情页缓存</span><span className="v">{days(TTL.day)}</span><span className="d">数据变化时由同步任务立即刷新</span></div>
        <div className="tile"><span className="k">列表页缓存</span><span className="v">{days(TTL.list)}</span><span className="d">首页、列表、聚合页</span></div>
      </div>
      <div className="cols">
        <form className="panel" action={purgeUrls}>
          <div className="panel-head"><div><h2>按网址清除</h2><p>同时清除站内缓存和 Cloudflare 缓存</p></div></div>
          <div className="panel-body form-grid">
            <div className="f full"><label htmlFor="pu">网址（每行一个，可带域名）</label><textarea className="field" id="pu" name="urls" rows={5} placeholder="/tv/1402-the-walking-dead" required /></div>
            <div className="f full"><label style={{ display: "flex", alignItems: "center", gap: 8 }}><input type="checkbox" name="children" defaultChecked /> 剧集网址同时清除它的季页、集页</label></div>
          </div>
          <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">清除</button></div>
        </form>
        <section className="panel">
          <div className="panel-head"><div><h2>清除全部缓存</h2><p>所有页面会在下次访问时重新生成，短时间内源站压力会上升</p></div></div>
          <div className="panel-body">
            {!confirm ? <a className="btn btn-danger" href="?confirm=1">清除全部缓存</a> : (
              <div className="confirm-box">
                <span>确定清除全部站内缓存和 Cloudflare 缓存吗？</span>
                <form action={purgeAll}><button className="btn btn-sm btn-danger" type="submit">确认清除</button></form>
                <a className="btn btn-sm" href="?">取消</a>
              </div>
            )}
            <p className="hint muted" style={{ marginTop: 14 }}><St kind="">说明</St> 缓存时长写在代码里（详情页 1 天、列表页 1 小时），数据有变化时同步任务会主动刷新对应页面，一般不需要手动清除。</p>
          </div>
        </section>
      </div>
    </>
  );
}
