import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { queue } from "@/sync/queue";
import { dismissFailure, refreshItem, retryAllFailures, retryFailure, runDailyNow, runRotationNow, saveSchedule } from "../../actions";
import { Notice, St, Top, fmt, when, type SP } from "../../ui";

const KIND: Record<string, string> = { daily: "每日增量", rotation: "6 个月轮换", preload: "预导入", manual: "手动" };
const STATUS: Record<string, [string, "ok" | "warn" | "bad" | "run"]> = { ok: ["成功", "ok"], partial: ["部分失败", "warn"], failed: ["失败", "bad"], running: ["运行中", "run"] };

export default async function SyncPage({ searchParams }: { searchParams: SP }) {
  const s = await getSettings(0);
  const [runs, failures, counts] = await Promise.all([
    prisma.syncRun.findMany({ orderBy: { startedAt: "desc" }, take: 30 }),
    prisma.syncFailure.findMany({ orderBy: { updatedAt: "desc" }, take: 100 }),
    queue().getJobCounts("waiting", "active", "delayed", "prioritized", "failed").catch(() => null),
  ]);
  const [mm, hh] = s.syncCron.split(" ");
  const time = `${hh.padStart(2, "0")}:${mm.padStart(2, "0")}`;
  const pending = counts ? (counts.waiting ?? 0) + (counts.prioritized ?? 0) + (counts.delayed ?? 0) : null;
  return (
    <>
      <Top eyebrow="同步管理" title="同步管理" sub="TMDB 数据同步、重试与计划"
        actions={counts ? <St kind={counts.active ? "run" : "ok"}>{counts.active ? `运行中 ${counts.active} · 排队 ${fmt(pending ?? 0)}` : pending ? `排队 ${fmt(pending)}` : "队列空闲"}</St> : <St kind="bad">无法连接 Redis</St>} />
      <Notice sp={searchParams} />
      <div className="cols">
        <section className="panel">
          <div className="panel-head"><div><h2>手动同步</h2><p>平时无需操作，每日任务会自动完成；需要 worker 在运行</p></div></div>
          <div className="panel-body" style={{ display: "grid", gap: 18 }}>
            <div className="inline-form">
              <form action={runDailyNow}><button className="btn btn-primary" type="submit">立即运行增量同步</button></form>
              <form action={runRotationNow}><button className="btn" type="submit">立即运行轮换刷新</button></form>
            </div>
            <form className="inline-form" action={refreshItem}>
              <input type="hidden" name="from" value="/sync" />
              <div className="f" style={{ flex: "0 0 120px" }}><label htmlFor="t-type">类型</label>
                <select className="field" id="t-type" name="type" defaultValue="tv"><option value="movie">电影</option><option value="tv">剧集</option><option value="person">演员</option><option value="collection">合集</option></select></div>
              <div className="f" style={{ flex: "1 1 200px" }}><label htmlFor="t-id">TMDB ID</label><input className="field" id="t-id" name="id" inputMode="numeric" placeholder="例如 1402" required /></div>
              <button className="btn" type="submit">添加或刷新</button>
            </form>
            <p className="hint muted" style={{ margin: 0 }}>剧集刷新时会比对季数和每季集数，自动补全新季、新集。库里没有的 ID 会先在 TMDB 确认存在再添加。</p>
          </div>
        </section>
        <section className="panel">
          <div className="panel-head"><div><h2>计划设置</h2><p>保存后立即更新定时任务；速率在 worker 重启后生效</p></div></div>
          <form className="panel-body form-grid" action={saveSchedule}>
            <div className="f"><label htmlFor="s-time">每日同步时间（UTC）</label><input className="field" id="s-time" name="time" type="time" defaultValue={time} /><span className="hint">建议选在流量低谷</span></div>
            <div className="f"><label htmlFor="s-rate">请求速率上限（次/秒）</label><input className="field" id="s-rate" name="rate" type="number" min={1} max={40} defaultValue={s.tmdbRatePerSecond} /><span className="hint">TMDB 软上限约 40，留出余量</span></div>
            <div className="f"><label htmlFor="s-div">每日轮换比例 1/N</label><input className="field" id="s-div" name="divisor" type="number" min={10} defaultValue={s.rotationDivisor} /><span className="hint">150 ≈ 5 个月轮换全库，满足 6 个月缓存期限</span></div>
            <div className="f"><label htmlFor="s-pre">预先导入范围</label>
              <select className="field" id="s-pre" name="preload" defaultValue={s.preloadScope}><option value="US_2010">美国出品 · 2010 年以后电影</option><option value="ALL">全部电影</option><option value="NONE">仅按需导入</option></select></div>
            <div className="f full"><span className="lbl">停止追踪的剧集状态</span>
              <div className="checks">
                <label><input type="checkbox" name="stopEnded" defaultChecked={s.stopTrackingStatuses.includes("Ended")} /> Ended（已完结）</label>
                <label><input type="checkbox" name="stopCanceled" defaultChecked={s.stopTrackingStatuses.includes("Canceled")} /> Canceled（已取消）</label>
              </div></div>
            <div className="f full" style={{ justifyItems: "start" }}><button className="btn btn-primary" type="submit">保存</button></div>
          </form>
        </section>
      </div>

      <section className="panel">
        <div className="panel-head"><div><h2>失败重试队列</h2><p>自动重试 5 次仍失败的条目</p></div>
          {failures.length > 0 && <form action={retryAllFailures}><button className="btn btn-sm" type="submit">全部重试</button></form>}</div>
        <div className="table-wrap"><table className="t">
          <thead><tr><th>类型</th><th>TMDB ID</th><th>原因</th><th>时间（UTC）</th><th>操作</th></tr></thead>
          <tbody>
            {failures.length === 0 && <tr><td colSpan={5} className="muted">没有失败条目。</td></tr>}
            {failures.map((f) => (
              <tr key={f.id}><td>{f.type}</td><td className="code">{f.tmdbId}</td><td>{f.reason}</td><td className="code">{when(f.updatedAt)}</td>
                <td style={{ display: "flex", gap: 6 }}>
                  <form action={retryFailure}><input type="hidden" name="id" value={f.id} /><button className="btn btn-sm" type="submit">重试</button></form>
                  <form action={dismissFailure}><input type="hidden" name="id" value={f.id} /><button className="btn btn-sm" type="submit">忽略</button></form>
                </td></tr>
            ))}
          </tbody>
        </table></div>
      </section>

      <section className="panel">
        <div className="panel-head"><div><h2>同步日志</h2><p>最近 30 次运行；新增依次为电影 / 剧集 / 新季 / 新集</p></div></div>
        <div className="table-wrap"><table className="t">
          <thead><tr><th>编号</th><th>类型</th><th>开始（UTC）</th><th className="n">耗时</th><th className="n">新增</th><th className="n">更新</th><th className="n">失败</th><th className="n">API</th><th>状态</th><th>备注</th></tr></thead>
          <tbody>
            {runs.length === 0 && <tr><td colSpan={10} className="muted">还没有运行记录。</td></tr>}
            {runs.map((r) => {
              const [label, kind] = STATUS[r.status] ?? [r.status, "warn"];
              return (
                <tr key={r.id}><td className="code">#{r.id}</td><td>{KIND[r.kind] ?? r.kind}</td><td className="code">{when(r.startedAt)}</td>
                  <td className="n">{r.finishedAt ? `${Math.round((r.finishedAt.getTime() - r.startedAt.getTime()) / 60000)}m` : "—"}</td>
                  <td className="n">{fmt(r.newMovies)} / {fmt(r.newShows)} / {fmt(r.newSeasons)} / {fmt(r.newEpisodes)}</td>
                  <td className="n">{fmt(r.updated)}</td><td className="n">{fmt(r.failed)}</td><td className="n">{fmt(r.apiCalls)}</td>
                  <td><St kind={kind}>{label}</St></td><td className="muted" style={{ maxWidth: 360 }}>{r.error ?? r.note ?? ""}</td></tr>
              );
            })}
          </tbody>
        </table></div>
      </section>
    </>
  );
}
