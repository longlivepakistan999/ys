import Link from "next/link";
import { prisma } from "@/lib/db";
import { redis } from "@/lib/redis";
import { getSettings } from "@/lib/settings";
import { adminBase } from "@/lib/admin/session";
import { crawlerStats } from "@/lib/admin/crawlers";
import { runDailyNow } from "../actions";
import { Notice, St, Top, ago, fmt, when, type SP } from "../ui";

/** 14-day TMDB API calls, drawn to one scale. */
function Bars({ days }: { days: { label: string; n: number }[] }) {
  const W = 640, H = 180, L = 44, B = 22, T = 10;
  const max = Math.max(1000, ...days.map((d) => d.n));
  const step = Math.pow(10, Math.floor(Math.log10(max)));
  const top = Math.ceil(max / step) * step;
  const ticks = [0, top / 2, top];
  const bw = (W - L - 8) / days.length;
  const y = (v: number) => H - B - ((H - B - T) * v) / top;
  return (
    <svg className="bars" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="近 14 天 TMDB API 调用量">
      {ticks.map((v) => <g key={v}><line className="grid-line" x1={L} x2={W - 4} y1={y(v)} y2={y(v)} /><text x={L - 6} y={y(v) + 3} textAnchor="end">{v >= 1000 ? `${v / 1000}k` : v}</text></g>)}
      {days.map((d, i) => {
        const x = L + i * bw + 3;
        return (
          <g key={d.label}>
            <rect className={`bar${i === days.length - 1 ? " today" : ""}`} x={x} y={y(d.n)} width={bw - 6} height={Math.max(0, H - B - y(d.n))} rx={2}><title>{`${d.label}: ${fmt(d.n)}`}</title></rect>
            {(i % 2 === 1 || i === days.length - 1) && <text x={x + (bw - 6) / 2} y={H - 6} textAnchor="middle">{d.label}</text>}
          </g>
        );
      })}
    </svg>
  );
}

export default async function Dashboard({ searchParams }: { searchParams: SP }) {
  const s = await getSettings();
  const base = adminBase();
  const dayKeys = Array.from({ length: 14 }, (_, i) => new Date(Date.now() - (13 - i) * 86_400_000).toISOString().slice(0, 10));
  const since = new Date(Date.now() - 86_400_000);
  const [movies, shows, seasons, episodes, people, idxM, idxT, idxS, idxE, idxP, newM, newT, lastRun, oldest, alerts, calls, limited, crawlers] = await Promise.all([
    prisma.movie.count({ where: { removedAt: null } }), prisma.tvShow.count({ where: { removedAt: null } }),
    prisma.season.count(), prisma.episode.count(), prisma.person.count({ where: { removedAt: null } }),
    prisma.movie.count({ where: { isIndexable: true } }), prisma.tvShow.count({ where: { isIndexable: true } }),
    prisma.season.count({ where: { isIndexable: true } }), prisma.episode.count({ where: { isIndexable: true } }), prisma.person.count({ where: { isIndexable: true } }),
    prisma.movie.count({ where: { createdAt: { gte: since } } }), prisma.tvShow.count({ where: { createdAt: { gte: since } } }),
    prisma.syncRun.findFirst({ where: { kind: "daily" }, orderBy: { startedAt: "desc" } }),
    prisma.movie.findFirst({ where: { detailSyncedAt: { not: null }, removedAt: null }, orderBy: { detailSyncedAt: "asc" }, select: { detailSyncedAt: true } }),
    prisma.alertLog.findMany({ orderBy: { createdAt: "desc" }, take: 8 }),
    redis().mget(...dayKeys.map((d) => `tmdb:calls:${d}`)),
    redis().get(`tmdb:429:${dayKeys[13]}`),
    crawlerStats(s.nginxLogPath),
  ]);
  const indexable = idxM + idxT + idxS + idxE + idxP;
  const staleDays = oldest?.detailSyncedAt ? Math.floor((Date.now() - oldest.detailSyncedAt.getTime()) / 86_400_000) : 0;
  const days = dayKeys.map((d, i) => ({ label: `${Number(d.slice(5, 7))}/${Number(d.slice(8))}`, n: Number(calls[i] || 0) }));
  const runKind = (st?: string) => (st === "ok" ? "ok" : st === "running" ? "run" : st === "partial" ? "warn" : "bad") as "ok";
  const runLabel: Record<string, string> = { ok: "成功", running: "运行中", partial: "部分失败", failed: "失败" };

  return (
    <>
      <Top eyebrow="仪表盘" title="仪表盘" sub={new Date().toISOString().slice(0, 10)} actions={<a className="btn btn-sm" href="/" target="_blank" rel="noopener">查看网站</a>} />
      <Notice sp={searchParams} />
      <div className="tiles">
        <div className="tile"><span className="k">电影</span><span className="v">{fmt(movies)}</span><span className="d"><span className="up">+{fmt(newM)}</span> 近 24 小时</span></div>
        <div className="tile"><span className="k">剧集</span><span className="v">{fmt(shows)}</span><span className="d"><span className="up">+{fmt(newT)}</span> 近 24 小时</span></div>
        <div className="tile"><span className="k">季 / 集</span><span className="v">{fmt(episodes)}</span><span className="d">集 · 季 {fmt(seasons)}</span></div>
        <div className="tile"><span className="k">演员</span><span className="v">{fmt(people)}</span><span className="d">可索引 {fmt(idxP)}</span></div>
        <div className="tile"><span className="k">可索引页面</span><span className="v">{fmt(indexable)}</span><span className="d">进入 sitemap 的页面</span></div>
        <div className={`tile${staleDays > s.staleAlertDays ? " warn" : ""}`}><span className="k">最久未刷新</span><span className="v">{staleDays} 天</span><span className="d">超过 {s.staleAlertDays} 天告警</span></div>
      </div>

      <div className="cols">
        <section className="panel">
          <div className="panel-head"><div><h2>最近一次每日同步</h2><p>计划：{s.syncCron} UTC</p></div>{lastRun && <St kind={runKind(lastRun.status)}>{runLabel[lastRun.status] ?? lastRun.status}</St>}</div>
          <div className="panel-body">
            {lastRun ? (
              <dl className="kv">
                <dt>开始</dt><dd>{when(lastRun.startedAt)} UTC（{ago(lastRun.startedAt)}）</dd>
                <dt>耗时</dt><dd>{lastRun.finishedAt ? `${Math.round((lastRun.finishedAt.getTime() - lastRun.startedAt.getTime()) / 60000)} 分钟` : "进行中"}</dd>
                <dt>新增</dt><dd>电影 {fmt(lastRun.newMovies)} · 剧集 {fmt(lastRun.newShows)} · 新季 {fmt(lastRun.newSeasons)} · 新集 {fmt(lastRun.newEpisodes)}</dd>
                <dt>更新</dt><dd>{fmt(lastRun.updated)} 条</dd>
                <dt>失败</dt><dd>{fmt(lastRun.failed)} 条{lastRun.failed ? <> · <Link className="section-link" href={`${base}/sync`}>查看重试队列</Link></> : null}</dd>
                <dt>IndexNow</dt><dd>推送 {fmt(lastRun.urlsPushed)} 个网址</dd>
                {lastRun.note && <><dt>备注</dt><dd>{lastRun.note}</dd></>}
                {lastRun.error && <><dt>错误</dt><dd style={{ color: "var(--bad)" }}>{lastRun.error}</dd></>}
              </dl>
            ) : <p className="muted" style={{ margin: 0 }}>还没有运行过。启动 worker 后点“立即同步”。</p>}
          </div>
          <div className="panel-foot"><Link className="btn btn-sm" href={`${base}/sync`}>查看日志</Link><form action={runDailyNow}><button className="btn btn-sm btn-primary" type="submit">立即同步</button></form></div>
        </section>
        <section className="panel">
          <div className="panel-head"><div><h2>TMDB API 调用量</h2><p>近 14 天，所有进程合计</p></div><span className="mono muted">今日 {fmt(days[13].n)}</span></div>
          <div className="panel-body"><Bars days={days} />
            <dl className="kv" style={{ marginTop: 10 }}><dt>今日 429 次数</dt><dd>{fmt(Number(limited || 0))}</dd><dt>速率上限</dt><dd>{s.tmdbRatePerSecond} 次/秒</dd></dl>
          </div>
        </section>
      </div>

      <section className="panel">
        <div className="panel-head"><div><h2>爬虫访问源站（今日）</h2><p>来自 Nginx 日志；Cloudflare 缓存命中的请求不会到达源站，因此不在这里</p></div><Link className="btn btn-sm" href={`${base}/cache`}>缓存管理</Link></div>
        {crawlers.error ? <div className="panel-body muted">{crawlers.error}。在站点设置里修改日志路径。</div> : (
          <div className="table-wrap"><table className="t">
            <thead><tr><th>爬虫</th><th>处理方式</th><th className="n">请求数</th><th className="n">429 / 5xx</th></tr></thead>
            <tbody>
              {crawlers.rows.length === 0 && <tr><td colSpan={4} className="muted">今天还没有爬虫请求到达源站。</td></tr>}
              {crawlers.rows.map((r) => (
                <tr key={r.name}><td>{r.name}</td>
                  <td><St kind={r.policy === "allowed" ? "ok" : r.policy === "blocked" ? "bad" : "warn"}>{r.policy === "allowed" ? "放行" : r.policy === "blocked" ? "应拦截（检查 Cloudflare 规则）" : "未识别"}</St></td>
                  <td className="n">{fmt(r.requests)}</td><td className="n">{fmt(r.errors)}</td></tr>
              ))}
            </tbody>
          </table></div>
        )}
      </section>

      <section className="panel">
        <div className="panel-head"><h2>最近告警</h2><Link className="btn btn-sm" href={`${base}/settings#telegram`}>告警设置</Link></div>
        <div className="table-wrap"><table className="t">
          <thead><tr><th>时间（UTC）</th><th>级别</th><th>内容</th><th>Telegram</th></tr></thead>
          <tbody>
            {alerts.length === 0 && <tr><td colSpan={4} className="muted">暂无告警。</td></tr>}
            {alerts.map((a) => (
              <tr key={a.id}><td className="code">{when(a.createdAt)}</td>
                <td><St kind={a.level === "error" ? "bad" : a.level === "warn" ? "warn" : ""}>{a.level === "error" ? "错误" : a.level === "warn" ? "警告" : "信息"}</St></td>
                <td style={{ whiteSpace: "pre-line" }}>{a.text}</td><td>{a.sent ? <St kind="ok">已推送</St> : <St kind="">未推送</St>}</td></tr>
            ))}
          </tbody>
        </table></div>
      </section>
    </>
  );
}
