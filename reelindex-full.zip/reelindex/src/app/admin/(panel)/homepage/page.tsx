import { prisma } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { Poster } from "@/components/ui";
import { addPin, movePin, saveHome } from "../../actions";
import { Notice, Top, type SP } from "../../ui";

const RULES: [string, string][] = [["popular", "热度最高（全部）"], ["trending", "近 30 天上映 / 播出中热度最高"], ["recent_good", "近一年且评分 ≥ 7"]];

async function Pins({ block }: { block: "movies" | "tv" }) {
  const pins = await prisma.homepagePin.findMany({ where: { block }, orderBy: { position: "asc" } });
  const ids = pins.map((p) => p.tmdbId);
  const items = block === "movies"
    ? (await prisma.movie.findMany({ where: { id: { in: ids } }, select: { id: true, title: true, year: true, posterPath: true } })).map((m) => ({ id: m.id, title: m.title, year: m.year, poster: m.posterPath }))
    : (await prisma.tvShow.findMany({ where: { id: { in: ids } }, select: { id: true, name: true, firstAirYear: true, posterPath: true } })).map((t) => ({ id: t.id, title: t.name, year: t.firstAirYear, poster: t.posterPath }));
  const byId = new Map(items.map((i) => [i.id, i]));
  return (
    <>
      <ol className="sort-list">
        {pins.length === 0 && <li style={{ display: "block" }} className="muted">还没有置顶内容，全部按自动规则显示。</li>}
        {pins.map((p, i) => {
          const it = byId.get(p.tmdbId);
          return (
            <li key={p.id}>
              <span className="idx">{i + 1}</span><Poster title={it?.title ?? String(p.tmdbId)} path={it?.poster} size="w92" mini />
              <span>{it?.title ?? `#${p.tmdbId}（未入库）`} <span className="muted">· {it?.year ?? ""}</span></span>
              <span className="actions">
                {(["up", "down", "remove"] as const).map((dir) => (
                  <form key={dir} action={movePin}><input type="hidden" name="id" value={p.id} /><input type="hidden" name="dir" value={dir} />
                    <button className="icon-btn" type="submit" aria-label={{ up: "上移", down: "下移", remove: "移除" }[dir]}>{{ up: "↑", down: "↓", remove: "×" }[dir]}</button></form>
                ))}
              </span>
            </li>
          );
        })}
      </ol>
      <form className="inline-form" action={addPin} style={{ marginTop: 12 }}>
        <input type="hidden" name="block" value={block} />
        <input className="field" name="q" placeholder="输入片名或 TMDB ID 添加" aria-label="添加置顶" required />
        <button className="btn btn-sm" type="submit">添加</button>
      </form>
    </>
  );
}

export default async function HomepagePage({ searchParams }: { searchParams: SP }) {
  const s = await getSettings(0);
  return (
    <>
      <Top eyebrow="首页编排" title="首页编排" sub="首页只有搜索框、推荐电影、推荐剧集，不放广告" actions={<a className="btn btn-sm" href="/" target="_blank" rel="noopener">预览首页</a>} />
      <Notice sp={searchParams} />
      <div className="cols">
        <section className="panel"><div className="panel-head"><div><h2>推荐电影 · 置顶</h2><p>置顶内容排在前面，其余按自动规则补足</p></div></div><div className="panel-body"><Pins block="movies" /></div></section>
        <section className="panel"><div className="panel-head"><div><h2>推荐剧集 · 置顶</h2><p>置顶内容排在前面，其余按自动规则补足</p></div></div><div className="panel-body"><Pins block="tv" /></div></section>
      </div>
      <form className="panel" action={saveHome}>
        <div className="panel-head"><div><h2>自动规则与热门链接</h2><p>保存后首页缓存立即清除</p></div></div>
        <div className="panel-body form-grid">
          <div className="f"><label htmlFor="h-mr">推荐电影规则</label><select className="field" id="h-mr" name="moviesRule" defaultValue={s.homeMoviesRule}>{RULES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
          <div className="f"><label htmlFor="h-tr">推荐剧集规则</label><select className="field" id="h-tr" name="tvRule" defaultValue={s.homeTvRule}>{RULES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
          <div className="f"><label htmlFor="h-n">每块显示数量</label><input className="field" id="h-n" name="count" type="number" min={6} max={24} defaultValue={s.homeCount} /></div>
          <div className="f full"><label htmlFor="h-q">搜索框下方的热门链接</label>
            <textarea className="field" id="h-q" name="quickLinks" rows={5} defaultValue={s.homeQuickLinks} placeholder={"The Walking Dead | /tv/1402-the-walking-dead\nKorean dramas | /country/south-korea/tv"} />
            <span className="hint">每行一个：显示文字 | 站内路径</span></div>
        </div>
        <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存并发布</button></div>
      </form>
    </>
  );
}
