import Link from "next/link";
import { prisma } from "@/lib/db";
import { adminBase } from "@/lib/admin/session";
import { saveAdSlot, toggleAdSlot } from "../../actions";
import { Notice, St, Top, type SP } from "../../ui";

const PAGE_TYPES: [string, string][] = [["movie", "电影详情"], ["tv", "剧集详情"], ["season", "季页"], ["episode", "集页"], ["person", "演员页"], ["list", "列表 / 聚合页"], ["similar", "相似电影"], ["collection", "合集"], ["watch", "播放页"]];

export default async function AdsPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const slots = await prisma.adSlot.findMany({ orderBy: { key: "asc" } });
  const base = adminBase();
  const current = slots.find((s) => s.key === sp.slot) ?? slots[0];
  return (
    <>
      <Top eyebrow="广告管理" title="广告管理" sub="不绑定特定广告联盟；首页始终没有广告" />
      <Notice sp={searchParams} />
      <section className="panel">
        <div className="panel-head"><div><h2>广告位</h2><p>关闭或没填代码的广告位不会输出任何 HTML，页面上看不出来</p></div></div>
        <div className="table-wrap"><table className="t">
          <thead><tr><th>标识</th><th>名称</th><th>尺寸（桌面 / 移动）</th><th>页面类型</th><th>代码</th><th>状态</th><th></th></tr></thead>
          <tbody>
            {slots.length === 0 && <tr><td colSpan={7} className="muted">还没有广告位。在服务器上运行 <code>npm run sync -- seed</code> 创建默认广告位。</td></tr>}
            {slots.map((s) => (
              <tr key={s.key}>
                <td className="code">{s.key}</td><td>{s.label}</td><td>{s.desktopW}×{s.desktopH} / {s.mobileW}×{s.mobileH}</td>
                <td>{s.pageTypes.map((t) => PAGE_TYPES.find(([k]) => k === t)?.[1] ?? t).join("、") || "全部"}</td>
                <td>{s.code.trim() ? <St kind="ok">已填写</St> : <St kind="">未填写</St>}</td>
                <td><form action={toggleAdSlot}><input type="hidden" name="key" value={s.key} /><button className="btn btn-sm" type="submit">{s.enabled ? "已开启 · 点击关闭" : "已关闭 · 点击开启"}</button></form></td>
                <td><Link href={`${base}/ads?slot=${s.key}`}>编辑</Link></td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </section>
      {current && (
        <form className="panel" action={saveAdSlot} key={current.key}>
          <input type="hidden" name="key" value={current.key} />
          <div className="panel-head"><div><h2>编辑：{current.key} · {current.label}</h2><p>粘贴任意广告联盟提供的 HTML/JS 代码</p></div></div>
          <div className="panel-body form-grid">
            <div className="f full"><label style={{ display: "flex", alignItems: "center", gap: 10 }}><input className="switch" type="checkbox" name="enabled" defaultChecked={current.enabled} /> 启用此广告位</label></div>
            <div className="f full"><label htmlFor="ad-code">广告代码</label><textarea className="field" id="ad-code" name="code" rows={8} defaultValue={current.code} placeholder="<!-- 在此粘贴广告联盟的代码 -->" /></div>
            <div className="f"><label htmlFor="dw">桌面宽 × 高</label><div className="inline-form"><input className="field" id="dw" name="dw" type="number" defaultValue={current.desktopW} aria-label="桌面宽" /><input className="field" name="dh" type="number" defaultValue={current.desktopH} aria-label="桌面高" /></div></div>
            <div className="f"><label htmlFor="mw">移动端宽 × 高</label><div className="inline-form"><input className="field" id="mw" name="mw" type="number" defaultValue={current.mobileW} aria-label="移动端宽" /><input className="field" name="mh" type="number" defaultValue={current.mobileH} aria-label="移动端高" /></div></div>
            <div className="f full"><span className="lbl">显示在</span>
              <div className="checks" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(150px,1fr))" }}>
                {PAGE_TYPES.map(([k, l]) => <label key={k}><input type="checkbox" name={`pt_${k}`} defaultChecked={current.pageTypes.includes(k)} /> {l}</label>)}
              </div>
              <span className="hint">都不勾选 = 所有页面类型（首页除外）</span></div>
            <div className="f full"><label style={{ display: "flex", alignItems: "center", gap: 10 }}><input type="checkbox" name="collapse" defaultChecked={current.collapseWhenEmpty} /> 广告联盟未返回广告时自动折叠</label>
              <span className="hint">广告位固定高度并放在首屏以下，折叠不会造成首屏跳动</span></div>
          </div>
          <div className="panel-foot"><button className="btn btn-sm btn-primary" type="submit">保存</button></div>
        </form>
      )}
    </>
  );
}
