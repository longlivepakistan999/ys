import type { ReactNode } from "react";

export type SP = Promise<Record<string, string | string[] | undefined>>;

export function Top({ eyebrow, title, sub, actions }: { eyebrow: string; title: string; sub?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="admin-top">
      <div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{sub && <p>{sub}</p>}</div>
      {actions && <div className="actions">{actions}</div>}
    </div>
  );
}

/** Result message from the last action (?msg= / ?err=). */
export async function Notice({ sp }: { sp: SP }) {
  const p = await sp;
  const msg = typeof p.msg === "string" ? p.msg : null;
  const err = typeof p.err === "string" ? p.err : null;
  if (!msg && !err) return null;
  return (
    <div role="status" className="panel panel-body" style={{ borderColor: err ? "var(--bad)" : "var(--good)", color: err ? "var(--bad)" : "var(--good)", fontWeight: 600 }}>
      {err ?? msg}
    </div>
  );
}

export function St({ kind, children }: { kind: "ok" | "warn" | "bad" | "run" | ""; children: ReactNode }) {
  return <span className={`st ${kind}`}>{children}</span>;
}

export const fmt = (n: number | bigint) => Number(n).toLocaleString("en-US");
export const when = (d: Date | null | undefined) => (d ? d.toISOString().slice(0, 16).replace("T", " ") : "—");
export const ago = (d: Date | null | undefined) => {
  if (!d) return "—";
  const m = Math.round((Date.now() - d.getTime()) / 60000);
  return m < 60 ? `${m} 分钟前` : m < 1440 ? `${Math.round(m / 60)} 小时前` : `${Math.round(m / 1440)} 天前`;
};
