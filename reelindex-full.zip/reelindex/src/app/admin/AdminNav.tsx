"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const GROUPS: [string, [string, string][]][] = [
  ["概览", [["仪表盘", ""]]],
  ["数据", [["同步管理", "/sync"], ["内容管理", "/content"], ["播放片源", "/sources"]]],
  ["运营", [["首页编排", "/homepage"], ["SEO 管理", "/seo"], ["广告管理", "/ads"]]],
  ["系统", [["缓存管理", "/cache"], ["站点设置", "/settings"]]],
];

export function AdminNav({ base, failures }: { base: string; failures: number }) {
  const path = usePathname() ?? "";
  const rel = path.startsWith(base) ? path.slice(base.length) : path.replace(/^\/admin/, "");
  return (
    <nav className="side-nav" aria-label="后台导航">
      {GROUPS.map(([g, items]) => (
        <div key={g} style={{ display: "contents" }}>
          <span className="grp">{g}</span>
          {items.map(([name, href]) => {
            const active = href === "" ? rel === "" || rel === "/" : rel === href || rel.startsWith(href + "/");
            return (
              <Link key={href} href={`${base}${href}`} aria-current={active ? "page" : undefined}>
                <span>{name}</span>{href === "/sync" && failures > 0 && <span className="count">{failures}</span>}
              </Link>
            );
          })}
        </div>
      ))}
    </nav>
  );
}
