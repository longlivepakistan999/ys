import { getAccount } from "@/lib/admin/auth";
import { getSite } from "@/lib/site";
import { login } from "../actions";
import { Notice, type SP } from "../ui";

export default async function Login({ searchParams }: { searchParams: SP }) {
  const [site, acc] = await Promise.all([getSite(), getAccount()]);
  return (
    <div className="login-wrap">
      <form className="login" action={login}>
        <span className="logo">{site.name}</span>
        <p className="muted" style={{ margin: 0 }}>后台管理登录</p>
        <Notice sp={searchParams} />
        {!acc && <p className="hint" style={{ margin: 0 }}>还没有管理员账号。在服务器上运行 <code>npm run sync -- admin 用户名 密码</code> 创建。</p>}
        <div className="f"><label htmlFor="u">用户名</label><input className="field" id="u" name="username" autoComplete="username" required /></div>
        <div className="f"><label htmlFor="pw">密码</label><input className="field" id="pw" name="password" type="password" autoComplete="current-password" required /></div>
        {acc?.totpEnabled && (
          <div className="f"><label htmlFor="otp">两步验证码</label>
            <input className="field" id="otp" name="otp" inputMode="numeric" maxLength={6} placeholder="6 位数字" autoComplete="one-time-code" required />
            <span className="hint">打开身份验证器 App 查看。连续失败 5 次将锁定 15 分钟。</span></div>
        )}
        <button className="btn btn-primary" type="submit">登录</button>
      </form>
    </div>
  );
}
