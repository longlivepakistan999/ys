"use server";
/**
 * Every admin mutation. Each action re-checks the session, writes the admin
 * log, refreshes affected page caches and redirects back with a message.
 */
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { redis } from "@/lib/redis";
import { DEFAULT_SETTINGS, getSettings, saveSettings, type Settings } from "@/lib/settings";
import { purgeCloudflare, purgeCloudflareAll } from "@/lib/publish";
import { notify, send } from "@/lib/notify/telegram";
import { paths } from "@/lib/slug";
import { tmdb } from "@/lib/tmdb/client";
import { titleIndexable, personIndexable } from "@/lib/seo/indexable";
import { clientIp, getAccount, logAction, requireAdmin, saveAccount } from "@/lib/admin/auth";
import { hashPassword, newTotpSecret, verifyPassword, verifyTotp } from "@/lib/admin/crypto";
import { adminBase, COOKIE, SESSION_DAYS, signSession } from "@/lib/admin/session";
import { enqueueDetail, PRIORITY, queue, sealRun } from "@/sync/queue";
import { startRun } from "@/sync/run";
import { enqueueRotation } from "@/sync/jobs/rotation";

const str = (f: FormData, k: string) => String(f.get(k) ?? "").trim();
const num = (f: FormData, k: string, d = 0) => { const n = Number(str(f, k)); return Number.isFinite(n) ? n : d; };
const on = (f: FormData, k: string) => f.get(k) === "on" || f.get(k) === "1";

function back(path: string, msg: string, kind: "msg" | "err" = "msg"): never {
  redirect(`${adminBase()}${path}${path.includes("?") ? "&" : "?"}${kind}=${encodeURIComponent(msg)}`);
}

/** Refresh our page cache and Cloudflare's copy for these site paths. */
async function publish(list: string[]) {
  for (const p of list) revalidatePath(p);
  await purgeCloudflare(list);
}

// ------------------------------------------------------------------ Auth
export async function login(f: FormData) {
  const ip = await clientIp();
  const lockKey = `login:lock:${ip}`, failKey = `login:fail:${ip}`;
  if (await redis().get(lockKey)) back("/login", "Too many failed attempts. Try again in 15 minutes.", "err");
  const acc = await getAccount();
  const ok = !!acc && acc.username === str(f, "username") && (await verifyPassword(str(f, "password"), acc.passwordHash))
    && (!acc.totpEnabled || (!!acc.totpSecret && verifyTotp(acc.totpSecret, str(f, "otp"))));
  if (!ok || !acc) {
    const n = await redis().incr(failKey);
    await redis().expire(failKey, 900);
    if (n >= 5) {
      await redis().set(lockKey, "1", "EX", 900);
      await notify("loginLocked", `🔒 Admin login locked for 15 minutes after 5 failed attempts from ${ip}`);
    }
    await prisma.adminLog.create({ data: { action: "登录失败", ip } });
    back("/login", acc ? "用户名、密码或验证码错误" : "尚未创建管理员账号，请先运行 npm run sync -- admin <用户名> <密码>", "err");
  }
  await redis().del(failKey);
  (await cookies()).set(COOKIE, await signSession(acc.username, acc.sessionVersion), {
    httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: SESSION_DAYS * 86400,
  });
  await prisma.adminLog.create({ data: { action: `登录成功${acc.totpEnabled ? "（两步验证）" : ""}`, ip } });
  await notify("loginSuccess", `Admin login from ${ip}`);
  redirect(adminBase());
}

export async function logout() {
  (await cookies()).delete(COOKIE);
  redirect(`${adminBase()}/login`);
}

// ------------------------------------------------------------------ Sync
export async function runDailyNow() {
  await requireAdmin();
  await queue().add("daily", { type: "daily" }, { removeOnComplete: true });
  await logAction("手动运行每日同步");
  back("/sync", "已加入队列：每日同步将在 1 分钟内开始");
}

export async function runRotationNow() {
  await requireAdmin();
  const runId = await startRun("rotation", "manual");
  const r = await enqueueRotation(runId);
  await sealRun(runId);
  await logAction("手动运行轮换刷新");
  back("/sync", `已加入队列：轮换刷新 ${r.movies + r.shows + r.people + r.collections} 条`);
}

export async function refreshItem(f: FormData) {
  await requireAdmin();
  const type = str(f, "type") as "movie" | "tv" | "person" | "collection";
  const id = num(f, "id");
  if (!["movie", "tv", "person", "collection"].includes(type) || !id) back(str(f, "from") || "/sync", "请输入正确的类型和 TMDB ID", "err");
  // Make sure a row exists so a brand-new id can be added by hand
  const exists = type === "movie" ? await prisma.movie.findUnique({ where: { id } }) : type === "tv" ? await prisma.tvShow.findUnique({ where: { id } }) : null;
  if (!exists && (type === "movie" || type === "tv")) {
    const probe = await tmdb<{ id: number; title?: string; name?: string }>(`/${type}/${id}`);
    if (!probe) back(str(f, "from") || "/sync", `TMDB 上找不到 ${type} ${id}`, "err");
  }
  await queue().add(type, { type, id, force: true }, { jobId: `${type}-${id}-manual-${Date.now()}`, priority: PRIORITY.manual, attempts: 3, backoff: { type: "exponential", delay: 3000 }, removeOnComplete: true, removeOnFail: true });
  await logAction(`手动刷新 ${type} ${id}`);
  back(str(f, "from") || "/sync", `已加入队列：${type} ${id} 将在几秒内刷新`);
}

export async function retryFailure(f: FormData) {
  await requireAdmin();
  const id = num(f, "id");
  const row = await prisma.syncFailure.findUnique({ where: { id } });
  if (row) {
    await enqueueDetail(row.type as "movie", row.tmdbId, { priority: PRIORITY.manual });
    await prisma.syncFailure.delete({ where: { id } });
  }
  back("/sync", "已重新加入队列");
}

export async function retryAllFailures() {
  await requireAdmin();
  const rows = await prisma.syncFailure.findMany();
  for (const r of rows) await enqueueDetail(r.type as "movie", r.tmdbId, { priority: PRIORITY.manual });
  await prisma.syncFailure.deleteMany({ where: { id: { in: rows.map((r) => r.id) } } });
  await logAction(`重试全部失败条目（${rows.length}）`);
  back("/sync", `${rows.length} 条已重新加入队列`);
}

export async function dismissFailure(f: FormData) {
  await requireAdmin();
  await prisma.syncFailure.delete({ where: { id: num(f, "id") } }).catch(() => {});
  back("/sync", "已从失败队列移除");
}

export async function saveSchedule(f: FormData) {
  await requireAdmin();
  const time = str(f, "time");
  const m = /^(\d{1,2}):(\d{2})$/.exec(time);
  if (!m) back("/sync", "时间格式应为 HH:MM", "err");
  const cron = `${Number(m[2])} ${Number(m[1])} * * *`;
  const patch: Partial<Settings> = {
    syncCron: cron,
    tmdbRatePerSecond: Math.min(40, Math.max(1, num(f, "rate", 30))),
    rotationDivisor: Math.max(10, num(f, "divisor", 150)),
    preloadScope: (["US_2010", "ALL", "NONE"].includes(str(f, "preload")) ? str(f, "preload") : "US_2010") as Settings["preloadScope"],
    stopTrackingStatuses: [on(f, "stopEnded") && "Ended", on(f, "stopCanceled") && "Canceled"].filter(Boolean) as string[],
  };
  await saveSettings(patch);
  await queue().upsertJobScheduler("daily-sync", { pattern: cron, tz: "UTC" },
    { name: "daily", data: { type: "daily" }, opts: { removeOnComplete: true, removeOnFail: 20, attempts: 1 } });
  await logAction(`保存同步计划（${time} UTC）`);
  back("/sync", "计划已保存。速率和并发在 worker 重启后生效");
}

export async function runReindex() {
  await requireAdmin();
  await queue().add("reindex", { type: "reindex" }, { jobId: `reindex-${Date.now()}`, removeOnComplete: true });
  await logAction("重新计算索引");
  back("/seo", "已开始重新计算全部页面的索引状态，完成后 Telegram 通知");
}

// ------------------------------------------------------------------ Content
async function entityPaths(type: string, id: number): Promise<string[]> {
  if (type === "movie") { const m = await prisma.movie.findUnique({ where: { id } }); return m ? [paths.movie(m.id, m.slug, m.year), `${paths.movie(m.id, m.slug, m.year)}/similar`] : []; }
  if (type === "tv") {
    const t = await prisma.tvShow.findUnique({ where: { id }, include: { seasons: { select: { seasonNumber: true } } } });
    if (!t) return [];
    const eps = await prisma.episode.findMany({ where: { showId: id, hasPage: true }, select: { seasonNumber: true, episodeNumber: true } });
    return [paths.tv(t.id, t.slug), ...t.seasons.map((s) => paths.season(t.id, t.slug, s.seasonNumber)), ...eps.map((e) => paths.episode(t.id, t.slug, e.seasonNumber, e.episodeNumber))];
  }
  if (type === "person") { const p = await prisma.person.findUnique({ where: { id } }); return p ? [paths.person(p.id, p.slug), `${paths.person(p.id, p.slug)}/movies`] : []; }
  if (type === "collection") { const c = await prisma.collection.findUnique({ where: { id } }); return c ? [paths.collection(c.id, c.slug)] : []; }
  return [];
}

export async function saveContent(f: FormData) {
  await requireAdmin();
  const type = str(f, "type"), id = num(f, "id");
  const back_ = `/content/${type}/${id}`;
  const s = await getSettings(0);
  const override = (["AUTO", "FORCE_INDEX", "FORCE_NOINDEX"].includes(str(f, "indexOverride")) ? str(f, "indexOverride") : "AUTO") as "AUTO";
  const hidden = on(f, "hidden");
  const text = (k: string) => str(f, k) || null;
  if (type === "movie") {
    const m = await prisma.movie.findUniqueOrThrow({ where: { id } });
    const isIndexable = titleIndexable({ ...m, hidden, indexOverride: override }, s);
    await prisma.movie.update({ where: { id }, data: { titleOverride: text("titleOverride"), seoTitleOverride: text("seoTitleOverride"), overviewOverride: text("overviewOverride"), indexOverride: override, hidden, isIndexable } });
  } else if (type === "tv") {
    const t = await prisma.tvShow.findUniqueOrThrow({ where: { id } });
    const isIndexable = titleIndexable({ ...t, hidden, indexOverride: override }, s);
    await prisma.tvShow.update({ where: { id }, data: { titleOverride: text("titleOverride"), seoTitleOverride: text("seoTitleOverride"), overviewOverride: text("overviewOverride"), indexOverride: override, hidden, isIndexable } });
    // Seasons and episodes follow the show
    if (!isIndexable) { await prisma.season.updateMany({ where: { showId: id }, data: { isIndexable: false } }); await prisma.episode.updateMany({ where: { showId: id }, data: { isIndexable: false } }); }
    else await queue().add("reindex", { type: "reindex" }, { jobId: `reindex-${Date.now()}`, removeOnComplete: true });
  } else if (type === "person") {
    const p = await prisma.person.findUniqueOrThrow({ where: { id } });
    await prisma.person.update({ where: { id }, data: { indexOverride: override, hidden, isIndexable: personIndexable({ ...p, hidden, indexOverride: override }, s) } });
  } else if (type === "collection") {
    await prisma.collection.update({ where: { id }, data: { hidden, isIndexable: !hidden } });
  }
  await publish(await entityPaths(type, id));
  await logAction(`${hidden ? "下架/" : ""}编辑 ${type} ${id}`);
  back(back_, "已保存，相关页面缓存已清除");
}

export async function purgeContent(f: FormData) {
  await requireAdmin();
  const type = str(f, "type"), id = num(f, "id");
  const list = await entityPaths(type, id);
  await publish(list);
  back(`/content/${type}/${id}`, `已清除 ${list.length} 个页面的缓存`);
}

// ------------------------------------------------------------------ Homepage
export async function saveHome(f: FormData) {
  await requireAdmin();
  const rule = (k: string) => (["popular", "recent_good", "trending"].includes(str(f, k)) ? str(f, k) : "popular") as Settings["homeMoviesRule"];
  await saveSettings({ homeMoviesRule: rule("moviesRule"), homeTvRule: rule("tvRule"), homeCount: Math.min(24, Math.max(6, num(f, "count", 12))), homeQuickLinks: str(f, "quickLinks") });
  await publish(["/"]);
  await logAction("保存首页编排");
  back("/homepage", "已发布，首页缓存已清除");
}

export async function addPin(f: FormData) {
  await requireAdmin();
  const block = str(f, "block") === "tv" ? "tv" : "movies";
  const q = str(f, "q");
  let id = /^\d+$/.test(q) ? Number(q) : 0;
  if (!id && q) {
    const hit = block === "movies"
      ? await prisma.movie.findFirst({ where: { title: { contains: q, mode: "insensitive" }, removedAt: null }, orderBy: { popularity: "desc" }, select: { id: true } })
      : await prisma.tvShow.findFirst({ where: { name: { contains: q, mode: "insensitive" }, removedAt: null }, orderBy: { popularity: "desc" }, select: { id: true } });
    id = hit?.id ?? 0;
  }
  if (!id) back("/homepage", `没有找到“${q}”`, "err");
  const last = await prisma.homepagePin.findFirst({ where: { block }, orderBy: { position: "desc" } });
  await prisma.homepagePin.upsert({ where: { block_tmdbId: { block, tmdbId: id } }, create: { block, tmdbId: id, position: (last?.position ?? 0) + 1 }, update: {} });
  await publish(["/"]);
  back("/homepage", "已添加到置顶");
}

export async function movePin(f: FormData) {
  await requireAdmin();
  const id = num(f, "id"), dir = str(f, "dir");
  const pin = await prisma.homepagePin.findUnique({ where: { id } });
  if (pin) {
    if (dir === "remove") await prisma.homepagePin.delete({ where: { id } });
    else {
      const other = await prisma.homepagePin.findFirst({
        where: { block: pin.block, position: dir === "up" ? { lt: pin.position } : { gt: pin.position } },
        orderBy: { position: dir === "up" ? "desc" : "asc" },
      });
      if (other) await prisma.$transaction([
        prisma.homepagePin.update({ where: { id: pin.id }, data: { position: other.position } }),
        prisma.homepagePin.update({ where: { id: other.id }, data: { position: pin.position } }),
      ]);
    }
  }
  await publish(["/"]);
  back("/homepage", "已更新");
}

// ------------------------------------------------------------------ SEO
export async function saveTemplates(f: FormData) {
  await requireAdmin();
  const t = { ...DEFAULT_SETTINGS.seoTemplates };
  for (const k of Object.keys(t) as (keyof typeof t)[]) t[k] = str(f, k) || DEFAULT_SETTINGS.seoTemplates[k];
  await saveSettings({ seoTemplates: t });
  await logAction("保存 SEO 标题模板");
  back("/seo", "模板已保存。页面在各自缓存到期或下次同步后更新");
}

export async function saveThresholds(f: FormData) {
  await requireAdmin();
  await saveSettings({
    minVotesWithoutFullData: num(f, "minVotes", 50), minShowPopularityForThinEpisodes: num(f, "minShowPop", 20),
    minPersonCredits: num(f, "minCredits", 3), minListSize: num(f, "minList", 12),
    topRatedMinVotesMovie: num(f, "topMovie", 500), topRatedMinVotesTv: num(f, "topTv", 200),
    maxListPages: Math.max(1, num(f, "maxPages", 100)), perPage: Math.min(60, Math.max(12, num(f, "perPage", 36))),
  });
  await logAction("保存索引门槛");
  back("/seo", "已保存。点“重新计算索引”让已有页面套用新门槛");
}

export async function saveRobots(f: FormData) {
  await requireAdmin();
  await saveSettings({ robotsTxt: str(f, "robots") });
  await purgeCloudflare(["/robots.txt"]);
  await logAction("保存 robots.txt");
  back("/seo", "robots.txt 已保存");
}

export async function addRedirect(f: FormData) {
  await requireAdmin();
  const from = str(f, "from"), to = str(f, "to");
  if (!from.startsWith("/") || !to.startsWith("/") || from === to) back("/seo", "旧网址和新网址都要以 / 开头，且不能相同", "err");
  await prisma.redirect.upsert({ where: { oldPath: from }, create: { oldPath: from, newPath: to, source: "manual" }, update: { newPath: to } });
  await logAction(`添加重定向 ${from} → ${to}`);
  back("/seo", "重定向已添加");
}

export async function deleteRedirect(f: FormData) {
  await requireAdmin();
  await prisma.redirect.delete({ where: { oldPath: str(f, "from") } }).catch(() => {});
  back("/seo", "已删除");
}

// ------------------------------------------------------------------ Ads
export async function saveAdSlot(f: FormData) {
  await requireAdmin();
  const key = str(f, "key");
  const types = ["movie", "tv", "season", "episode", "person", "list", "similar", "collection", "watch"].filter((t) => on(f, `pt_${t}`));
  await prisma.adSlot.update({
    where: { key },
    data: {
      enabled: on(f, "enabled"), code: String(f.get("code") ?? ""), desktopW: num(f, "dw", 728), desktopH: num(f, "dh", 90),
      mobileW: num(f, "mw", 320), mobileH: num(f, "mh", 100), pageTypes: types, collapseWhenEmpty: on(f, "collapse"),
    },
  });
  await logAction(`修改广告位 ${key}`);
  revalidatePath("/", "layout");
  back(`/ads?slot=${key}`, "广告位已保存。页面缓存到期后生效，或在缓存管理里清除全部");
}

export async function toggleAdSlot(f: FormData) {
  await requireAdmin();
  const key = str(f, "key");
  const s = await prisma.adSlot.findUnique({ where: { key } });
  if (s) await prisma.adSlot.update({ where: { key }, data: { enabled: !s.enabled } });
  await logAction(`${s?.enabled ? "关闭" : "开启"}广告位 ${key}`);
  revalidatePath("/", "layout");
  back("/ads", s?.enabled ? "已关闭" : "已开启");
}

// ------------------------------------------------------------------ Cache
export async function purgeUrls(f: FormData) {
  await requireAdmin();
  const list = str(f, "urls").split(/\s+/).map((u) => u.replace(/^https?:\/\/[^/]+/, "")).filter((u) => u.startsWith("/"));
  const extra: string[] = [];
  if (on(f, "children")) {
    for (const u of list) {
      const m = /^\/tv\/(\d+)/.exec(u);
      if (m) extra.push(...(await entityPaths("tv", Number(m[1]))));
    }
  }
  const all = [...new Set([...list, ...extra])];
  await publish(all);
  await logAction(`清除缓存 ${all.length} 个网址`);
  back("/cache", `已清除 ${all.length} 个网址的缓存`);
}

export async function purgeAll() {
  await requireAdmin();
  revalidatePath("/", "layout");
  const cf = await purgeCloudflareAll();
  await logAction("清除全部缓存");
  back("/cache", cf ? "已清除全部站内缓存和 Cloudflare 缓存" : "已清除站内缓存（Cloudflare 未配置或调用失败）");
}

// ------------------------------------------------------------------ Settings
export async function saveSite(f: FormData) {
  await requireAdmin();
  const url = str(f, "siteUrl").replace(/\/$/, "");
  if (url && !/^https:\/\/[^/]+$/.test(url)) back("/settings", "域名格式应为 https://www.example.com", "err");
  await saveSettings({ siteName: str(f, "siteName") || DEFAULT_SETTINGS.siteName, siteUrl: url, footerText: str(f, "footerText") || DEFAULT_SETTINGS.footerText, nginxLogPath: str(f, "nginxLogPath") || DEFAULT_SETTINGS.nginxLogPath });
  revalidatePath("/", "layout");
  await logAction("保存站点信息");
  back("/settings", "站点信息已保存");
}

export async function saveKeys(f: FormData) {
  await requireAdmin();
  // Empty field = keep the current secret
  const patch: Partial<Settings> = {};
  for (const k of ["tmdbToken", "cloudflareToken", "cloudflareZone", "indexNowKey"] as const) if (str(f, k)) patch[k] = str(f, k);
  await saveSettings(patch);
  let msg = "密钥已保存";
  if (patch.tmdbToken) msg += (await tmdb("/configuration").then(() => true).catch(() => false)) ? "，TMDB 验证通过" : "，但 TMDB 验证失败，请检查 Token";
  await logAction("修改接口密钥");
  back("/settings#api", msg);
}

export async function saveTelegram(f: FormData) {
  await requireAdmin();
  const ev = { ...DEFAULT_SETTINGS.telegramEvents };
  for (const k of Object.keys(ev) as (keyof typeof ev)[]) ev[k] = on(f, `ev_${k}`);
  const patch: Partial<Settings> = { telegramEvents: ev, telegramChatId: str(f, "chatId") };
  if (str(f, "botToken")) patch.telegramBotToken = str(f, "botToken");
  await saveSettings(patch);
  await logAction("保存 Telegram 设置");
  back("/settings#telegram", "Telegram 设置已保存");
}

export async function testTelegram() {
  await requireAdmin();
  const ok = await send("test", "✅ Test message from the admin panel");
  back("/settings#telegram", ok ? "测试消息已发送" : "发送失败：检查 Bot Token 和 Chat ID", ok ? "msg" : "err");
}

export async function saveCode(f: FormData) {
  await requireAdmin();
  await saveSettings({ headCode: String(f.get("headCode") ?? ""), bodyEndCode: String(f.get("bodyEndCode") ?? "") });
  revalidatePath("/", "layout");
  await logAction("修改代码插入");
  back("/settings#code", "代码已保存，页面缓存已清除");
}

export async function changePassword(f: FormData) {
  const acc = await requireAdmin();
  if (!(await verifyPassword(str(f, "current"), acc.passwordHash))) back("/settings#account", "当前密码不正确", "err");
  const pw = str(f, "next");
  if (pw.length < 12) back("/settings#account", "新密码至少 12 位", "err");
  const username = str(f, "username") || acc.username;
  const updated = { ...acc, username, passwordHash: await hashPassword(pw), sessionVersion: acc.sessionVersion + 1 };
  await saveAccount(updated);
  (await cookies()).set(COOKIE, await signSession(username, updated.sessionVersion), { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: SESSION_DAYS * 86400 });
  await logAction("修改密码（其他设备已退出登录）");
  back("/settings#account", "密码已修改，其他设备已退出登录");
}

export async function totpBegin() {
  const acc = await requireAdmin();
  await saveAccount({ ...acc, pendingTotpSecret: newTotpSecret() });
  back("/settings#account", "扫描或输入下方密钥，然后填写 6 位验证码确认");
}

export async function totpConfirm(f: FormData) {
  const acc = await requireAdmin();
  if (!acc.pendingTotpSecret || !verifyTotp(acc.pendingTotpSecret, str(f, "code"))) back("/settings#account", "验证码不正确", "err");
  await saveAccount({ ...acc, totpSecret: acc.pendingTotpSecret!, totpEnabled: true, pendingTotpSecret: null });
  await logAction("开启两步验证");
  back("/settings#account", "两步验证已开启");
}

export async function totpDisable(f: FormData) {
  const acc = await requireAdmin();
  if (!(await verifyPassword(str(f, "current"), acc.passwordHash))) back("/settings#account", "当前密码不正确", "err");
  await saveAccount({ ...acc, totpEnabled: false, totpSecret: null, pendingTotpSecret: null });
  await logAction("关闭两步验证");
  back("/settings#account", "两步验证已关闭");
}

// ------------------------------------------------------------------ Video sources
async function watchPathsFor(mediaType: string, tmdbId: number): Promise<string[]> {
  if (mediaType === "movie") {
    const m = await prisma.movie.findUnique({ where: { id: tmdbId } });
    return m ? [paths.movie(m.id, m.slug, m.year), `${paths.movie(m.id, m.slug, m.year)}/watch`] : [];
  }
  const e = await prisma.episode.findUnique({ where: { id: tmdbId }, include: { show: { select: { id: true, slug: true } } } });
  if (!e) return [];
  const p = paths.episode(e.show.id, e.show.slug, e.seasonNumber, e.episodeNumber);
  return [p, `${p}/watch`, paths.season(e.show.id, e.show.slug, e.seasonNumber)];
}

export async function addSource(f: FormData) {
  await requireAdmin();
  const mediaType = str(f, "mediaType") === "episode" ? "episode" : "movie";
  const kind = str(f, "kind");
  const url = str(f, "url");
  const rightsNote = str(f, "rightsNote");
  if (!["hls", "mp4", "iframe"].includes(kind)) back("/sources", "请选择片源类型", "err");
  if (!/^https:\/\//.test(url)) back("/sources", "片源地址必须以 https:// 开头", "err");
  if (!rightsNote) back("/sources", "请填写授权说明（版权方、地区、到期时间）", "err");
  let tmdbId = 0;
  if (mediaType === "movie") {
    tmdbId = num(f, "movieId");
    if (!(await prisma.movie.findUnique({ where: { id: tmdbId } }))) back("/sources", `库里没有电影 ${tmdbId}，请先在同步管理里添加`, "err");
  } else {
    const ep = await prisma.episode.findUnique({ where: { showId_seasonNumber_episodeNumber: { showId: num(f, "showId"), seasonNumber: num(f, "season"), episodeNumber: num(f, "episode") } } });
    if (!ep) back("/sources", "找不到这一集，请确认剧集 ID、季和集号，或先刷新该剧", "err");
    tmdbId = ep.id;
  }
  await prisma.videoSource.create({ data: { mediaType, tmdbId, kind, url, label: str(f, "label") || "Server 1", priority: num(f, "priority"), rightsNote } });
  await publish(await watchPathsFor(mediaType, tmdbId));
  await logAction(`添加片源 ${mediaType} ${tmdbId}`);
  back("/sources", "片源已添加");
}

export async function toggleSource(f: FormData) {
  await requireAdmin();
  const s = await prisma.videoSource.findUnique({ where: { id: num(f, "id") } });
  if (s) {
    await prisma.videoSource.update({ where: { id: s.id }, data: { enabled: !s.enabled } });
    await publish(await watchPathsFor(s.mediaType, s.tmdbId));
  }
  back("/sources", s?.enabled ? "已停用" : "已启用");
}

export async function deleteSource(f: FormData) {
  await requireAdmin();
  const s = await prisma.videoSource.findUnique({ where: { id: num(f, "id") } });
  if (s) {
    await prisma.videoSource.delete({ where: { id: s.id } });
    await publish(await watchPathsFor(s.mediaType, s.tmdbId));
    await logAction(`删除片源 #${s.id}`);
  }
  back("/sources", "已删除");
}
