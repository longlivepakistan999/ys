import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./admin.css";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin", robots: { index: false, follow: false } };

export default function AdminRoot({ children }: { children: ReactNode }) {
  return <div className="admin-body" lang="zh-CN">{children}</div>;
}
