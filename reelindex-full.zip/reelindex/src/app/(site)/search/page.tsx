import Link from "next/link";
import type { Metadata } from "next";
import { logSearch, movieHref, search, tvHref } from "@/lib/data/queries";
import { paths } from "@/lib/slug";
import { Avatar, Poster } from "@/components/ui";

// Search is never cached or indexed (blocked in robots.txt too).
export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Search", robots: { index: false, follow: true } };

type Props = { searchParams: Promise<{ q?: string; type?: string }> };

export default async function Page({ searchParams }: Props) {
  const { q = "", type = "all" } = await searchParams;
  const r = await search(q);
  if (q.trim()) logSearch(q).catch(() => {});
  const total = r.movies.length + r.tv.length + r.people.length;
  const tab = (t: string, label: string, n: number) => (
    <Link href={`/search?q=${encodeURIComponent(q)}${t === "all" ? "" : `&type=${t}`}`} rel="nofollow" aria-current={type === t ? "page" : undefined}>{label}<span className="count">{n}</span></Link>
  );
  const show = (t: string) => type === "all" || type === t;
  return (
    <div className="wrap">
      <div className="page-head"><div><span className="eyebrow">Search</span><h1 className="page-title">{q ? <>Results for “{q}”</> : "Search"}</h1></div></div>
      <form className="search-big" action="/search" method="get" role="search">
        <label className="visually-hidden" htmlFor="sq">Search</label>
        <input className="field" id="sq" name="q" type="search" defaultValue={q} placeholder="Search movies, shows, people" autoFocus />
        <button className="btn btn-primary" type="submit">Search</button>
      </form>
      {q.trim().length >= 2 && (
        <>
          <nav className="tabs" style={{ margin: "22px 0 4px" }} aria-label="Result type">
            {tab("all", "All", total)}{tab("tv", "TV Shows", r.tv.length)}{tab("movie", "Movies", r.movies.length)}{tab("person", "People", r.people.length)}
          </nav>
          {total === 0 && <p className="empty">No matches. Check the spelling, or try the original title.</p>}
          <ol className="result-list">
            {show("tv") && r.tv.map((t) => (
              <li className="result" key={`t${t.id}`}><Link href={tvHref(t)}><Poster title={t.name} path={t.posterPath} mini /></Link>
                <div><div><span className="type-tag">TV</span><Link className="row-title" href={tvHref(t)}>{t.name}</Link></div>
                  <div className="row-meta">{t.firstAirYear ?? ""}{t.numberOfSeasons ? ` · ${t.numberOfSeasons} season${t.numberOfSeasons === 1 ? "" : "s"}` : ""}</div></div></li>
            ))}
            {show("movie") && r.movies.map((m) => (
              <li className="result" key={`m${m.id}`}><Link href={movieHref(m)}><Poster title={m.title} path={m.posterPath} mini /></Link>
                <div><div><span className="type-tag">Movie</span><Link className="row-title" href={movieHref(m)}>{m.title}</Link></div>
                  <div className="row-meta">{m.year ?? ""}{m.rating ? ` · ★ ${m.rating.toFixed(1)}` : ""}</div></div></li>
            ))}
            {show("person") && r.people.map((p) => (
              <li className="result" key={`p${p.id}`}><Link href={paths.person(p.id, p.slug)}><Avatar name={p.name} path={p.profilePath} /></Link>
                <div><div><span className="type-tag">Person</span><Link className="row-title" href={paths.person(p.id, p.slug)}>{p.name}</Link></div>
                  <div className="row-meta">{p.knownFor ?? ""}</div></div></li>
            ))}
          </ol>
        </>
      )}
    </div>
  );
}
