import Link from "next/link";
import { cache } from "react";
import { permanentRedirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { ensureDetail } from "@/lib/data/ensure";
import { movieLinks } from "@/lib/data/queries";
import { idFromSegment, paths } from "@/lib/slug";
import { missing } from "@/lib/route";
import { buildMeta } from "@/lib/seo/meta";
import { breadcrumbLd, JsonLd } from "@/lib/seo/jsonld";
import { fmtRuntime, getSite, img } from "@/lib/site";
import type { trimCollection } from "@/lib/tmdb/trim";
import { Ad } from "@/components/Ad";
import { Crumbs, Poster, hue } from "@/components/ui";

export const revalidate = 86400;
export async function generateStaticParams() { return []; }
type Props = { params: Promise<{ idSlug: string }> };

const load = cache(async (segment: string) => {
  const id = idFromSegment(segment);
  if (!id) return missing(`/collection/${segment}`);
  try { await ensureDetail("collection", id); } catch { /* cached */ }
  const c = await prisma.collection.findUnique({ where: { id } });
  if (!c || c.removedAt || c.hidden || !c.detail) return missing(`/collection/${segment}`);
  const canonical = paths.collection(c.id, c.slug);
  if (`/collection/${segment}` !== canonical) permanentRedirect(canonical);
  const parts = (c.detail as unknown as ReturnType<typeof trimCollection>).parts;
  const rows = await prisma.movie.findMany({ where: { id: { in: parts.map((p) => p.id) } }, select: { id: true, runtime: true, overview: true } });
  const extra = new Map(rows.map((r) => [r.id, r]));
  const links = await movieLinks(parts.map((p) => p.id));
  const name = c.name.replace(/\s+Collection$/i, "");
  return { c, canonical, parts, extra, links, name };
});

export async function generateMetadata({ params }: Props) {
  const { c, canonical, parts, name } = await load((await params).idSlug);
  const released = parts.filter((p) => p.releaseDate && new Date(p.releaseDate) <= new Date());
  const span = released.length ? `${released[0].year}–${released[released.length - 1].year}` : "";
  return buildMeta({
    title: `${name} Movies in Order`, path: canonical, index: c.isIndexable, image: img(c.backdropPath, "w1280"),
    description: `All ${parts.length} ${name} movies in release order${span ? ` (${span})` : ""}${released.length ? `, from ${released[0].title} to ${released[released.length - 1].title}` : ""}, with runtimes and ratings.`,
  });
}

export default async function Page({ params }: Props) {
  const { c, canonical, parts, extra, links, name } = await load((await params).idSlug);
  const site = await getSite();
  const total = parts.reduce((n, p) => n + (extra.get(p.id)?.runtime ?? 0), 0);
  const rated = parts.filter((p) => p.rating);
  const avg = rated.length ? rated.reduce((n, p) => n + p.rating, 0) / rated.length : 0;
  const years = parts.map((p) => p.year).filter((y): y is number => !!y);
  const crumbs: [string, string][] = [["Home", "/"], ["Movies", "/movies"], [c.name, canonical]];
  return (
    <>
      <JsonLd data={[{
        "@context": "https://schema.org", "@type": "ItemList", name: c.name, itemListOrder: "https://schema.org/ItemListOrderAscending",
        itemListElement: parts.map((p, i) => ({ "@type": "ListItem", position: i + 1, name: p.title, url: site.url + (links.get(p.id) ?? `/movie/${p.id}`) })),
      }, breadcrumbLd(site.url, crumbs)]} />
      <section className="hero">
        <div className="hero-bg" style={{ ["--h" as string]: hue(c.name) }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {c.backdropPath && <img src={img(c.backdropPath, "w1280")!} alt="" />}
        </div>
        <div className="wrap">
          <Crumbs items={crumbs} />
          <div className="hero-grid" style={{ gridTemplateColumns: "minmax(0,1fr)" }}>
            <div className="hero-text">
              <div className="hero-meta"><span>Collection</span><span>{parts.length} movies</span>{years.length > 0 && <span>{Math.min(...years)}–{Math.max(...years)}</span>}{total > 0 && <span>{fmtRuntime(total)} total</span>}</div>
              <h1 className="hero-title">{name} <small>Movies in Order</small></h1>
              <p className="hero-overview">{c.overview || `The ${name} films in release order.`} Watching them in release order follows the story as audiences first saw it.</p>
            </div>
          </div>
        </div>
      </section>
      <div className="wrap">
        <section className="section">
          <div className="section-head"><h2 className="section-title">Release Order</h2>{avg > 0 && <span className="count">average ★ {avg.toFixed(1)}</span>}</div>
          <ol className="order-list">
            {parts.map((p, i) => {
              const href = links.get(p.id) ?? `/movie/${p.id}`;
              const ex = extra.get(p.id);
              return (
                <li className="order-row" key={p.id}>
                  <span className="order-num">{i + 1}</span>
                  <Link href={href}><Poster title={p.title} path={p.poster} mini /></Link>
                  <div>
                    <Link className="row-title" href={href}>{p.title}</Link>
                    <div className="row-meta">{p.year ?? "TBA"}{ex?.runtime ? ` · ${fmtRuntime(ex.runtime)}` : ""}</div>
                    {ex?.overview && <p className="row-desc">{ex.overview.length > 200 ? ex.overview.slice(0, 197).replace(/\s+\S*$/, "") + "…" : ex.overview}</p>}
                  </div>
                  {p.rating ? <div className="rank-score"><b>★ {p.rating.toFixed(1)}</b></div> : <span />}
                </li>
              );
            })}
          </ol>
        </section>
        <Ad slot="content-bottom" page="collection" />
      </div>
    </>
  );
}
