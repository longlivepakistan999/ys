import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/db";
import { homeBlock } from "@/lib/data/queries";
import { buildMeta } from "@/lib/seo/meta";
import { JsonLd } from "@/lib/seo/jsonld";
import { fmtInt, getSite } from "@/lib/site";
import { Grid, Section } from "@/components/ui";

export const revalidate = 3600;

export async function generateMetadata(): Promise<Metadata> {
  return buildMeta({
    title: "Find Where to Watch Movies & TV Shows",
    description: "Search any movie or TV show to see the cast, episode guide, ratings and where to stream, rent or buy it. Updated daily.",
    path: "/",
  });
}

/** Home (needs doc §4): search box, recommended movies, recommended TV shows. No ads. */
export default async function Home() {
  const site = await getSite();
  const [movies, shows, mCount, tCount, eCount] = await Promise.all([
    homeBlock("movies"), homeBlock("tv"),
    prisma.movie.count({ where: { removedAt: null } }),
    prisma.tvShow.count({ where: { removedAt: null } }),
    prisma.episode.count(),
  ]);
  const quick = site.settings.homeQuickLinks.split("\n").map((l) => l.split("|").map((x) => x.trim())).filter((p) => p.length === 2 && p[0] && p[1].startsWith("/"));
  return (
    <>
      <JsonLd data={{
        "@context": "https://schema.org", "@type": "WebSite", name: site.name, url: site.url + "/",
        potentialAction: { "@type": "SearchAction", target: { "@type": "EntryPoint", urlTemplate: `${site.url}/search?q={search_term_string}` }, "query-input": "required name=search_term_string" },
      }} />
      <section className="home-hero">
        <div className="wrap">
          <span className="eyebrow">Movies · TV shows · Episodes · Cast</span>
          <h1>Find it. <em>Then watch it.</em></h1>
          <form className="home-search" action="/search" method="get" role="search">
            <label className="visually-hidden" htmlFor="q">Search movies, TV shows and people</label>
            <input className="field" id="q" name="q" type="search" placeholder="Search a movie, show or actor" autoComplete="off" />
            <button className="btn btn-primary" type="submit">Search</button>
          </form>
          {quick.length > 0 && (
            <div className="quick"><span className="label">Popular</span>
              {quick.map(([label, href]) => <Link key={href} className="chip" href={href}>{label}</Link>)}
            </div>
          )}
          <p className="stats-line">{fmtInt(mCount)} movies · {fmtInt(tCount)} TV shows · {fmtInt(eCount)} episodes · updated daily</p>
        </div>
      </section>
      <div className="wrap">
        <Section title="Recommended Movies" link={["All movies", "/movies"]}><Grid items={movies} /></Section>
        <Section title="Recommended TV Shows" link={["All TV shows", "/tv"]}><Grid items={shows} /></Section>
      </div>
    </>
  );
}
