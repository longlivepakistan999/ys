import Link from "next/link";
import { cache } from "react";
import { listMovies, listTv } from "@/lib/data/queries";
import { codeFromSlug, countryName, countryTitle } from "@/lib/countries";
import { guardPage, missing, splitPage } from "@/lib/route";
import { fillTemplate, getSettings } from "@/lib/settings";
import { buildMeta } from "@/lib/seo/meta";
import { fmtInt, listJoin } from "@/lib/site";
import { ListPage } from "@/views/ListPage";

export const revalidate = 3600;
export async function generateStaticParams() { return []; }
type Props = { params: Promise<{ path: string[] }> };

/** /country/{slug}/movies | /country/{slug}/tv (+ /page/N) */
const load = cache(async (key: string) => {
  const segs = key.split("/");
  const { rest, page } = await splitPage(segs, (r) => `/country/${r.join("/")}`);
  const [slug, kind] = rest;
  const code = slug ? codeFromSlug(slug) : null;
  if (rest.length !== 2 || !code || (kind !== "movies" && kind !== "tv")) return missing(`/country/${key}`);
  const s = await getSettings();
  const r = kind === "movies" ? await listMovies({ country: code }, "popular", page) : await listTv({ country: code }, "popular", page);
  const base = `/country/${slug}/${kind}`;
  await guardPage(page, r.pages, s.maxListPages, base);
  const title = countryTitle(code, kind);
  const top = r.items.slice(0, 3).map((x) => x.title);
  return { code, kind, slug, page, r, base, title, top, s };
});

export async function generateMetadata({ params }: Props) {
  const { code, kind, page, r, base, title, top, s } = await load((await params).path.join("/"));
  const noun = kind === "movies" ? "movies" : "TV shows";
  return buildMeta({
    title: page > 1 ? fillTemplate(s.seoTemplates.page, { list_title: title, page }) : title,
    path: page > 1 ? `${base}/page/${page}` : base, index: r.total >= s.minListSize,
    description: `Browse ${fmtInt(r.total)} ${noun} from ${countryName(code)}${top.length ? `, including ${listJoin(top)}` : ""}. Cast, ratings and where to watch.`,
  });
}

export default async function Page({ params }: Props) {
  const { code, kind, slug, page, r, base, title, top, s } = await load((await params).path.join("/"));
  const noun = kind === "movies" ? "movies" : "TV shows";
  return (
    <ListPage eyebrow={`Country · ${code}`} title={title} page={page} pages={r.pages} total={r.total} perPage={r.perPage} items={r.items} base={base}
      maxPages={s.maxListPages} adPage="list" count={`${fmtInt(r.total)} ${noun}`}
      crumbs={[["Home", "/"], ["Countries", "/countries"], [countryName(code), base]]}
      intro={`This page lists ${fmtInt(r.total)} ${noun} from ${countryName(code)}, most popular first${top.length ? `, led by ${listJoin(top)}` : ""}. Open any title for its cast, ${kind === "tv" ? "episode guide" : "details"} and streaming options.`}
      before={
        <nav className="tabs" style={{ marginBottom: 22 }} aria-label="Type">
          <Link href={`/country/${slug}/tv`} aria-current={kind === "tv" ? "page" : undefined}>TV Shows</Link>
          <Link href={`/country/${slug}/movies`} aria-current={kind === "movies" ? "page" : undefined}>Movies</Link>
        </nav>
      } />
  );
}
