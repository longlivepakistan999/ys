import Link from "next/link";
import { countryCounts } from "@/lib/data/queries";
import { countryName, countrySlug } from "@/lib/countries";
import { buildMeta } from "@/lib/seo/meta";
import { breadcrumbLd, JsonLd } from "@/lib/seo/jsonld";
import { fmtInt, getSite } from "@/lib/site";
import { Crumbs } from "@/components/ui";

export const revalidate = 86400;

export async function generateMetadata() {
  return buildMeta({
    title: "Movies & TV Shows by Country",
    description: "Browse movies and TV shows by country of origin: Korean dramas, Japanese anime, British TV, French films and more.",
    path: "/countries",
  });
}

export default async function Page() {
  const site = await getSite();
  const counts = await countryCounts();
  const rows = [...counts.entries()].map(([code, n]) => ({ code, name: countryName(code), slug: countrySlug(code), ...n }))
    .filter((r) => r.name !== r.code && r.movies + r.tv >= 20);
  const popular = [...rows].sort((a, b) => b.movies + b.tv - (a.movies + a.tv)).slice(0, 12);
  const az = [...rows].sort((a, b) => a.name.localeCompare(b.name));
  const crumbs: [string, string][] = [["Home", "/"], ["Countries", "/countries"]];
  return (
    <div className="wrap">
      <JsonLd data={breadcrumbLd(site.url, crumbs)} />
      <Crumbs items={crumbs} />
      <div className="page-head"><div><h1 className="page-title">Browse by Country</h1>
        <p className="page-sub">Find films and series by where they were made. Counts include every title in the catalog.</p></div></div>
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="section-head"><h2 className="section-title">Popular Countries</h2></div>
        <div className="country-grid">
          {popular.map((r) => (
            <div className="country" key={r.code}>
              <span className="cc">{r.code}</span>
              <Link className="country-name" href={`/country/${r.slug}/${r.tv > r.movies ? "tv" : "movies"}`}>{r.name}</Link>
              <span className="country-links"><Link href={`/country/${r.slug}/movies`}>{fmtInt(r.movies)} movies</Link><Link href={`/country/${r.slug}/tv`}>{fmtInt(r.tv)} shows</Link></span>
            </div>
          ))}
        </div>
      </section>
      <section className="section">
        <div className="section-head"><h2 className="section-title">All Countries A–Z</h2><span className="count">titles</span></div>
        <ul className="az">{az.map((r) => <li key={r.code}><Link href={`/country/${r.slug}/movies`}>{r.name}</Link><span>{fmtInt(r.movies + r.tv)}</span></li>)}</ul>
      </section>
    </div>
  );
}
