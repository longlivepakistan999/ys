import Link from "next/link";

export default function NotFound() {
  return (
    <div className="wrap notfound">
      <div className="big">404</div>
      <h1 className="page-title" style={{ marginTop: 18 }}>This page isn&apos;t showing</h1>
      <p className="page-sub">The link may be old, or the title may have been removed. Search for it or start from one of these.</p>
      <form className="search-big" style={{ marginTop: 22 }} action="/search" method="get" role="search">
        <label className="visually-hidden" htmlFor="nq">Search</label>
        <input className="field" id="nq" name="q" type="search" placeholder="Search movies, shows, people" />
        <button className="btn btn-primary" type="submit">Search</button>
      </form>
      <div className="chips" style={{ marginTop: 20 }}>
        <Link className="chip" href="/movies">Movies</Link><Link className="chip" href="/tv">TV Shows</Link>
        <Link className="chip" href="/top-rated/movies">Top Rated</Link><Link className="chip" href="/countries">Countries</Link>
      </div>
    </div>
  );
}
