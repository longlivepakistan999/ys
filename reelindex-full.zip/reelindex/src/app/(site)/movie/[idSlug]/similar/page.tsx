import { SimilarPage, similarMetadata } from "@/views/movie";

export const revalidate = 86400;
export async function generateStaticParams() { return []; }

type Props = { params: Promise<{ idSlug: string }> };

export async function generateMetadata({ params }: Props) {
  return similarMetadata((await params).idSlug);
}

export default async function Page({ params }: Props) {
  return <SimilarPage segment={(await params).idSlug} />;
}
