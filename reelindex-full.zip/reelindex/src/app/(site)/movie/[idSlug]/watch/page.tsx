import { MovieWatchPage, movieWatchMetadata } from "@/views/watch";

export const revalidate = 3600;
export async function generateStaticParams() { return []; }
type Props = { params: Promise<{ idSlug: string }> };

export async function generateMetadata({ params }: Props) { return movieWatchMetadata((await params).idSlug); }
export default async function Page({ params }: Props) { return <MovieWatchPage segment={(await params).idSlug} />; }
