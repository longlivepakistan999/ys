import { MoviePage, movieMetadata } from "@/views/movie";

export const revalidate = 86400;
export async function generateStaticParams() { return []; }

type Props = { params: Promise<{ idSlug: string }> };

export async function generateMetadata({ params }: Props) {
  return movieMetadata((await params).idSlug);
}

export default async function Page({ params }: Props) {
  return <MoviePage segment={(await params).idSlug} />;
}
