import type { ReactNode } from "react";
import { Footer, Header } from "@/components/Chrome";
import { getSite } from "@/lib/site";

export default async function SiteLayout({ children }: { children: ReactNode }) {
  const site = await getSite();
  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <Header siteName={site.name} />
      <main id="main">{children}</main>
      <Footer siteName={site.name} text={site.footerText} />
    </>
  );
}
