import { permanentRedirect } from "next/navigation";

export default function Page() {
  permanentRedirect("/top-rated/movies");
}
