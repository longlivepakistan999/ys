import Link from "next/link";
import { cache } from "react";
import { listMovies, listTv } from "@/lib/data/queries";
import { genreNames } from "@/lib/genres";
import { guardPage, missing, splitPage } from "@/lib/route";
import { fillTemplate, getSettings } from "@/lib/settings";
import { buildMeta } from "@/lib/seo/meta";
import { breadcrumbLd, JsonLd } from "@/lib/seo/jsonld";
import { fmtInt, getSite } from "@/lib/site";
import { Crumbs, Pager, Poster } from "@/components/ui";

export const revalidate = 3600;
export async function generateStaticParams() { return []; }
type Props = { params: Promise<{ path: string[] }> };

const load = cache(async (key: string) => {
  const segs = key.split("/");
  const { rest, page } = await splitPage(segs, (r) => `/top-rated/${r.join("/")}`);
  const kind = rest[0];
  if (rest.length !== 1 || (kind !== "movies" && kind !== "tv")) return missing(`/top-rated/${key}`);
  const s = await getSettings();
  const minVotes = kind === "movies" ? s.topRatedMinVotesMovie : s.topRatedMinVotesTv;
  const r = kind === "movies" ? await listMovies({ minVotes }, "rating", page) : await listTv({ minVotes }, "rating", page);
  const base = `/top-rated/${kind}`;
  await guardPage(page, r.pages, s.maxListPages, base);
  const label = kind === "movies" ? "Movies" : "TV Shows";
  const genres = new Map<number, string>();
  for (const g of await genreNames([...new Set(r.rows.flatMap((x) => ("genres" in x ? [] : [])))])) genres.set(g.id, g.name);
  return { kind, page, r, base, label, minVotes, s };
});

export async function generateMetadata({ params }: Props) {
  const { page, label, minVotes, base, s } = await load((await params).path.join("/"));
  const t = `Top Rated ${label} of All Time`;
  return buildMeta({
    title: page > 1 ? fillTemplate(s.seoTemplates.page, { list_title: t, page }) : t, path: page > 1 ? `${base}/page/${page}` : base,
    description: `The highest rated ${label.toLowerCase()} of all time, ranked by average user score. Only titles with at least ${fmtInt(minVotes)} votes are included.`,
  });
}

export default async function Page({ params }: Props) {
  const { kind, page, r, base, label, minVotes, s } = await load((await params).path.join("/"));
  const site = await getSite();
  const crumbs: [string, string][] = [["Home", "/"], [`Top Rated ${label}`, base]];
  const start = (page - 1) * r.perPage;
  return (
    <div className="wrap">
      <JsonLd data={[breadcrumbLd(site.url, crumbs), {
        "@context": "https://schema.org", "@type": "ItemList", name: `Top Rated ${label}`,
        itemListElement: r.items.map((x, i) => ({ "@type": "ListItem", position: start + i + 1, name: x.title, url: site.url + x.href })),
      }]} />
      <Crumbs items={crumbs} />
      <div className="page-head"><div><h1 className="page-title">Top Rated {label}</h1>
        <p className="page-sub">{page === 1 ? `Ranked by average score. A title needs at least ${fmtInt(minVotes)} votes to qualify, so a few perfect scores cannot push an obscure title to the top.` : `Page ${page} · ranks ${start + 1}–${start + r.items.length}`}</p></div></div>
      <nav className="tabs" style={{ marginBottom: 8 }} aria-label="Type">
        <Link href="/top-rated/movies" aria-current={kind === "movies" ? "page" : undefined}>Movies</Link>
        <Link href="/top-rated/tv" aria-current={kind === "tv" ? "page" : undefined}>TV Shows</Link>
      </nav>
      <ol className="rank-list">
        {r.items.map((x, i) => (
          <li className="rank-row" key={x.key}>
            <span className="rank-num">{start + i + 1}</span>
            <Link href={x.href}><Poster title={x.title} path={x.poster} mini /></Link>
            <div><Link className="row-title" href={x.href}>{x.title}</Link><div className="row-meta">{x.year}</div></div>
            <div className="rank-score"><b>★ {x.rating?.toFixed(1)}</b><small>{fmtInt(r.rows[i].voteCount)} votes</small></div>
          </li>
        ))}
      </ol>
      <Pager base={base} page={page} pages={r.pages} maxPages={s.maxListPages} />
    </div>
  );
}
