import { PersonMoviesPage, personMoviesMetadata } from "@/views/person";

export const revalidate = 86400;
export async function generateStaticParams() { return []; }
type Props = { params: Promise<{ idSlug: string }> };

export async function generateMetadata({ params }: Props) { return personMoviesMetadata((await params).idSlug); }
export default async function Page({ params }: Props) { return <PersonMoviesPage segment={(await params).idSlug} />; }
