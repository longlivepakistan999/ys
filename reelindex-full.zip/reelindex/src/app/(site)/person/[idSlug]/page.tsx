import { PersonPage, personMetadata } from "@/views/person";

export const revalidate = 86400;
export async function generateStaticParams() { return []; }
type Props = { params: Promise<{ idSlug: string }> };

export async function generateMetadata({ params }: Props) { return personMetadata((await params).idSlug); }
export default async function Page({ params }: Props) { return <PersonPage segment={(await params).idSlug} />; }
