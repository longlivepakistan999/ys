import { catalogMetadata, resolveCatalog } from "@/views/catalog";

export const revalidate = 3600;

export async function generateMetadata() {
  return catalogMetadata(await resolveCatalog("tv", []));
}

export default async function Page() {
  return (await resolveCatalog("tv", [])).render();
}
