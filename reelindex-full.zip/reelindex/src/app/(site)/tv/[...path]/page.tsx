import { catalogMetadata, resolveCatalog } from "@/views/catalog";
import { EpisodePage, episodeMetadata, SeasonPage, seasonMetadata, ShowPage, showMetadata } from "@/views/tv";
import { missing } from "@/lib/route";
import { EpisodeWatchPage, episodeWatchMetadata } from "@/views/watch";

/**
 * /tv/{id}-{slug}                       show
 * /tv/{id}-{slug}/season-{n}|specials   season
 * /tv/{id}-{slug}/season-{n}/episode-{m}
 * /tv/{id}-{slug}/season-{n}/episode-{m}/watch
 * anything else → catalog views (genre, year, platform, pagination)
 */
export const revalidate = 86400;
export async function generateStaticParams() { return []; }

type Props = { params: Promise<{ path: string[] }> };
const isShow = (seg: string) => /^\d/.test(seg);

export async function generateMetadata({ params }: Props) {
  const { path } = await params;
  if (isShow(path[0])) {
    if (path.length === 1) return showMetadata(path[0]);
    if (path.length === 2) return seasonMetadata(path[0], path[1]);
    if (path.length === 3) return episodeMetadata(path[0], path[1], path[2]);
    if (path.length === 4 && path[3] === "watch") return episodeWatchMetadata(path[0], path[1], path[2]);
    return missing(`/tv/${path.join("/")}`);
  }
  return catalogMetadata(await resolveCatalog("tv", path));
}

export default async function Page({ params }: Props) {
  const { path } = await params;
  if (isShow(path[0])) {
    if (path.length === 1) return <ShowPage segment={path[0]} />;
    if (path.length === 2) return <SeasonPage segment={path[0]} seasonSeg={path[1]} />;
    if (path.length === 3) return <EpisodePage segment={path[0]} seasonSeg={path[1]} epSeg={path[2]} />;
    if (path.length === 4 && path[3] === "watch") return <EpisodeWatchPage segment={path[0]} seasonSeg={path[1]} epSeg={path[2]} />;
    return missing(`/tv/${path.join("/")}`);
  }
  return (await resolveCatalog("tv", path)).render();
}
