import { catalogMetadata, resolveCatalog } from "@/views/catalog";

export const revalidate = 3600;

export async function generateMetadata() {
  return catalogMetadata(await resolveCatalog("movies", []));
}

export default async function Page() {
  return (await resolveCatalog("movies", [])).render();
}
