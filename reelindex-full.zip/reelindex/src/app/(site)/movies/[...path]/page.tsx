import { cache } from "react";
import { catalogMetadata, resolveCatalog } from "@/views/catalog";

export const revalidate = 3600;
export async function generateStaticParams() { return []; }

type Props = { params: Promise<{ path: string[] }> };
const view = cache((key: string) => resolveCatalog("movies", key.split("/")));

export async function generateMetadata({ params }: Props) {
  return catalogMetadata(await view((await params).path.join("/")));
}

export default async function Page({ params }: Props) {
  return (await view((await params).path.join("/"))).render();
}
