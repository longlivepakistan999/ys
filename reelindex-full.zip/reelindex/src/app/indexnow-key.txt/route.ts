import { secrets } from "@/lib/settings";

// Rendered per request (cheap) and cached by Cloudflare via cache-control; never built ahead of time.
export const dynamic = "force-dynamic";

/** IndexNow ownership check: the key file must be served from the site's own host. */
export async function GET() {
  const { indexNowKey } = await secrets();
  if (!indexNowKey) return new Response("Not found", { status: 404 });
  return new Response(indexNowKey, { headers: { "content-type": "text/plain; charset=utf-8" } });
}
