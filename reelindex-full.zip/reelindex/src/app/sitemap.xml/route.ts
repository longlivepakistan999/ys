import { countFor, indexXml, PER_FILE, TYPES } from "@/lib/seo/sitemaps";
import { secrets } from "@/lib/settings";

// Rendered per request (cheap) and cached by Cloudflare via cache-control; never built ahead of time.
export const dynamic = "force-dynamic";


/** Sitemap index: lists every /sitemaps/{type}-{n}.xml file. */
export async function GET() {
  const { siteUrl } = await secrets();
  const files: string[] = [];
  for (const t of TYPES) {
    const n = Math.max(1, Math.ceil((await countFor(t)) / PER_FILE));
    for (let i = 1; i <= n; i++) files.push(`${t}-${i}.xml`);
  }
  return new Response(indexXml(siteUrl, files), { headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=3600" } });
}
