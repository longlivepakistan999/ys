/** ASCII slug from a title: "Shōgun" → "shogun", "Se7en" → "se7en". */
export function slugify(input: string | null | undefined): string {
  if (!input) return "";
  return input
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/&/g, " and ")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80)
    .replace(/-+$/, "");
}

/** URL segments. The id comes first, so a changed slug is fixed with a 301, not a 404. */
export const paths = {
  movie: (id: number, slug: string, year?: number | null) =>
    `/movie/${[id, slug, year].filter(Boolean).join("-")}`,
  tv: (id: number, slug: string) => `/tv/${slug ? `${id}-${slug}` : id}`,
  season: (id: number, slug: string, n: number) => `${paths.tv(id, slug)}/${n === 0 ? "specials" : `season-${n}`}`,
  episode: (id: number, slug: string, s: number, e: number) => `${paths.season(id, slug, s)}/episode-${e}`,
  person: (id: number, slug: string) => `/person/${slug ? `${id}-${slug}` : id}`,
  collection: (id: number, slug: string) => `/collection/${slug ? `${id}-${slug}` : id}`,
};

/** "550-fight-club-1999" → 550 */
export function idFromSegment(segment: string): number | null {
  const m = /^(\d+)/.exec(segment);
  return m ? Number(m[1]) : null;
}
