import { notFound, permanentRedirect } from "next/navigation";
import { findRedirect } from "./data/queries";

/** Before a 404, honour redirects saved in Admin > SEO. */
export async function missing(path: string): Promise<never> {
  const r = await findRedirect(path).catch(() => null);
  if (r) permanentRedirect(r.newPath);
  notFound();
}

/**
 * Splits a trailing "page/N" off a path. N must be 2+ (page 1 is the base URL),
 * so "/page/1" redirects to the base and junk numbers 404.
 */
export async function splitPage(segments: string[], base: (rest: string[]) => string): Promise<{ rest: string[]; page: number }> {
  const n = segments.length;
  if (n >= 2 && segments[n - 2] === "page") {
    const rest = segments.slice(0, -2);
    const raw = segments[n - 1];
    if (!/^\d+$/.test(raw)) return missing("/" + segments.join("/"));
    const page = Number(raw);
    if (page === 1) permanentRedirect(base(rest));
    if (page < 1) return missing("/" + segments.join("/"));
    return { rest, page };
  }
  return { rest: segments, page: 1 };
}

/** Throws 404 when a page number is beyond the list or past the crawl-depth cap. */
export async function guardPage(page: number, pages: number, maxPages: number, path: string) {
  if (page > 1 && (page > pages || page > maxPages)) await missing(path);
}
