import { cache } from "react";
import { getSettings, secrets } from "./settings";

/** Site identity for rendering; cached per request. */
export const getSite = cache(async () => {
  const s = await getSettings();
  const { siteUrl } = await secrets();
  return { name: s.siteName, url: siteUrl, footerText: s.footerText, headCode: s.headCode, bodyEndCode: s.bodyEndCode, settings: s };
});

export const IMG = "https://image.tmdb.org/t/p";
export const img = (path: string | null | undefined, size: "w92" | "w185" | "w342" | "w500" | "w780" | "w1280" | "h632" | "original" = "w342") =>
  path ? `${IMG}/${size}${path}` : null;

/** ISR lifetimes in seconds (needs doc §8). */
export const TTL = {
  airing: 86_400,          // shows still on the air
  stable: 2_592_000,       // ended shows, older movies (30 days)
  list: 3_600,             // home, lists, aggregations
  day: 86_400,
};

export const fmtInt = (n: number) => n.toLocaleString("en-US");
export const fmtDate = (d: Date | string | null | undefined) => {
  if (!d) return "";
  const x = typeof d === "string" ? new Date(d + (d.length === 10 ? "T00:00:00Z" : "")) : d;
  return x.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" });
};
export const fmtRuntime = (m: number | null | undefined) => (!m ? "" : m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`);
export const ordinal = (n: number) => {
  const s = ["th", "st", "nd", "rd"], v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
};
export const listJoin = (a: string[]) => (a.length <= 1 ? a.join("") : a.length === 2 ? `${a[0]} and ${a[1]}` : `${a.slice(0, -1).join(", ")} and ${a[a.length - 1]}`);
