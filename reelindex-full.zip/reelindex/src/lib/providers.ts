/** Streaming services that get their own list pages (TMDB watch-provider ids). */
export const PROVIDERS = [
  { slug: "netflix", id: 8, name: "Netflix" },
  { slug: "prime-video", id: 9, name: "Prime Video" },
  { slug: "disney-plus", id: 337, name: "Disney+" },
  { slug: "max", id: 1899, name: "Max" },
  { slug: "hulu", id: 15, name: "Hulu" },
  { slug: "apple-tv-plus", id: 350, name: "Apple TV+" },
  { slug: "paramount-plus", id: 531, name: "Paramount+" },
  { slug: "peacock", id: 386, name: "Peacock" },
] as const;

export type ProviderDef = (typeof PROVIDERS)[number];
export const providerBySlug = (slug: string) => PROVIDERS.find((p) => p.slug === slug) ?? null;

/** URL region slugs for platform pages; no slug = United States. */
export const REGION_SLUGS = { uk: "GB", ca: "CA", au: "AU", nz: "NZ", ie: "IE" } as const;
export const REGION_NAMES: Record<string, string> = { US: "the United States", GB: "the United Kingdom", CA: "Canada", AU: "Australia", NZ: "New Zealand", IE: "Ireland" };
export const regionSlugFor = (code: string) => (Object.entries(REGION_SLUGS).find(([, c]) => c === code)?.[0] ?? "");
