import type { Metadata } from "next";
import { getSite } from "../site";

export interface MetaInput {
  title: string;
  description: string;
  path: string;
  index?: boolean;
  ogType?: "website" | "video.movie" | "video.tv_show" | "video.episode" | "profile";
  image?: string | null;
}

/** One place that turns page facts into <head> tags: title, description, canonical, robots, Open Graph. */
export async function buildMeta(m: MetaInput): Promise<Metadata> {
  const site = await getSite();
  const description = m.description.length > 160 ? m.description.slice(0, 157).replace(/\s+\S*$/, "") + "…" : m.description;
  return {
    title: { absolute: `${m.title} | ${site.name}` },
    description,
    alternates: { canonical: m.path },
    robots: m.index === false ? { index: false, follow: true } : { index: true, follow: true },
    openGraph: {
      type: (m.ogType ?? "website") as "website",
      siteName: site.name,
      title: m.title,
      description,
      url: m.path,
      ...(m.image ? { images: [{ url: m.image }] } : {}),
    },
    twitter: { card: m.image ? "summary_large_image" : "summary", title: m.title, description },
  };
}

export const noindexMeta = (title: string, description: string): Metadata => ({
  title, description, robots: { index: false, follow: true },
});
