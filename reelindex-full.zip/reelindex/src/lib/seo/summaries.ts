/**
 * Auto-written paragraphs that make each page's text its own (needs doc §5):
 * built from numbers and dates specific to the title, not the shared TMDB overview.
 */
import { fmtDate, fmtInt, fmtRuntime, listJoin, ordinal } from "../site";
import type { RegionProviders } from "../tmdb/trim";

const langNames = new Intl.DisplayNames(["en"], { type: "language" });
export const languageName = (code?: string | null) => {
  if (!code) return "";
  try { return langNames.of(code) ?? code; } catch { return code; }
};

function usWhere(p?: Record<string, RegionProviders>) {
  const us = p?.US;
  if (!us) return "";
  const stream = us.stream.map((x) => x.name).slice(0, 3);
  const buy = [...new Set([...us.rent, ...us.buy].map((x) => x.name))].slice(0, 3);
  if (stream.length && buy.length) return ` In the US you can stream it on ${listJoin(stream)}, or rent or buy it from ${listJoin(buy)}.`;
  if (stream.length) return ` In the US you can stream it on ${listJoin(stream)}.`;
  if (buy.length) return ` In the US you can rent or buy it from ${listJoin(buy)}.`;
  return "";
}

export function movieSummary(m: {
  title: string; year: number | null; genres: string[]; directors: string[]; cast: string[]; runtime: number | null;
  certification: string | null; rating: number; voteCount: number; releaseDate: Date | null; providers?: Record<string, RegionProviders>;
}) {
  const upcoming = m.releaseDate && m.releaseDate.getTime() > Date.now();
  const genre = m.genres[0]?.toLowerCase() ?? "film";
  let s = `${m.title} is ${m.year ? `a ${m.year} ` : "a "}${genre}`;
  if (m.directors.length) s += ` directed by ${listJoin(m.directors)}`;
  if (m.cast.length) s += `${m.directors.length ? "," : ""} starring ${listJoin(m.cast.slice(0, 3))}`;
  s += ".";
  if (upcoming) s += ` It is scheduled for release on ${fmtDate(m.releaseDate)}.`;
  if (m.runtime) s += ` It runs ${fmtRuntime(m.runtime).replace("h", " hours").replace("m", " minutes")}${m.certification ? ` and is rated ${m.certification} in the United States` : ""}.`;
  if (!upcoming && m.voteCount >= 10) s += ` Users give it an average of ${m.rating.toFixed(1)} out of 10 from ${fmtInt(m.voteCount)} votes.`;
  return s + usWhere(m.providers);
}

export function tvSummary(t: {
  name: string; creators: string[]; networks: string[]; firstAirDate: Date | null; lastAirDate: Date | null; status: string | null;
  seasons: number; episodes: number; cast: string[]; lastEpisode?: { s: number; e: number; name: string; airDate: string | null } | null;
  nextEpisode?: { s: number; e: number; name: string; airDate: string | null } | null; providers?: Record<string, RegionProviders>;
}) {
  const ended = t.status === "Ended" || t.status === "Canceled";
  let s = `${t.name} is a TV series`;
  if (t.creators.length) s += ` created by ${listJoin(t.creators)}`;
  if (t.networks.length) s += ` that ${ended ? "aired" : "airs"} on ${t.networks[0]}`;
  if (t.firstAirDate) s += ended && t.lastAirDate ? ` from ${fmtDate(t.firstAirDate)} to ${fmtDate(t.lastAirDate)}` : ` since ${fmtDate(t.firstAirDate)}`;
  s += `. It ${ended ? "ran for" : "has"} ${t.seasons} season${t.seasons === 1 ? "" : "s"} and ${fmtInt(t.episodes)} episode${t.episodes === 1 ? "" : "s"}`;
  if (t.cast.length) s += `, starring ${listJoin(t.cast.slice(0, 3))}`;
  s += ".";
  if (t.nextEpisode?.airDate) s += ` The next episode, Season ${t.nextEpisode.s} Episode ${t.nextEpisode.e}, airs on ${fmtDate(t.nextEpisode.airDate)}.`;
  else if (t.lastEpisode?.airDate) s += ` The ${ended ? "final" : "latest"} episode, Season ${t.lastEpisode.s} Episode ${t.lastEpisode.e}, aired on ${fmtDate(t.lastEpisode.airDate)}.`;
  return s + usWhere(t.providers);
}

export function seasonSummary(x: { show: string; season: number; episodes: { name: string | null; airDate: Date | null; runtime: number | null }[]; network?: string }) {
  const eps = x.episodes;
  const first = eps.find((e) => e.airDate);
  const last = [...eps].reverse().find((e) => e.airDate);
  const label = x.season === 0 ? `${x.show} Specials` : `${x.show} Season ${x.season}`;
  let s = `${label} has ${eps.length} episode${eps.length === 1 ? "" : "s"}.`;
  if (first?.airDate) {
    const future = first.airDate.getTime() > Date.now();
    s += ` It ${future ? "premieres" : "premiered"}${x.network ? ` on ${x.network}` : ""} on ${fmtDate(first.airDate)}${first.name ? ` with “${first.name}”` : ""}`;
    if (last?.airDate && last !== first) s += ` and ${last.airDate.getTime() > Date.now() ? "ends" : "ended"} on ${fmtDate(last.airDate)}${last.name ? ` with “${last.name}”` : ""}`;
    s += ".";
  }
  const rts = eps.map((e) => e.runtime).filter((r): r is number => !!r);
  if (rts.length) {
    const min = Math.min(...rts), max = Math.max(...rts);
    s += min === max ? ` Episodes run ${min} minutes.` : ` Episodes run ${min}–${max} minutes.`;
  }
  return s;
}

export function episodeSummary(x: { name: string | null; show: string; season: number; episode: number; seasonEpisodes: number; airDate: Date | null; runtime: number | null; directors: string[]; writers: string[]; guests: string[] }) {
  const n = x.name ? `“${x.name}”` : `Episode ${x.episode}`;
  let s = `${n} is the ${ordinal(x.episode)} episode of Season ${x.season} of ${x.show}`;
  if (x.episode === x.seasonEpisodes && x.seasonEpisodes > 1) s += " and the season finale";
  s += ".";
  if (x.airDate) s += ` It ${x.airDate.getTime() > Date.now() ? "airs" : "aired"} on ${fmtDate(x.airDate)}${x.runtime ? ` and runs ${x.runtime} minutes` : ""}.`;
  if (x.directors.length) s += ` It was directed by ${listJoin(x.directors)}${x.writers.length ? ` and written by ${listJoin(x.writers)}` : ""}.`;
  if (x.guests.length) s += ` Guest stars include ${listJoin(x.guests.slice(0, 3))}.`;
  return s;
}
