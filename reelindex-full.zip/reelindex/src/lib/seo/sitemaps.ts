/**
 * Sitemaps (needs doc §5): only indexable pages, split by type, ≤ 50,000 URLs per
 * file, lastmod from each row's updatedAt. Most popular titles come first in
 * each type, so the first files hold what matters most.
 */
import { prisma } from "../db";
import { getSettings } from "../settings";
import { paths } from "../slug";
import { genresFor } from "../genres";
import { countrySlug } from "../countries";
import { PROVIDERS } from "../providers";

export const PER_FILE = 50_000;
export type SitemapType = "movies" | "tv" | "seasons" | "episodes" | "people" | "collections" | "lists";
export const TYPES: SitemapType[] = ["movies", "tv", "seasons", "episodes", "people", "collections", "lists"];

export interface Url { loc: string; lastmod?: Date | null }

export async function countFor(type: SitemapType): Promise<number> {
  switch (type) {
    case "movies": return prisma.movie.count({ where: { isIndexable: true } });
    case "tv": return prisma.tvShow.count({ where: { isIndexable: true } });
    case "seasons": return prisma.season.count({ where: { isIndexable: true } });
    case "episodes": return prisma.episode.count({ where: { isIndexable: true } });
    case "people": return prisma.person.count({ where: { isIndexable: true } });
    case "collections": return prisma.collection.count({ where: { isIndexable: true } });
    case "lists": return 1;
  }
}

export async function urlsFor(type: SitemapType, n: number): Promise<Url[]> {
  const skip = (n - 1) * PER_FILE, take = PER_FILE;
  switch (type) {
    case "movies":
      return (await prisma.movie.findMany({ where: { isIndexable: true }, orderBy: [{ popularity: "desc" }, { id: "asc" }], skip, take, select: { id: true, slug: true, year: true, updatedAt: true } }))
        .map((m) => ({ loc: paths.movie(m.id, m.slug, m.year), lastmod: m.updatedAt }));
    case "tv":
      return (await prisma.tvShow.findMany({ where: { isIndexable: true }, orderBy: [{ popularity: "desc" }, { id: "asc" }], skip, take, select: { id: true, slug: true, updatedAt: true } }))
        .map((t) => ({ loc: paths.tv(t.id, t.slug), lastmod: t.updatedAt }));
    case "seasons":
      return (await prisma.season.findMany({ where: { isIndexable: true }, orderBy: [{ showId: "asc" }, { seasonNumber: "asc" }], skip, take, select: { seasonNumber: true, updatedAt: true, show: { select: { id: true, slug: true } } } }))
        .map((s) => ({ loc: paths.season(s.show.id, s.show.slug, s.seasonNumber), lastmod: s.updatedAt }));
    case "episodes":
      return (await prisma.episode.findMany({ where: { isIndexable: true }, orderBy: [{ showId: "asc" }, { seasonNumber: "asc" }, { episodeNumber: "asc" }], skip, take, select: { seasonNumber: true, episodeNumber: true, updatedAt: true, show: { select: { id: true, slug: true } } } }))
        .map((e) => ({ loc: paths.episode(e.show.id, e.show.slug, e.seasonNumber, e.episodeNumber), lastmod: e.updatedAt }));
    case "people":
      return (await prisma.person.findMany({ where: { isIndexable: true }, orderBy: [{ popularity: "desc" }, { id: "asc" }], skip, take, select: { id: true, slug: true, updatedAt: true } }))
        .map((p) => ({ loc: paths.person(p.id, p.slug), lastmod: p.updatedAt }));
    case "collections":
      return (await prisma.collection.findMany({ where: { isIndexable: true }, orderBy: { id: "asc" }, skip, take, select: { id: true, slug: true, updatedAt: true } }))
        .map((c) => ({ loc: paths.collection(c.id, c.slug), lastmod: c.updatedAt }));
    case "lists":
      return listUrls();
  }
}

/** Aggregation pages that pass the minimum-size rule. */
async function listUrls(): Promise<Url[]> {
  const s = await getSettings();
  const min = s.minListSize;
  const out: Url[] = [{ loc: "/" }, { loc: "/movies" }, { loc: "/tv" }, { loc: "/top-rated/movies" }, { loc: "/top-rated/tv" }, { loc: "/countries" }];
  const live = `"removedAt" IS NULL AND NOT hidden AND NOT adult AND "posterPath" IS NOT NULL`;

  for (const kind of ["movies", "tv"] as const) {
    const table = kind === "movies" ? `"Movie"` : `"TvShow"`;
    const yearCol = kind === "movies" ? "year" : `"firstAirYear"`;
    const genres = await genresFor(kind === "movies" ? "movie" : "tv");
    const gSlug = new Map(genres.map((g) => [g.id, g.slug]));
    const byGenre = await prisma.$queryRawUnsafe<{ g: number; n: bigint }[]>(`SELECT unnest(genres) AS g, count(*)::bigint AS n FROM ${table} WHERE ${live} GROUP BY 1`);
    for (const r of byGenre) if (Number(r.n) >= min && gSlug.has(r.g)) out.push({ loc: `/${kind}/${gSlug.get(r.g)}` });
    const byGenreYear = await prisma.$queryRawUnsafe<{ g: number; y: number; n: bigint }[]>(
      `SELECT g, y, count(*)::bigint AS n FROM (SELECT unnest(genres) AS g, ${yearCol} AS y FROM ${table} WHERE ${live} AND ${yearCol} IS NOT NULL) x GROUP BY 1, 2`);
    for (const r of byGenreYear) if (Number(r.n) >= min && gSlug.has(r.g)) out.push({ loc: `/${kind}/${gSlug.get(r.g)}/${r.y}` });
    const byCountry = await prisma.$queryRawUnsafe<{ c: string; n: bigint }[]>(`SELECT unnest(countries) AS c, count(*)::bigint AS n FROM ${table} WHERE ${live} GROUP BY 1`);
    for (const r of byCountry) if (Number(r.n) >= min) out.push({ loc: `/country/${countrySlug(r.c)}/${kind}` });
    for (const p of PROVIDERS) {
      for (const [slug, region] of [["", "US"], ["uk", "GB"], ["ca", "CA"], ["au", "AU"], ["nz", "NZ"], ["ie", "IE"]] as const) {
        const n = kind === "movies"
          ? await prisma.movie.count({ where: { providers: { has: `${region}:${p.id}` }, removedAt: null, hidden: false } })
          : await prisma.tvShow.count({ where: { providers: { has: `${region}:${p.id}` }, removedAt: null, hidden: false } });
        if (n >= min) out.push({ loc: `/${kind}/${p.slug}${slug ? `/${slug}` : ""}` });
      }
    }
  }
  const now = new Date();
  for (let i = 0; i < 4; i++) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + i, 1));
    out.push({ loc: `/movies/upcoming/${d.getUTCFullYear()}/${d.getUTCMonth() + 1}` });
  }
  return out;
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export function urlsetXml(siteUrl: string, urls: Url[]) {
  const body = urls.map((u) => `<url><loc>${esc(siteUrl + u.loc)}</loc>${u.lastmod ? `<lastmod>${u.lastmod.toISOString()}</lastmod>` : ""}</url>`).join("");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${body}</urlset>`;
}

export function indexXml(siteUrl: string, files: string[]) {
  const now = new Date().toISOString();
  return `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${files.map((f) => `<sitemap><loc>${esc(`${siteUrl}/sitemaps/${f}`)}</loc><lastmod>${now}</lastmod></sitemap>`).join("")}</sitemapindex>`;
}
