/**
 * Index rules (needs doc §5). Pages that fail stay reachable but render
 * `noindex,follow` and are left out of the sitemaps. Thresholds come from
 * Admin > SEO.
 */
import type { IndexOverride } from "@prisma/client";
import type { Settings } from "../settings";

interface Base { hidden: boolean; removedAt?: Date | null; indexOverride?: IndexOverride; adult?: boolean }

function override(x: Base): boolean | null {
  if (x.hidden || x.removedAt || x.adult) return false;
  if (x.indexOverride === "FORCE_INDEX") return true;
  if (x.indexOverride === "FORCE_NOINDEX") return false;
  return null;
}

/** Movies and shows: overview + poster, or one of them plus enough votes. */
export function titleIndexable(x: Base & { overview?: string | null; posterPath?: string | null; voteCount: number }, s: Settings) {
  const o = override(x);
  if (o !== null) return o;
  const hasOverview = !!x.overview && x.overview.trim().length >= 40;
  const hasPoster = !!x.posterPath;
  if (hasOverview && hasPoster) return true;
  return (hasOverview || hasPoster) && x.voteCount >= s.minVotesWithoutFullData;
}

/** An episode gets its own URL when it has content or its show is popular enough. */
export function episodeHasPage(e: { overview?: string | null; stillPath?: string | null }, showPopularity: number, s: Settings) {
  const hasContent = (!!e.overview && e.overview.trim().length >= 20) || !!e.stillPath;
  return hasContent || showPopularity >= s.minShowPopularityForThinEpisodes;
}

export function seasonIndexable(showIndexable: boolean, season: { overview?: string | null; episodeCount: number }, anyEpisodePage: boolean) {
  if (!showIndexable) return false;
  return (!!season.overview && season.overview.trim().length >= 40) || (season.episodeCount > 0 && anyEpisodePage);
}

export function personIndexable(p: Base & { profilePath?: string | null; creditCount: number }, s: Settings) {
  const o = override(p);
  if (o !== null) return o;
  return !!p.profilePath && p.creditCount >= s.minPersonCredits;
}
