/**
 * Trim TMDB responses before storing them as the JSON cache: keep only what
 * pages render, so a movie row is ~10–30 KB instead of ~150 KB.
 */
import type {
  TmdbCollection, TmdbCredits, TmdbEpisode, TmdbListItem, TmdbMovie, TmdbPaged, TmdbPerson, TmdbTv, TmdbWatchProviders,
} from "./types";

/** Watch-provider regions shown on the site (English-speaking markets). */
export const REGIONS = ["US", "GB", "CA", "AU", "NZ", "IE"] as const;
const CREW_JOBS = new Set(["Director", "Screenplay", "Writer", "Novel", "Story", "Creator", "Producer", "Executive Producer", "Original Music Composer", "Director of Photography"]);

export interface Provider { id: number; name: string; logo: string | null }
export interface RegionProviders { link?: string; stream: Provider[]; free: Provider[]; rent: Provider[]; buy: Provider[] }
export interface Card { id: number; title: string; poster: string | null; year: number | null; rating: number }

const yearOf = (d?: string | null) => (d && /^\d{4}/.test(d) ? Number(d.slice(0, 4)) : null);

export function trimProviders(wp?: TmdbWatchProviders): Record<string, RegionProviders> {
  const out: Record<string, RegionProviders> = {};
  for (const r of REGIONS) {
    const p = wp?.results?.[r];
    if (!p) continue;
    const map = (l?: { provider_id: number; provider_name: string; logo_path: string | null; display_priority: number }[]) =>
      (l ?? []).sort((a, b) => a.display_priority - b.display_priority).map((x) => ({ id: x.provider_id, name: x.provider_name, logo: x.logo_path }));
    out[r] = { link: p.link, stream: map(p.flatrate), free: [...map(p.free), ...map(p.ads)], rent: map(p.rent), buy: map(p.buy) };
  }
  return out;
}

/** "US:8"-style keys for every stream/free provider, stored in an indexed column. */
export function providerKeys(p: Record<string, RegionProviders>): string[] {
  const out = new Set<string>();
  for (const [region, r] of Object.entries(p)) for (const x of [...r.stream, ...r.free]) out.add(`${region}:${x.id}`);
  return [...out];
}

export function trimCredits(c?: TmdbCredits, castLimit = 20) {
  return {
    cast: (c?.cast ?? []).slice(0, castLimit).map((p) => ({ id: p.id, name: p.name, character: p.character ?? "", profile: p.profile_path })),
    crew: (c?.crew ?? []).filter((p) => CREW_JOBS.has(p.job)).slice(0, 30).map((p) => ({ id: p.id, name: p.name, job: p.job, profile: p.profile_path })),
  };
}

export function trimCards(list?: TmdbPaged<TmdbListItem>, limit = 12): Card[] {
  return (list?.results ?? []).filter((x) => !x.adult).slice(0, limit).map((x) => ({
    id: x.id, title: x.title ?? x.name ?? "", poster: x.poster_path,
    year: yearOf(x.release_date ?? x.first_air_date), rating: Math.round((x.vote_average ?? 0) * 10) / 10,
  }));
}

export function usCertification(m: TmdbMovie): string | null {
  const us = m.release_dates?.results.find((r) => r.iso_3166_1 === "US");
  const c = us?.release_dates.map((d) => d.certification).find(Boolean);
  return c || null;
}

export function trimMovie(m: TmdbMovie) {
  return {
    tagline: m.tagline || null,
    certification: usCertification(m),
    budget: m.budget || null,
    revenue: m.revenue || null,
    imdbId: m.imdb_id || null,
    genres: m.genres.map((g) => g.name),
    countries: m.production_countries.map((c) => c.iso_3166_1),
    collection: m.belongs_to_collection ? { id: m.belongs_to_collection.id, name: m.belongs_to_collection.name } : null,
    credits: trimCredits(m.credits),
    providers: trimProviders(m["watch/providers"]),
    recommendations: trimCards(m.recommendations),
    similar: trimCards(m.similar),
  };
}

export function trimTv(t: TmdbTv) {
  const us = t.content_ratings?.results.find((r) => r.iso_3166_1 === "US");
  return {
    tagline: t.tagline || null,
    certification: us?.rating || null,
    type: t.type || null,
    inProduction: t.in_production,
    runtimes: t.episode_run_time ?? [],
    genres: t.genres.map((g) => g.name),
    networks: t.networks.map((n) => n.name),
    createdBy: t.created_by.map((p) => ({ id: p.id, name: p.name })),
    lastEpisode: t.last_episode_to_air ? { s: t.last_episode_to_air.season_number, e: t.last_episode_to_air.episode_number, name: t.last_episode_to_air.name, airDate: t.last_episode_to_air.air_date } : null,
    nextEpisode: t.next_episode_to_air ? { s: t.next_episode_to_air.season_number, e: t.next_episode_to_air.episode_number, name: t.next_episode_to_air.name, airDate: t.next_episode_to_air.air_date } : null,
    credits: trimCredits(t.credits),
    providers: trimProviders(t["watch/providers"]),
    recommendations: trimCards(t.recommendations),
  };
}

export function trimEpisode(e: TmdbEpisode) {
  return {
    type: e.episode_type ?? null,
    guests: (e.guest_stars ?? []).slice(0, 15).map((p) => ({ id: p.id, name: p.name, character: p.character ?? "", profile: p.profile_path })),
    crew: (e.crew ?? []).filter((p) => p.job === "Director" || p.department === "Writing").slice(0, 10).map((p) => ({ id: p.id, name: p.name, job: p.job })),
  };
}

export function trimPerson(p: TmdbPerson) {
  const cast = (p.combined_credits?.cast ?? []).filter((c) => !c.adult);
  const crew = (p.combined_credits?.crew ?? []).filter((c) => !c.adult);
  const credit = (c: TmdbListItem, role: string) => ({
    id: c.id, type: c.media_type === "tv" ? "tv" : "movie", title: c.title ?? c.name ?? "", poster: c.poster_path,
    year: yearOf(c.release_date ?? c.first_air_date), rating: Math.round((c.vote_average ?? 0) * 10) / 10,
    votes: c.vote_count ?? 0, popularity: c.popularity ?? 0, role,
  });
  return {
    biography: p.biography || null,
    birthday: p.birthday, deathday: p.deathday, placeOfBirth: p.place_of_birth,
    department: p.known_for_department, imdbId: p.imdb_id || null,
    cast: cast.map((c) => credit(c, c.character ?? "")).slice(0, 400),
    crew: crew.map((c) => credit(c, c.job)).slice(0, 200),
  };
}

export function trimCollection(c: TmdbCollection) {
  const parts = c.parts.filter((p) => !p.adult).map((p) => ({
    id: p.id, title: p.title ?? "", poster: p.poster_path, releaseDate: p.release_date || null,
    year: yearOf(p.release_date), rating: Math.round((p.vote_average ?? 0) * 10) / 10,
  }));
  parts.sort((a, b) => (a.releaseDate ?? "9999").localeCompare(b.releaseDate ?? "9999"));
  return { parts };
}

export const toDate = (d?: string | null) => (d && /^\d{4}-\d{2}-\d{2}$/.test(d) ? new Date(d + "T00:00:00Z") : null);
export { yearOf };
