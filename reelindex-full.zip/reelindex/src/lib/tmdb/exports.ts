import { createGunzip } from "node:zlib";
import { createInterface } from "node:readline";
import { Readable } from "node:stream";
import type { ReadableStream as NodeWebStream } from "node:stream/web";

/**
 * TMDB daily ID exports: one JSON object per line, gzipped, published daily
 * (usually by ~08:00 UTC). They list every valid id with its name and
 * popularity, and are downloaded instead of paging the API.
 */
export type ExportType = "movie" | "tv_series" | "person" | "collection";

export interface ExportRow {
  id: number;
  name: string;
  popularity: number;
  adult: boolean;
  video: boolean;
}

function fileUrl(type: ExportType, d: Date) {
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `https://files.tmdb.org/p/exports/${type}_ids_${mm}_${dd}_${d.getUTCFullYear()}.json.gz`;
}

/** Newest file that exists: today, else yesterday, else the day before. */
async function openExport(type: ExportType): Promise<{ url: string; body: NodeWebStream<Uint8Array> }> {
  for (let back = 0; back < 3; back++) {
    const d = new Date(Date.now() - back * 86_400_000);
    const url = fileUrl(type, d);
    const res = await fetch(url, { signal: AbortSignal.timeout(120_000) });
    if (res.ok && res.body) return { url, body: res.body as unknown as NodeWebStream<Uint8Array> };
  }
  throw new Error(`No TMDB ${type} export found for the last 3 days`);
}

/** Streams rows without loading the whole file into memory. */
export async function* readExport(type: ExportType): AsyncGenerator<ExportRow> {
  const { body } = await openExport(type);
  const lines = createInterface({ input: Readable.fromWeb(body).pipe(createGunzip()), crlfDelay: Infinity });
  for await (const line of lines) {
    if (!line) continue;
    let o: Record<string, unknown>;
    try { o = JSON.parse(line); } catch { continue; }
    const id = Number(o.id);
    if (!Number.isInteger(id)) continue;
    yield {
      id,
      name: String(o.original_title ?? o.original_name ?? o.name ?? ""),
      popularity: Number(o.popularity ?? 0),
      adult: o.adult === true,
      video: o.video === true,
    };
  }
}
