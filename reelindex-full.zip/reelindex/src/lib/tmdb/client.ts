import { redis } from "../redis";
import { getSettings, secrets } from "../settings";

const BASE = "https://api.themoviedb.org/3";

export class TmdbError extends Error {
  constructor(message: string, public status: number) { super(message); }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const today = () => new Date().toISOString().slice(0, 10);

/**
 * Global rate limit shared by every process (worker, web app): a per-second
 * counter in Redis. Keeps total TMDB traffic under the admin-set ceiling.
 */
async function acquireSlot(limitPerSecond: number) {
  const r = redis();
  for (;;) {
    const sec = Math.floor(Date.now() / 1000);
    const key = `tmdb:rl:${sec}`;
    const n = await r.incr(key);
    if (n === 1) await r.expire(key, 3);
    if (n <= limitPerSecond) return;
    await sleep(1000 - (Date.now() % 1000) + Math.floor(Math.random() * 40));
  }
}

async function countCall(kind: "calls" | "429") {
  const key = `tmdb:${kind}:${today()}`;
  const r = redis();
  await r.incr(key);
  await r.expire(key, 60 * 60 * 24 * 40);
}

type Params = Record<string, string | number | boolean | undefined>;

/**
 * GET a TMDB v3 endpoint. Returns null on 404 (deleted or unknown id).
 * Retries 429 (honouring Retry-After), 5xx and network errors with backoff.
 */
export async function tmdb<T>(path: string, params: Params = {}, opts: { retries?: number } = {}): Promise<T | null> {
  const { tmdbToken } = await secrets();
  if (!tmdbToken) throw new TmdbError("TMDB token is not set (Admin > Site settings or TMDB_TOKEN)", 0);
  const { tmdbRatePerSecond } = await getSettings();

  const url = new URL(BASE + path);
  if (!("language" in params)) url.searchParams.set("language", "en-US");
  for (const [k, v] of Object.entries(params)) if (v !== undefined) url.searchParams.set(k, String(v));

  const retries = opts.retries ?? 5;
  let lastErr: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    await acquireSlot(tmdbRatePerSecond);
    await countCall("calls");
    try {
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${tmdbToken}`, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      });
      if (res.status === 404) return null;
      if (res.status === 429) {
        await countCall("429");
        const ra = Number(res.headers.get("retry-after"));
        await sleep((Number.isFinite(ra) && ra > 0 ? ra * 1000 : 1000 * 2 ** attempt) + Math.random() * 250);
        continue;
      }
      if (res.status >= 500) { lastErr = new TmdbError(`TMDB ${res.status} on ${path}`, res.status); await sleep(1000 * 2 ** attempt); continue; }
      if (!res.ok) throw new TmdbError(`TMDB ${res.status} on ${path}: ${(await res.text()).slice(0, 200)}`, res.status);
      return (await res.json()) as T;
    } catch (err) {
      if (err instanceof TmdbError && err.status >= 400 && err.status < 500) throw err;
      lastErr = err;
      await sleep(1000 * 2 ** attempt);
    }
  }
  throw lastErr instanceof Error ? lastErr : new TmdbError(`TMDB request failed: ${path}`, 0);
}

export async function apiCallStats(day = today()) {
  const r = redis();
  const [calls, limited] = await r.mget(`tmdb:calls:${day}`, `tmdb:429:${day}`);
  return { calls: Number(calls || 0), rateLimited: Number(limited || 0) };
}
