/** The subset of TMDB v3 response fields the site uses. */

export interface TmdbGenre { id: number; name: string }
export interface TmdbCountry { iso_3166_1: string; name: string }
export interface TmdbCast { id: number; name: string; character?: string; profile_path: string | null; order?: number; known_for_department?: string }
export interface TmdbCrew { id: number; name: string; job: string; department: string; profile_path: string | null }
export interface TmdbCredits { cast?: TmdbCast[]; crew?: TmdbCrew[]; guest_stars?: TmdbCast[] }
export interface TmdbProvider { provider_id: number; provider_name: string; logo_path: string | null; display_priority: number }
export interface TmdbRegionProviders { link?: string; flatrate?: TmdbProvider[]; free?: TmdbProvider[]; ads?: TmdbProvider[]; rent?: TmdbProvider[]; buy?: TmdbProvider[] }
export interface TmdbWatchProviders { results?: Record<string, TmdbRegionProviders> }
export interface TmdbListItem {
  id: number; title?: string; name?: string; poster_path: string | null; release_date?: string; first_air_date?: string;
  vote_average?: number; vote_count?: number; popularity?: number; adult?: boolean; media_type?: string; genre_ids?: number[];
}
export interface TmdbPaged<T> { page: number; results: T[]; total_pages: number; total_results: number }

export interface TmdbMovie {
  id: number; title: string; original_title: string; overview: string; tagline?: string;
  release_date: string; runtime: number | null; status: string; adult: boolean; original_language: string;
  genres: TmdbGenre[]; production_countries: TmdbCountry[]; origin_country?: string[];
  vote_average: number; vote_count: number; popularity: number;
  poster_path: string | null; backdrop_path: string | null;
  budget: number; revenue: number; imdb_id?: string | null;
  belongs_to_collection: { id: number; name: string; poster_path: string | null; backdrop_path: string | null } | null;
  credits?: TmdbCredits;
  "watch/providers"?: TmdbWatchProviders;
  recommendations?: TmdbPaged<TmdbListItem>;
  similar?: TmdbPaged<TmdbListItem>;
  release_dates?: { results: { iso_3166_1: string; release_dates: { certification: string; type: number; release_date: string }[] }[] };
}

export interface TmdbSeasonSummary {
  id: number; season_number: number; name: string; overview: string; episode_count: number;
  air_date: string | null; poster_path: string | null; vote_average?: number;
}
export interface TmdbEpisodeSummary {
  id: number; name: string; season_number: number; episode_number: number; air_date: string | null; runtime?: number | null;
}
export interface TmdbTv {
  id: number; name: string; original_name: string; overview: string; tagline?: string;
  first_air_date: string; last_air_date: string | null; status: string; type?: string; adult?: boolean;
  in_production: boolean; original_language: string; origin_country: string[];
  number_of_seasons: number; number_of_episodes: number; episode_run_time?: number[];
  genres: TmdbGenre[]; networks: { id: number; name: string }[];
  created_by: { id: number; name: string; profile_path: string | null }[];
  vote_average: number; vote_count: number; popularity: number;
  poster_path: string | null; backdrop_path: string | null;
  last_episode_to_air: TmdbEpisodeSummary | null; next_episode_to_air: TmdbEpisodeSummary | null;
  seasons: TmdbSeasonSummary[];
  credits?: TmdbCredits;
  "watch/providers"?: TmdbWatchProviders;
  recommendations?: TmdbPaged<TmdbListItem>;
  content_ratings?: { results: { iso_3166_1: string; rating: string }[] };
}

export interface TmdbEpisode {
  id: number; name: string; overview: string; season_number: number; episode_number: number;
  air_date: string | null; runtime: number | null; still_path: string | null;
  vote_average: number; vote_count: number; episode_type?: string;
  crew?: TmdbCrew[]; guest_stars?: TmdbCast[];
}
export interface TmdbSeason {
  id: number; _id?: string; name: string; overview: string; season_number: number;
  air_date: string | null; poster_path: string | null; episodes: TmdbEpisode[];
}

export interface TmdbPerson {
  id: number; name: string; biography: string; birthday: string | null; deathday: string | null;
  place_of_birth: string | null; known_for_department: string; profile_path: string | null;
  popularity: number; adult: boolean; also_known_as?: string[]; imdb_id?: string | null;
  combined_credits?: { cast: (TmdbListItem & { character?: string; episode_count?: number })[]; crew: (TmdbListItem & { job: string; department: string })[] };
}

export interface TmdbCollection {
  id: number; name: string; overview: string; poster_path: string | null; backdrop_path: string | null;
  parts: TmdbListItem[];
}

export interface TmdbChange { id: number; adult: boolean | null }
