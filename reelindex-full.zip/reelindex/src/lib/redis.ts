import { Redis } from "ioredis";
import { env } from "./env";

const g = globalThis as unknown as { __redis?: Redis };

/** Shared connection for counters, rate limiting and run bookkeeping. */
export function redis(): Redis {
  if (!g.__redis) g.__redis = new Redis(env.redisUrl, { maxRetriesPerRequest: null, lazyConnect: false });
  return g.__redis;
}

/** BullMQ needs its own connections (blocking commands). */
export function newRedisConnection(): Redis {
  return new Redis(env.redisUrl, { maxRetriesPerRequest: null });
}
