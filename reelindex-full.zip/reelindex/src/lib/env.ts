function req(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing environment variable ${name}. Copy .env.example to .env and fill it in.`);
  return v;
}

export const env = {
  get databaseUrl() { return req("DATABASE_URL"); },
  get redisUrl() { return process.env.REDIS_URL || "redis://localhost:6379"; },
  get tmdbToken() { return process.env.TMDB_TOKEN || ""; },
  get siteUrl() { return (process.env.SITE_URL || "https://www.example.com").replace(/\/$/, ""); },
  get appInternalUrl() { return (process.env.APP_INTERNAL_URL || "http://127.0.0.1:3000").replace(/\/$/, ""); },
  get revalidateSecret() { return process.env.REVALIDATE_SECRET || ""; },
  get telegramBotToken() { return process.env.TELEGRAM_BOT_TOKEN || ""; },
  get telegramChatId() { return process.env.TELEGRAM_CHAT_ID || ""; },
  get cloudflareToken() { return process.env.CLOUDFLARE_API_TOKEN || ""; },
  get cloudflareZone() { return process.env.CLOUDFLARE_ZONE_ID || ""; },
  get indexNowKey() { return process.env.INDEXNOW_KEY || ""; },
};
