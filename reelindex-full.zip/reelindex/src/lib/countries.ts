import { slugify } from "./slug";

const names = new Intl.DisplayNames(["en"], { type: "region" });

/** Adjectives for page titles ("Korean TV Shows"); other countries use "TV Shows from X". */
const DEMONYM: Record<string, string> = {
  US: "American", GB: "British", KR: "Korean", JP: "Japanese", FR: "French", DE: "German", IN: "Indian", CN: "Chinese",
  ES: "Spanish", IT: "Italian", CA: "Canadian", AU: "Australian", MX: "Mexican", BR: "Brazilian", TR: "Turkish",
  TW: "Taiwanese", TH: "Thai", PH: "Filipino", ID: "Indonesian", RU: "Russian", SE: "Swedish", DK: "Danish",
  NO: "Norwegian", FI: "Finnish", NL: "Dutch", BE: "Belgian", PL: "Polish", IE: "Irish", AR: "Argentine",
  CO: "Colombian", CL: "Chilean", EG: "Egyptian", NG: "Nigerian", IL: "Israeli", IR: "Iranian", AT: "Austrian",
  CH: "Swiss", PT: "Portuguese", GR: "Greek", CZ: "Czech", HU: "Hungarian", UA: "Ukrainian", VN: "Vietnamese", MY: "Malaysian",
};

export const countryName = (code: string) => {
  try { return names.of(code.toUpperCase()) ?? code; } catch { return code; }
};

let bySlug: Map<string, string> | null = null;
/** "south-korea" → "KR". Built once from every two-letter code Intl knows. */
export function codeFromSlug(slug: string): string | null {
  if (!bySlug) {
    bySlug = new Map();
    for (let a = 65; a <= 90; a++) for (let b = 65; b <= 90; b++) {
      const code = String.fromCharCode(a, b);
      const n = countryName(code);
      if (n && n !== code) bySlug.set(slugify(n), code);
    }
  }
  return bySlug.get(slug) ?? null;
}

export const countrySlug = (code: string) => slugify(countryName(code));

export function countryTitle(code: string, kind: "movies" | "tv") {
  const d = DEMONYM[code];
  if (kind === "tv") return code === "KR" ? "Korean TV Shows & K-Dramas" : d ? `${d} TV Shows` : `TV Shows from ${countryName(code)}`;
  return d ? `${d} Movies` : `Movies from ${countryName(code)}`;
}
