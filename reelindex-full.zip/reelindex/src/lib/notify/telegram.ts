import { prisma } from "../db";
import { getSettings, secrets } from "../settings";

export type AlertEvent = keyof Awaited<ReturnType<typeof getSettings>>["telegramEvents"];

const LEVEL: Record<string, string> = { dailySummary: "info", loginSuccess: "info", syncFailed: "error", sitemapFailed: "error", loginLocked: "warn", rateLimited: "warn", staleData: "warn", crawlerSpike: "warn" };

/**
 * Records the alert (shown on the admin dashboard) and sends it to Telegram if
 * that event is switched on in Admin > Settings. Never throws.
 */
export async function notify(event: AlertEvent, html: string): Promise<boolean> {
  const sent = await send(event, html);
  await prisma.alertLog.create({ data: { level: LEVEL[event] ?? "info", event, text: html.replace(/<[^>]+>/g, "").slice(0, 1000), sent } }).catch(() => {});
  return sent;
}

/** Telegram only, no logging (used by the admin's test button). */
export async function send(event: AlertEvent | "test", html: string): Promise<boolean> {
  try {
    const s = await getSettings(0);
    if (event !== "test" && !s.telegramEvents[event]) return false;
    const { telegramBotToken, telegramChatId } = await secrets();
    if (!telegramBotToken || !telegramChatId) return false;
    const res = await fetch(`https://api.telegram.org/bot${telegramBotToken}/sendMessage`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ chat_id: telegramChatId, text: `<b>${s.siteName}</b>\n${html}`, parse_mode: "HTML", disable_web_page_preview: true }),
      signal: AbortSignal.timeout(10_000),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export const esc = (s: string) => s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]!);
