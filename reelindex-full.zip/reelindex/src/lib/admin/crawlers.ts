import { open, stat } from "node:fs/promises";

/**
 * Crawler requests that reached the server today, read from the tail of the
 * Nginx access log (combined format). Requests Cloudflare served from its
 * cache never reach Nginx, so these are the ones that cost server time.
 */
const BOTS: [string, RegExp, "allowed" | "blocked"][] = [
  ["Googlebot", /Googlebot/i, "allowed"], ["Bingbot", /bingbot/i, "allowed"], ["YandexBot", /YandexBot/i, "allowed"],
  ["DuckDuckBot", /DuckDuckBot/i, "allowed"], ["Applebot", /Applebot/i, "allowed"], ["Baiduspider", /Baiduspider/i, "allowed"],
  ["AhrefsBot", /AhrefsBot/i, "blocked"], ["SemrushBot", /SemrushBot/i, "blocked"], ["MJ12bot", /MJ12bot/i, "blocked"],
  ["DotBot", /DotBot/i, "blocked"], ["PetalBot", /PetalBot/i, "blocked"], ["Bytespider", /Bytespider/i, "blocked"],
  ["GPTBot", /GPTBot/i, "blocked"], ["ClaudeBot", /ClaudeBot/i, "blocked"], ["CCBot", /CCBot/i, "blocked"], ["Amazonbot", /Amazonbot/i, "blocked"],
];

export interface CrawlerRow { name: string; policy: "allowed" | "blocked" | "other"; requests: number; errors: number }

export async function crawlerStats(logPath: string, maxBytes = 64 * 1024 * 1024): Promise<{ rows: CrawlerRow[]; total: number; error?: string }> {
  let text: string;
  try {
    const st = await stat(logPath);
    const fh = await open(logPath, "r");
    const len = Math.min(st.size, maxBytes);
    const buf = Buffer.alloc(len);
    await fh.read(buf, 0, len, st.size - len);
    await fh.close();
    text = buf.toString("utf8");
  } catch (err) {
    return { rows: [], total: 0, error: `无法读取 ${logPath}：${err instanceof Error ? err.message : String(err)}` };
  }
  // Nginx default time format: [11/Oct/2026:03:30:02 +0000]
  const d = new Date();
  const today = `${String(d.getUTCDate()).padStart(2, "0")}/${d.toLocaleString("en-US", { month: "short", timeZone: "UTC" })}/${d.getUTCFullYear()}`;
  const counts = new Map<string, CrawlerRow>();
  let total = 0;
  for (const line of text.split("\n")) {
    if (!line.includes(`[${today}:`)) continue;
    total++;
    const ua = /"([^"]*)"\s*$/.exec(line)?.[1] ?? "";
    const status = Number(/"\s(\d{3})\s/.exec(line)?.[1] ?? 0);
    let hit = BOTS.find(([, re]) => re.test(ua));
    let name: string, policy: CrawlerRow["policy"];
    if (hit) { name = hit[0]; policy = hit[2]; }
    else if (/bot|crawl|spider|slurp/i.test(ua)) { name = "Other bots"; policy = "other"; }
    else continue;
    const r = counts.get(name) ?? { name, policy, requests: 0, errors: 0 };
    r.requests++;
    if (status >= 500 || status === 429) r.errors++;
    counts.set(name, r);
    hit = undefined;
  }
  return { rows: [...counts.values()].sort((a, b) => b.requests - a.requests), total };
}
