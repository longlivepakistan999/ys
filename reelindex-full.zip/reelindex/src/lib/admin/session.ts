/**
 * Signed admin session cookie. Uses Web Crypto only, so the same code runs in
 * the middleware (edge) and in server actions (Node).
 * Format: base64url(JSON{u,exp,v}).base64url(HMAC-SHA256)
 */
export const COOKIE = "ri_admin";
export const SESSION_DAYS = 7;

const enc = new TextEncoder();
const b64url = (buf: ArrayBuffer | Uint8Array) => {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
const fromB64url = (s: string) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4)), (c) => c.charCodeAt(0));

function secret() {
  const s = process.env.ADMIN_SESSION_SECRET;
  if (!s || s.length < 32) throw new Error("ADMIN_SESSION_SECRET must be set (32+ characters)");
  return s;
}

async function key() {
  return crypto.subtle.importKey("raw", enc.encode(secret()), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

export interface Session { u: string; exp: number; v: number }

/** `v` is the account's session version: changing the password bumps it and logs out every device. */
export async function signSession(username: string, version: number): Promise<string> {
  const payload: Session = { u: username, exp: Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400, v: version };
  const body = b64url(enc.encode(JSON.stringify(payload)));
  const sig = await crypto.subtle.sign("HMAC", await key(), enc.encode(body));
  return `${body}.${b64url(sig)}`;
}

export async function verifySession(token: string | undefined | null): Promise<Session | null> {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  try {
    const ok = await crypto.subtle.verify("HMAC", await key(), fromB64url(sig), enc.encode(body));
    if (!ok) return null;
    const s = JSON.parse(new TextDecoder().decode(fromB64url(body))) as Session;
    if (!s.u || s.exp < Date.now() / 1000) return null;
    return s;
  } catch {
    return null;
  }
}

/** Public admin URL prefix (ADMIN_PATH env, default "admin"); internally the routes live under /admin. */
export const adminBase = () => `/${(process.env.ADMIN_PATH || "admin").replace(/^\/+|\/+$/g, "")}`;
