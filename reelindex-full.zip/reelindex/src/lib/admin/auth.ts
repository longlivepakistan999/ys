import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "../db";
import { getAccount, type AdminAccount } from "./account";
export { getAccount, saveAccount, type AdminAccount } from "./account";
import { adminBase, COOKIE, verifySession } from "./session";

export async function clientIp(): Promise<string> {
  const h = await headers();
  return h.get("cf-connecting-ip") || h.get("x-real-ip") || h.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
}

/** Server-side guard for every admin page and action (the middleware checks too). */
export async function requireAdmin(): Promise<AdminAccount> {
  const jar = await cookies();
  const s = await verifySession(jar.get(COOKIE)?.value);
  const acc = await getAccount();
  if (!s || !acc || s.u !== acc.username || s.v !== acc.sessionVersion) redirect(`${adminBase()}/login`);
  return acc;
}

export async function logAction(action: string) {
  await prisma.adminLog.create({ data: { action: action.slice(0, 300), ip: await clientIp() } }).catch(() => {});
}
