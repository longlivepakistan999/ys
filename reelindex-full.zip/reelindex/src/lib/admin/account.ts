import { prisma } from "../db";

/** The single admin account, stored outside the general settings. */
export interface AdminAccount {
  username: string;
  passwordHash: string;
  totpSecret: string | null;
  totpEnabled: boolean;
  /** Bumped on password change: invalidates every existing session */
  sessionVersion: number;
  pendingTotpSecret?: string | null;
}

const KEY = "adminAccount";

export async function getAccount(): Promise<AdminAccount | null> {
  const row = await prisma.setting.findUnique({ where: { key: KEY } });
  return (row?.value as unknown as AdminAccount) ?? null;
}

export async function saveAccount(a: AdminAccount) {
  await prisma.setting.upsert({ where: { key: KEY }, create: { key: KEY, value: a as never }, update: { value: a as never } });
}
