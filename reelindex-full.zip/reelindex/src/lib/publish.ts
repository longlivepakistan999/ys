/**
 * After data changes: refresh the Next.js page cache, purge Cloudflare's copy,
 * and tell search engines through IndexNow.
 */
import { env } from "./env";
import { secrets } from "./settings";

const chunk = <T,>(a: T[], n: number) => Array.from({ length: Math.ceil(a.length / n) }, (_, i) => a.slice(i * n, i * n + n));
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Asks the running Next.js app to regenerate these paths on next request. */
export async function revalidatePaths(paths: string[]): Promise<number> {
  if (!paths.length || !env.revalidateSecret) return 0;
  let done = 0;
  for (const part of chunk(paths, 500)) {
    try {
      const res = await fetch(`${env.appInternalUrl}/api/revalidate`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-revalidate-secret": env.revalidateSecret },
        body: JSON.stringify({ paths: part }),
        signal: AbortSignal.timeout(30_000),
      });
      if (res.ok) done += part.length;
    } catch { /* app not running: pages expire on their own TTL */ }
  }
  return done;
}

/** Cloudflare accepts 30 URLs per purge call on non-Enterprise plans. */
export async function purgeCloudflare(paths: string[]): Promise<number> {
  const { cloudflareToken, cloudflareZone, siteUrl } = await secrets();
  if (!paths.length || !cloudflareToken || !cloudflareZone) return 0;
  let done = 0;
  for (const part of chunk(paths, 30)) {
    try {
      const res = await fetch(`https://api.cloudflare.com/client/v4/zones/${cloudflareZone}/purge_cache`, {
        method: "POST",
        headers: { Authorization: `Bearer ${cloudflareToken}`, "content-type": "application/json" },
        body: JSON.stringify({ files: part.map((p) => siteUrl + p) }),
        signal: AbortSignal.timeout(15_000),
      });
      if (res.ok) done += part.length;
    } catch { /* ignore; edge TTL will expire */ }
    await sleep(250);
  }
  return done;
}

export async function purgeCloudflareAll(): Promise<boolean> {
  const { cloudflareToken, cloudflareZone } = await secrets();
  if (!cloudflareToken || !cloudflareZone) return false;
  const res = await fetch(`https://api.cloudflare.com/client/v4/zones/${cloudflareZone}/purge_cache`, {
    method: "POST",
    headers: { Authorization: `Bearer ${cloudflareToken}`, "content-type": "application/json" },
    body: JSON.stringify({ purge_everything: true }),
  });
  return res.ok;
}

/** IndexNow (Bing, Yandex, Seznam, Naver…). Up to 10,000 URLs per call. Key file is served at /indexnow-key.txt. */
export async function pushIndexNow(paths: string[]): Promise<number> {
  const { indexNowKey, siteUrl } = await secrets();
  if (!paths.length || !indexNowKey) return 0;
  const host = new URL(siteUrl).host;
  let done = 0;
  for (const part of chunk(paths, 10_000)) {
    try {
      const res = await fetch("https://api.indexnow.org/IndexNow", {
        method: "POST",
        headers: { "content-type": "application/json; charset=utf-8" },
        body: JSON.stringify({ host, key: indexNowKey, keyLocation: `${siteUrl}/indexnow-key.txt`, urlList: part.map((p) => siteUrl + p) }),
        signal: AbortSignal.timeout(30_000),
      });
      if (res.ok || res.status === 202) done += part.length;
    } catch { /* retried next run */ }
  }
  return done;
}
