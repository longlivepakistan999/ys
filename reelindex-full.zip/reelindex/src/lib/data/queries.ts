import type { Prisma } from "@prisma/client";
import { prisma } from "../db";
import { paths } from "../slug";
import { getSettings } from "../settings";

/** Public rows only: not removed, not hidden, not adult. Lists also require a poster. */
const LIVE = { removedAt: null, hidden: false, adult: false } as const;

export interface CardItem { key: string; href: string; title: string; poster: string | null; year: string; rating: number | null; meta?: string }
export type Sort = "popular" | "rating" | "newest" | "title";
export interface ListFilter { genreId?: number; year?: number; country?: string; provider?: string; minRating?: number; minVotes?: number }

export const movieHref = (m: { id: number; slug: string; year: number | null }) => paths.movie(m.id, m.slug, m.year);
export const tvHref = (t: { id: number; slug: string }) => paths.tv(t.id, t.slug);

const movieCard = { id: true, title: true, slug: true, year: true, rating: true, posterPath: true } as const;
const tvCard = { id: true, name: true, slug: true, firstAirYear: true, lastAirDate: true, status: true, rating: true, posterPath: true } as const;

export function toMovieCard(m: { id: number; title: string; slug: string; year: number | null; rating: number; posterPath: string | null }, meta?: string): CardItem {
  return { key: `m${m.id}`, href: movieHref(m), title: m.title, poster: m.posterPath, year: m.year ? String(m.year) : "", rating: m.rating || null, meta };
}
export function toTvCard(t: { id: number; name: string; slug: string; firstAirYear: number | null; lastAirDate?: Date | null; status?: string | null; rating: number; posterPath: string | null }, meta?: string): CardItem {
  const end = t.status === "Ended" || t.status === "Canceled" ? t.lastAirDate?.getUTCFullYear() : null;
  const years = t.firstAirYear ? (end && end !== t.firstAirYear ? `${t.firstAirYear}–${end}` : end ? `${t.firstAirYear}` : `${t.firstAirYear}–`) : "";
  return { key: `t${t.id}`, href: tvHref(t), title: t.name, poster: t.posterPath, year: years, rating: t.rating || null, meta };
}

function movieWhere(f: ListFilter): Prisma.MovieWhereInput {
  return {
    ...LIVE, posterPath: { not: null },
    ...(f.genreId ? { genres: { has: f.genreId } } : {}),
    ...(f.year ? { year: f.year } : {}),
    ...(f.country ? { countries: { has: f.country } } : {}),
    ...(f.provider ? { providers: { has: f.provider } } : {}),
    ...(f.minRating ? { rating: { gte: f.minRating } } : {}),
    ...(f.minVotes ? { voteCount: { gte: f.minVotes } } : {}),
  };
}
function tvWhere(f: ListFilter): Prisma.TvShowWhereInput {
  return {
    ...LIVE, posterPath: { not: null },
    ...(f.genreId ? { genres: { has: f.genreId } } : {}),
    ...(f.year ? { firstAirYear: f.year } : {}),
    ...(f.country ? { countries: { has: f.country } } : {}),
    ...(f.provider ? { providers: { has: f.provider } } : {}),
    ...(f.minRating ? { rating: { gte: f.minRating } } : {}),
    ...(f.minVotes ? { voteCount: { gte: f.minVotes } } : {}),
  };
}
const movieOrder = (s: Sort): Prisma.MovieOrderByWithRelationInput[] =>
  s === "rating" ? [{ rating: "desc" }, { voteCount: "desc" }] : s === "newest" ? [{ releaseDate: { sort: "desc", nulls: "last" } }] : s === "title" ? [{ title: "asc" }] : [{ popularity: "desc" }];
const tvOrder = (s: Sort): Prisma.TvShowOrderByWithRelationInput[] =>
  s === "rating" ? [{ rating: "desc" }, { voteCount: "desc" }] : s === "newest" ? [{ firstAirDate: { sort: "desc", nulls: "last" } }] : s === "title" ? [{ name: "asc" }] : [{ popularity: "desc" }];

export async function listMovies(f: ListFilter, sort: Sort, page: number, perPage?: number) {
  const pp = perPage ?? (await getSettings()).perPage;
  const where = movieWhere(f);
  const [rows, total] = await Promise.all([
    prisma.movie.findMany({ where, orderBy: movieOrder(sort), skip: (page - 1) * pp, take: pp, select: { ...movieCard, voteCount: true } }),
    prisma.movie.count({ where }),
  ]);
  return { rows, items: rows.map((r) => toMovieCard(r)), total, perPage: pp, pages: Math.max(1, Math.ceil(total / pp)) };
}

export async function listTv(f: ListFilter, sort: Sort, page: number, perPage?: number) {
  const pp = perPage ?? (await getSettings()).perPage;
  const where = tvWhere(f);
  const [rows, total] = await Promise.all([
    prisma.tvShow.findMany({ where, orderBy: tvOrder(sort), skip: (page - 1) * pp, take: pp, select: { ...tvCard, voteCount: true } }),
    prisma.tvShow.count({ where }),
  ]);
  return { rows, items: rows.map((r) => toTvCard(r)), total, perPage: pp, pages: Math.max(1, Math.ceil(total / pp)) };
}

/** Home blocks: admin pins first, then the automatic rule fills the rest. */
export async function homeBlock(kind: "movies" | "tv") {
  const s = await getSettings();
  const pins = await prisma.homepagePin.findMany({ where: { block: kind }, orderBy: { position: "asc" } });
  const pinIds = pins.map((p) => p.tmdbId);
  const rule = kind === "movies" ? s.homeMoviesRule : s.homeTvRule;
  const since = new Date(Date.now() - (rule === "trending" ? 30 : 365) * 86_400_000);
  if (kind === "movies") {
    const pinned = await prisma.movie.findMany({ where: { id: { in: pinIds }, ...LIVE }, select: movieCard });
    const auto = await prisma.movie.findMany({
      where: { ...LIVE, posterPath: { not: null }, isIndexable: true, id: { notIn: pinIds },
        ...(rule !== "popular" ? { releaseDate: { gte: since, lte: new Date() } } : {}), ...(rule === "recent_good" ? { rating: { gte: 7 }, voteCount: { gte: 100 } } : {}) },
      orderBy: { popularity: "desc" }, take: Math.max(0, s.homeCount - pinned.length), select: movieCard,
    });
    const order = new Map(pinIds.map((id, i) => [id, i]));
    return [...pinned.sort((a, b) => order.get(a.id)! - order.get(b.id)!), ...auto].map((m) => toMovieCard(m));
  }
  const pinned = await prisma.tvShow.findMany({ where: { id: { in: pinIds }, ...LIVE }, select: tvCard });
  const auto = await prisma.tvShow.findMany({
    where: { ...LIVE, posterPath: { not: null }, isIndexable: true, id: { notIn: pinIds },
      ...(rule !== "popular" ? { lastEpisodeAirDate: { gte: since } } : {}), ...(rule === "recent_good" ? { rating: { gte: 7 }, voteCount: { gte: 50 } } : {}) },
    orderBy: { popularity: "desc" }, take: Math.max(0, s.homeCount - pinned.length), select: tvCard,
  });
  const order = new Map(pinIds.map((id, i) => [id, i]));
  return [...pinned.sort((a, b) => order.get(a.id)! - order.get(b.id)!), ...auto].map((t) => toTvCard(t));
}

export async function upcomingMovies(year: number, month: number) {
  const from = new Date(Date.UTC(year, month - 1, 1));
  const to = new Date(Date.UTC(year, month, 0));
  return prisma.movie.findMany({
    where: { ...LIVE, releaseDate: { gte: from, lte: to }, posterPath: { not: null } },
    orderBy: [{ releaseDate: "asc" }, { popularity: "desc" }], take: 300,
    select: { ...movieCard, releaseDate: true, genres: true },
  });
}

/** Title counts per origin country (cached with the page that uses it). */
export async function countryCounts() {
  const [m, t] = await Promise.all([
    prisma.$queryRawUnsafe<{ c: string; n: bigint }[]>(`SELECT unnest(countries) AS c, count(*)::bigint AS n FROM "Movie" WHERE "removedAt" IS NULL AND NOT hidden GROUP BY 1`),
    prisma.$queryRawUnsafe<{ c: string; n: bigint }[]>(`SELECT unnest(countries) AS c, count(*)::bigint AS n FROM "TvShow" WHERE "removedAt" IS NULL AND NOT hidden GROUP BY 1`),
  ]);
  const out = new Map<string, { movies: number; tv: number }>();
  for (const r of m) out.set(r.c, { movies: Number(r.n), tv: 0 });
  for (const r of t) out.set(r.c, { movies: out.get(r.c)?.movies ?? 0, tv: Number(r.n) });
  return out;
}

export async function search(q: string) {
  const term = q.trim().slice(0, 100);
  if (term.length < 2) return { movies: [], tv: [], people: [] };
  const [movies, tv, people] = await Promise.all([
    prisma.movie.findMany({ where: { ...LIVE, OR: [{ title: { contains: term, mode: "insensitive" } }, { originalTitle: { contains: term, mode: "insensitive" } }] }, orderBy: { popularity: "desc" }, take: 20, select: { ...movieCard, genres: true } }),
    prisma.tvShow.findMany({ where: { ...LIVE, OR: [{ name: { contains: term, mode: "insensitive" } }, { originalName: { contains: term, mode: "insensitive" } }] }, orderBy: { popularity: "desc" }, take: 20, select: { ...tvCard, numberOfSeasons: true, genres: true } }),
    prisma.person.findMany({ where: { removedAt: null, hidden: false, adult: false, name: { contains: term, mode: "insensitive" } }, orderBy: { popularity: "desc" }, take: 10, select: { id: true, name: true, slug: true, profilePath: true, knownFor: true } }),
  ]);
  return { movies, tv, people };
}

export async function logSearch(q: string) {
  const term = q.trim().toLowerCase().slice(0, 100);
  if (term.length < 2) return;
  const day = new Date(new Date().toISOString().slice(0, 10) + "T00:00:00Z");
  await prisma.searchTerm.upsert({ where: { term_day: { term, day } }, create: { term, day, count: 1 }, update: { count: { increment: 1 } } }).catch(() => {});
}

/** id → slug lookups so internal links point straight at canonical URLs (no redirect hop). */
export async function movieLinks(ids: number[]) {
  if (!ids.length) return new Map<number, string>();
  const rows = await prisma.movie.findMany({ where: { id: { in: ids } }, select: { id: true, slug: true, year: true } });
  return new Map(rows.map((r) => [r.id, movieHref(r)]));
}
export async function tvLinks(ids: number[]) {
  if (!ids.length) return new Map<number, string>();
  const rows = await prisma.tvShow.findMany({ where: { id: { in: ids } }, select: { id: true, slug: true } });
  return new Map(rows.map((r) => [r.id, tvHref(r)]));
}
export async function personLinks(ids: number[]) {
  if (!ids.length) return new Map<number, string>();
  const rows = await prisma.person.findMany({ where: { id: { in: ids } }, select: { id: true, slug: true } });
  return new Map(rows.map((r) => [r.id, paths.person(r.id, r.slug)]));
}

/** Manual and rule-based redirects from Admin > SEO, checked before a 404. */
export async function findRedirect(path: string) {
  return prisma.redirect.findUnique({ where: { oldPath: path } });
}
