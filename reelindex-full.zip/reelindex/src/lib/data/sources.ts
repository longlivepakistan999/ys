import { prisma } from "../db";
import type { PlayableSource } from "@/components/Player";

/** Enabled sources for a movie or an episode (TMDB ids), best first. */
export async function videoSources(mediaType: "movie" | "episode", tmdbId: number): Promise<PlayableSource[]> {
  const rows = await prisma.videoSource.findMany({
    where: { mediaType, tmdbId, enabled: true }, orderBy: [{ priority: "asc" }, { id: "asc" }],
    select: { id: true, kind: true, url: true, label: true },
  });
  return rows.filter((r) => r.kind === "hls" || r.kind === "mp4" || r.kind === "iframe") as PlayableSource[];
}

export async function hasVideo(mediaType: "movie" | "episode", tmdbId: number) {
  return (await prisma.videoSource.count({ where: { mediaType, tmdbId, enabled: true } })) > 0;
}

/** Episode ids (of one season) that have something to play. */
export async function episodesWithVideo(ids: number[]) {
  if (!ids.length) return new Set<number>();
  const rows = await prisma.videoSource.findMany({ where: { mediaType: "episode", tmdbId: { in: ids }, enabled: true }, select: { tmdbId: true }, distinct: ["tmdbId"] });
  return new Set(rows.map((r) => r.tmdbId));
}
