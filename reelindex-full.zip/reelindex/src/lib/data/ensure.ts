/**
 * On-demand details for pages: a title that is in the database (from the ID
 * export) but not cached yet is fetched once, on its first visit. A Redis lock
 * stops a burst of crawler hits from fetching the same title many times.
 */
import { prisma } from "../db";
import { redis } from "../redis";
import { refreshMovie } from "@/sync/refresh/movie";
import { refreshTv } from "@/sync/refresh/tv";
import { refreshCollection, refreshPerson } from "@/sync/refresh/other";

type Kind = "movie" | "tv" | "person" | "collection";
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function cached(kind: Kind, id: number): Promise<boolean> {
  const where = { id };
  const sel = { select: { detailSyncedAt: true } };
  const row =
    kind === "movie" ? await prisma.movie.findUnique({ where, ...sel })
    : kind === "tv" ? await prisma.tvShow.findUnique({ where, ...sel })
    : kind === "person" ? await prisma.person.findUnique({ where, ...sel })
    : await prisma.collection.findUnique({ where, ...sel });
  return !!row?.detailSyncedAt;
}

export async function ensureDetail(kind: Kind, id: number): Promise<void> {
  if (await cached(kind, id)) return;
  const lock = `lazy:${kind}:${id}`;
  const got = await redis().set(lock, "1", "EX", 30, "NX");
  if (!got) {
    // Another request is fetching it; wait briefly for that to finish.
    for (let i = 0; i < 20 && !(await cached(kind, id)); i++) await sleep(250);
    return;
  }
  try {
    if (kind === "movie") await refreshMovie(id);
    else if (kind === "tv") await refreshTv(id);
    else if (kind === "person") await refreshPerson(id);
    else await refreshCollection(id);
  } finally {
    await redis().del(lock);
  }
}
