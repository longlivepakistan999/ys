import { prisma } from "./db";
import { env } from "./env";

/** Everything editable in the admin. Defaults apply until the admin saves a value. */
export const DEFAULT_SETTINGS = {
  siteName: "ReelIndex",
  siteUrl: "",                     // empty = use SITE_URL from env
  footerText: "Cast, episode guides, ratings and where to watch for every movie and TV show, updated daily.",
  tmdbToken: "",                   // empty = use TMDB_TOKEN from env
  cloudflareToken: "",
  cloudflareZone: "",
  indexNowKey: "",
  telegramBotToken: "",
  telegramChatId: "",
  telegramEvents: {
    dailySummary: true, syncFailed: true, rateLimited: true, sitemapFailed: true,
    staleData: true, crawlerSpike: true, loginSuccess: false, loginLocked: true,
  },
  // Sync
  syncCron: "30 3 * * *",          // UTC
  tmdbRatePerSecond: 30,           // TMDB soft ceiling is ~40/s
  workerConcurrency: 12,
  rotationDivisor: 150,            // refresh 1/150 of cached rows a day → ~5 months per cycle
  staleAlertDays: 150,
  preloadScope: "US_2010" as "US_2010" | "ALL" | "NONE",
  stopTrackingStatuses: ["Ended", "Canceled"],
  // Indexing thresholds
  minVotesWithoutFullData: 50,
  minShowPopularityForThinEpisodes: 20,
  minPersonCredits: 3,
  minListSize: 12,
  topRatedMinVotesMovie: 500,
  topRatedMinVotesTv: 200,
  maxListPages: 100,
  perPage: 36,
  // Nginx access log, read by the dashboard's crawler table
  nginxLogPath: "/var/log/nginx/access.log",
  // Code injection
  headCode: "",
  bodyEndCode: "",
  // SEO title templates (Admin > SEO). " | {site}" is appended to every title.
  seoTemplates: {
    movie: "{title} ({year}) – Cast, Release Date & Where to Watch",
    movieUpcoming: "{title} ({year}) – Release Date & Cast",
    tv: "{title} (TV Series {years}) – All Seasons & Episodes",
    season: "{show} Season {season} – All {episodes} Episodes, Cast & Where to Watch",
    episode: "{show} Season {season} Episode {episode}: {name} ({code})",
    person: "{name} – Movies, TV Shows & Biography",
    page: "{list_title} – Page {page}",
  },
  // Home page: one "Label | /path" per line, shown under the search box
  homeQuickLinks: "",
  homeMoviesRule: "popular" as "popular" | "recent_good" | "trending",
  homeTvRule: "popular" as "popular" | "recent_good" | "trending",
  homeCount: 12,
  robotsTxt: [
    "User-agent: *",
    "Disallow: /search",
    "Disallow: /*?sort=",
    "Disallow: /*?genre=",
    "Disallow: /*?region=",
    "Disallow: /admin",
    "Disallow: /api/",
    "",
    "User-agent: AhrefsBot",
    "Disallow: /",
    "",
    "User-agent: SemrushBot",
    "Disallow: /",
    "",
    "User-agent: MJ12bot",
    "Disallow: /",
    "",
    "User-agent: GPTBot",
    "Disallow: /",
  ].join("\n"),
};

/** Fills "{name}" placeholders. Unknown placeholders are dropped. */
export function fillTemplate(tpl: string, vars: Record<string, string | number | null | undefined>) {
  return tpl.replace(/\{(\w+)\}/g, (_, k: string) => (vars[k] === undefined || vars[k] === null ? "" : String(vars[k])))
    .replace(/\(\s*\)/g, "").replace(/\s{2,}/g, " ").trim();
}

export type Settings = typeof DEFAULT_SETTINGS;

let cache: { at: number; value: Settings } | null = null;

export async function getSettings(maxAgeMs = 30_000): Promise<Settings> {
  if (cache && Date.now() - cache.at < maxAgeMs) return cache.value;
  let rows: { key: string; value: unknown }[];
  try {
    rows = await prisma.setting.findMany();
  } catch (err) {
    // Database unreachable (e.g. during a build without DB): run on defaults, don't cache.
    console.warn("[settings] using defaults:", err instanceof Error ? err.message.split("\n")[0] : err);
    return { ...DEFAULT_SETTINGS };
  }
  const value = { ...DEFAULT_SETTINGS } as Record<string, unknown>;
  for (const r of rows) if (r.key in value) value[r.key] = r.value as unknown;
  const s = value as Settings;
  cache = { at: Date.now(), value: s };
  return s;
}

export async function saveSettings(patch: Partial<Settings>) {
  for (const [key, val] of Object.entries(patch)) {
    await prisma.setting.upsert({ where: { key }, create: { key, value: val as never }, update: { value: val as never } });
  }
  cache = null;
}

/** Secrets: admin value first, env fallback. */
export async function secrets() {
  const s = await getSettings();
  return {
    tmdbToken: s.tmdbToken || env.tmdbToken,
    siteUrl: (s.siteUrl || env.siteUrl).replace(/\/$/, ""),
    telegramBotToken: s.telegramBotToken || env.telegramBotToken,
    telegramChatId: s.telegramChatId || env.telegramChatId,
    cloudflareToken: s.cloudflareToken || env.cloudflareToken,
    cloudflareZone: s.cloudflareZone || env.cloudflareZone,
    indexNowKey: s.indexNowKey || env.indexNowKey,
  };
}
