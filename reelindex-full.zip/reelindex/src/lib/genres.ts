import { prisma } from "./db";

export interface GenreRow { id: number; name: string; slug: string; kind: string }
let cache: { at: number; list: GenreRow[] } | null = null;

export async function allGenres(): Promise<GenreRow[]> {
  if (cache && Date.now() - cache.at < 600_000) return cache.list;
  const list = await prisma.genre.findMany({ orderBy: { name: "asc" } });
  cache = { at: Date.now(), list };
  return list;
}

export async function genresFor(kind: "movie" | "tv") {
  return (await allGenres()).filter((g) => g.kind === kind || g.kind === "both");
}

export async function genreBySlug(slug: string, kind: "movie" | "tv") {
  return (await genresFor(kind)).find((g) => g.slug === slug) ?? null;
}

export async function genreNames(ids: number[]) {
  const map = new Map((await allGenres()).map((g) => [g.id, g]));
  return ids.map((id) => map.get(id)).filter((g): g is GenreRow => !!g);
}
