import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Pages are rendered on demand and cached (ISR); nothing is pre-built at deploy time.
  images: {
    // Posters and stills are served straight from TMDB's image CDN.
    remotePatterns: [{ protocol: "https", hostname: "image.tmdb.org", pathname: "/t/p/**" }],
    unoptimized: true,
  },
  poweredByHeader: false,
  // Loaded by Node at runtime instead of being bundled (BullMQ has optional native deps)
  serverExternalPackages: ["bullmq", "ioredis"],
};

export default nextConfig;
